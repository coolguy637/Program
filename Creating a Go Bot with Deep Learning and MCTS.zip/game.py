import numpy as np

class GoGame:
    def __init__(self, board_size=9):
        self.board_size = board_size
        self.reset()

    def reset(self):
        self.board = np.zeros((self.board_size, self.board_size), dtype=int)
        self.current_player = 1  # 1 for Black, -1 for White
        self.ko_state = None
        self.passes = 0
        self.history = []
        return self.get_state()

    def get_state(self):
        return self.board.copy()

    def is_valid_move(self, x, y, player):
        if x < 0 or x >= self.board_size or y < 0 or y >= self.board_size:
            return False
        if self.board[x, y] != 0:
            return False
        
        # Check for Ko and Suicide (simplified for now)
        # In a real implementation, we'd simulate the move and check liberties
        return True

    def get_liberties(self, x, y, board=None):
        if board is None:
            board = self.board
        color = board[x, y]
        if color == 0:
            return set()
        
        visited = set()
        liberties = set()
        stack = [(x, y)]
        
        while stack:
            curr_x, curr_y = stack.pop()
            if (curr_x, curr_y) in visited:
                continue
            visited.add((curr_x, curr_y))
            
            for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                nx, ny = curr_x + dx, curr_y + dy
                if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                    if board[nx, ny] == 0:
                        liberties.add((nx, ny))
                    elif board[nx, ny] == color:
                        stack.append((nx, ny))
        return liberties

    def apply_move(self, x, y):
        if x is None: # Pass
            self.passes += 1
            self.current_player *= -1
            return True
        
        if not self.is_valid_move(x, y, self.current_player):
            return False
        
        self.board[x, y] = self.current_player
        self.passes = 0
        
        # Check for captures
        opponent = -self.current_player
        for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                if self.board[nx, ny] == opponent:
                    if not self.get_liberties(nx, ny):
                        self.remove_group(nx, ny)
        
        # Check for suicide
        if not self.get_liberties(x, y):
            self.board[x, y] = 0
            return False
            
        self.current_player *= -1
        return True

    def remove_group(self, x, y):
        color = self.board[x, y]
        stack = [(x, y)]
        while stack:
            curr_x, curr_y = stack.pop()
            if self.board[curr_x, curr_y] == color:
                self.board[curr_x, curr_y] = 0
                for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                    nx, ny = curr_x + dx, curr_y + dy
                    if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                        stack.append((nx, ny))

    def is_game_over(self):
        return self.passes >= 2 or len(self.get_legal_moves()) == 0

    def get_legal_moves(self):
        moves = []
        for x in range(self.board_size):
            for y in range(self.board_size):
                if self.is_valid_move(x, y, self.current_player):
                    # Check if it's a suicide move
                    temp_board = self.board.copy()
                    temp_board[x, y] = self.current_player
                    # Simple capture check for legal move
                    captured = False
                    opponent = -self.current_player
                    for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                            if temp_board[nx, ny] == opponent:
                                if not self.get_liberties(nx, ny, temp_board):
                                    captured = True
                                    break
                    if captured or self.get_liberties(x, y, temp_board):
                        moves.append((x, y))
        moves.append(None) # Pass move
        return moves

    def get_score(self):
        # Simple stone counting for now
        black_score = np.sum(self.board == 1)
        white_score = np.sum(self.board == -1) + 6.5 # Komi
        return black_score - white_score
