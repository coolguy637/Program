from go_bot.train import Trainer
import torch

def main():
    print("Starting Go Bot Training...")
    board_size = 9
    trainer = Trainer(board_size=board_size)
    
    num_iterations = 5
    games_per_iteration = 2
    simulations_per_move = 20 # Low for demonstration speed
    
    for i in range(num_iterations):
        print(f"\nIteration {i+1}/{num_iterations}")
        
        print("Starting Self-Play...")
        trainer.self_play(num_games=games_per_iteration, num_simulations=simulations_per_move)
        
        print("Starting Training...")
        loss = trainer.train()
        if loss is not None:
            print(f"Training Loss: {loss:.4f}")
        else:
            print("Not enough data to train yet.")
            
    # Save the model
    torch.save(trainer.model.state_dict(), "go_bot_model.pth")
    print("\nTraining complete. Model saved to go_bot_model.pth")

if __name__ == "__main__":
    main()
