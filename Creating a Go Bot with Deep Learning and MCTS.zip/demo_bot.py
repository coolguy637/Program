import torch
from go_bot.game import GoGame
from go_bot.model import GoNet, state_to_tensor
from go_bot.mcts import MCTS
import numpy as np

def demo():
    print("Loading trained Go Bot...")
    board_size = 9
    model = GoNet(board_size=board_size)
    try:
        model.load_state_dict(torch.load("go_bot_model.pth"))
        print("Model loaded successfully.")
    except:
        print("Could not load model, using untrained model.")
    
    model.eval()
    game = GoGame(board_size=board_size)
    mcts = MCTS(model, game)
    
    print("\nCurrent Board (Empty):")
    print(game.board)
    
    print("\nBot is thinking for its first move...")
    probs = mcts.get_action_probs(num_simulations=50)
    
    action_idx = np.argmax(probs)
    if action_idx == board_size * board_size:
        action = "Pass"
    else:
        action = (action_idx // board_size, action_idx % board_size)
    
    print(f"Bot chooses move: {action}")
    
    if action != "Pass":
        game.apply_move(action[0], action[1])
        print("\nBoard after bot's move:")
        print(game.board)

if __name__ == "__main__":
    demo()
