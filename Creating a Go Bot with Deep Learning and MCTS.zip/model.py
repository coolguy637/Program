import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class ResBlock(nn.Module):
    def __init__(self, num_hidden):
        super().__init__()
        self.conv1 = nn.Conv2d(num_hidden, num_hidden, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(num_hidden)
        self.conv2 = nn.Conv2d(num_hidden, num_hidden, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(num_hidden)

    def forward(self, x):
        residual = x
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.bn2(self.conv2(x))
        x += residual
        x = F.relu(x)
        return x

class GoNet(nn.Module):
    def __init__(self, board_size=9, num_res_blocks=4, num_hidden=64):
        super().__init__()
        self.board_size = board_size
        
        # Initial Convolution
        self.start_block = nn.Sequential(
            nn.Conv2d(3, num_hidden, kernel_size=3, padding=1), # 3 channels: black, white, current_player
            nn.BatchNorm2d(num_hidden),
            nn.ReLU()
        )
        
        # Residual Blocks
        self.res_blocks = nn.ModuleList([ResBlock(num_hidden) for _ in range(num_res_blocks)])
        
        # Policy Head
        self.policy_head = nn.Sequential(
            nn.Conv2d(num_hidden, 2, kernel_size=1),
            nn.BatchNorm2d(2),
            nn.ReLU(),
            nn.Flatten(),
            nn.Linear(2 * board_size * board_size, board_size * board_size + 1) # +1 for pass
        )
        
        # Value Head
        self.value_head = nn.Sequential(
            nn.Conv2d(num_hidden, 1, kernel_size=1),
            nn.BatchNorm2d(1),
            nn.ReLU(),
            nn.Flatten(),
            nn.Linear(board_size * board_size, num_hidden),
            nn.ReLU(),
            nn.Linear(num_hidden, 1),
            nn.Tanh()
        )

    def forward(self, x):
        x = self.start_block(x)
        for res_block in self.res_blocks:
            x = res_block(x)
        
        policy = self.policy_head(x)
        value = self.value_head(x)
        return policy, value

def state_to_tensor(game):
    board = game.board
    board_size = game.board_size
    # 3 channels: current player's stones, opponent's stones, current player indicator
    player = game.current_player
    channel1 = (board == player).astype(float)
    channel2 = (board == -player).astype(float)
    channel3 = np.full((board_size, board_size), (1.0 if player == 1 else 0.0))
    
    state = np.stack([channel1, channel2, channel3])
    return torch.FloatTensor(state).unsqueeze(0)
