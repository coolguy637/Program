import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import random
from collections import deque
from .game import GoGame
from .model import GoNet, state_to_tensor
from .mcts import MCTS

class Trainer:
    def __init__(self, board_size=9):
        self.board_size = board_size
        self.model = GoNet(board_size=board_size)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        self.memory = deque(maxlen=2000)
        self.batch_size = 32

    def self_play(self, num_games=1, num_simulations=50):
        for g in range(num_games):
            game = GoGame(board_size=self.board_size)
            mcts = MCTS(self.model, game)
            game_history = []
            
            while not game.is_game_over() and len(game_history) < 100:
                probs = mcts.get_action_probs(num_simulations)
                state = state_to_tensor(game)
                game_history.append((state, probs, game.current_player))
                
                action_idx = np.random.choice(len(probs), p=probs)
                if action_idx == self.board_size * self.board_size:
                    action = None
                else:
                    action = (action_idx // self.board_size, action_idx % self.board_size)
                
                game.apply_move(action[0], action[1]) if action else game.apply_move(None, None)
                mcts.game = game
            
            score = game.get_score()
            winner = 1 if score > 0 else -1
            
            for state, probs, player in game_history:
                value = 1 if player == winner else -1
                self.memory.append((state, probs, value))
            
            print(f"  Game {g+1} finished. Winner: {'Black' if winner == 1 else 'White'}. Score: {score}")

    def train(self):
        if len(self.memory) < self.batch_size:
            return None
        
        batch = random.sample(self.memory, self.batch_size)
        states, target_probs, target_values = zip(*batch)
        
        states = torch.cat(states)
        target_probs = torch.FloatTensor(np.array(target_probs))
        target_values = torch.FloatTensor(np.array(target_values)).unsqueeze(1)
        
        self.model.train()
        self.optimizer.zero_grad()
        
        policy_logits, values = self.model(states)
        
        policy_loss = -torch.mean(torch.sum(target_probs * torch.log_softmax(policy_logits, dim=1), dim=1))
        value_loss = F.mse_loss(values, target_values)
        
        loss = policy_loss + value_loss
        loss.backward()
        self.optimizer.step()
        
        return loss.item()
