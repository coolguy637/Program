import numpy as np
import torch
import math

class MCTSNode:
    def __init__(self, game, parent=None, action=None, prior=0):
        self.game = game
        self.parent = parent
        self.action = action
        self.children = {}
        self.visit_count = 0
        self.value_sum = 0
        self.prior = prior
        self.state = game.get_state()

    @property
    def value(self):
        if self.visit_count == 0:
            return 0
        return self.value_sum / self.visit_count

    def select_child(self, c_puct):
        best_score = -float('inf')
        best_action = None
        best_child = None

        for action, child in self.children.items():
            # PUCT formula: Q + U
            # U = c_puct * P * sqrt(parent_N) / (1 + child_N)
            u_score = c_puct * child.prior * math.sqrt(self.visit_count) / (1 + child.visit_count)
            score = child.value + u_score
            
            if score > best_score:
                best_score = score
                best_action = action
                best_child = child
        
        return best_action, best_child

    def expand(self, policy_probs):
        legal_moves = self.game.get_legal_moves()
        board_size = self.game.board_size
        
        for move in legal_moves:
            if move is None: # Pass
                idx = board_size * board_size
            else:
                idx = move[0] * board_size + move[1]
            
            prob = policy_probs[idx]
            
            # Create a new game state for the child
            import copy
            new_game = copy.deepcopy(self.game)
            if move is None:
                new_game.apply_move(None, None)
            else:
                new_game.apply_move(move[0], move[1])
            
            self.children[move] = MCTSNode(new_game, parent=self, action=move, prior=prob)

class MCTS:
    def __init__(self, model, game, c_puct=1.4):
        self.model = model
        self.game = game
        self.c_puct = c_puct

    def search(self, num_simulations):
        root = MCTSNode(self.game)
        
        # Initial expansion of root
        from .model import state_to_tensor
        state_tensor = state_to_tensor(self.game)
        with torch.no_grad():
            policy_logits, value = self.model(state_tensor)
        policy_probs = torch.softmax(policy_logits, dim=1).numpy()[0]
        root.expand(policy_probs)

        for _ in range(num_simulations):
            node = root
            
            # Selection
            while node.children:
                action, node = node.select_child(self.c_puct)
            
            # Expansion and Evaluation
            if not node.game.is_game_over():
                state_tensor = state_to_tensor(node.game)
                with torch.no_grad():
                    policy_logits, value = self.model(state_tensor)
                policy_probs = torch.softmax(policy_logits, dim=1).numpy()[0]
                node.expand(policy_probs)
                v = value.item()
            else:
                # Terminal state evaluation
                score = node.game.get_score()
                # If current player is Black (1) and score > 0, Black wins
                # But value is from perspective of current player in node
                v = 1 if (score * node.game.current_player > 0) else -1
            
            # Backpropagation
            while node is not None:
                node.value_sum += v
                node.visit_count += 1
                v = -v # Value for parent is opposite
                node = node.parent
                
        return root

    def get_action_probs(self, num_simulations, temperature=1.0):
        root = self.search(num_simulations)
        
        board_size = self.game.board_size
        probs = np.zeros(board_size * board_size + 1)
        
        for action, child in root.children.items():
            if action is None:
                idx = board_size * board_size
            else:
                idx = action[0] * board_size + action[1]
            probs[idx] = child.visit_count
            
        probs = probs ** (1 / temperature)
        probs /= np.sum(probs)
        return probs
