# Go-Playing Bot with DNN, RL, and MCTS

This project implements a Go-playing bot inspired by the AlphaZero architecture. It uses a combination of Deep Neural Networks (DNN), Reinforcement Learning (RL), and Monte Carlo Tree Search (MCTS).

## Project Structure

- `go_bot/game.py`: A custom Go engine implementing basic rules, captures, and scoring.
- `go_bot/model.py`: A Residual Neural Network (ResNet) with policy and value heads.
- `go_bot/mcts.py`: Monte Carlo Tree Search implementation guided by the neural network.
- `go_bot/train.py`: Reinforcement learning loop using self-play and experience replay.
- `main.py`: The main training script.
- `demo_bot.py`: A script to demonstrate the bot's decision-making.

## How it Works

1.  **Neural Network**: The model takes the board state as input and outputs two things:
    - **Policy**: A probability distribution over all possible moves (including passing).
    - **Value**: A scalar representing the predicted winner from the current state.
2.  **MCTS**: During play, the bot performs multiple simulations. In each simulation, it uses the neural network's policy to guide the search and the value head to evaluate leaf nodes.
3.  **Reinforcement Learning**: The bot plays against itself (self-play). The outcomes of these games are used to train the neural network, improving both its move selection and its ability to evaluate positions.

## Training

The bot was trained on a 9x9 board for 5 iterations, with 2 self-play games per iteration. While this is a small amount of training, it demonstrates the full pipeline from game logic to model updates.

## Usage

To run the training:
```bash
python3 main.py
```

To see the bot in action:
```bash
python3 demo_bot.py
```
