"""
Simplified Backtest Script
"""

import pandas as pd
import numpy as np
from data_collector_yf import DataCollectorYF
import json

# Load historical data
collector = DataCollectorYF(symbols=['BTC-USD'], data_dir='./data')
df = collector.load_historical_data('BTC-USD', interval='1h')

print(f"Loaded {len(df)} records for BTC-USD")
print(f"Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")

# Simple buy and hold strategy
initial_capital = 10000
initial_price = df.iloc[1000]['close']
final_price = df.iloc[-1]['close']

units_bought = initial_capital / initial_price
final_value = units_bought * final_price
total_return = (final_value / initial_capital - 1) * 100

print(f"\n{'='*60}")
print("Buy & Hold Strategy Results")
print(f"{'='*60}")
print(f"Initial Capital: ${initial_capital:,.2f}")
print(f"Initial Price: ${initial_price:,.2f}")
print(f"Final Price: ${final_price:,.2f}")
print(f"Units Bought: {units_bought:.4f}")
print(f"Final Value: ${final_value:,.2f}")
print(f"Total Return: {total_return:.2f}%")

# Save results
results = {
    'strategy': 'Buy & Hold',
    'symbol': 'BTC-USD',
    'initial_capital': initial_capital,
    'final_value': float(final_value),
    'total_return_pct': float(total_return),
    'initial_price': float(initial_price),
    'final_price': float(final_price)
}

with open('./backtests/simple_backtest_results.json', 'w') as f:
    json.dump(results, f, indent=2)

print(f"\nResults saved to ./backtests/simple_backtest_results.json")
