"""
Data Collection Module for Cryptocurrency Trading Bot
Fetches historical and real-time market data from Binance API
"""

import ccxt
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import time
import json
import os


class DataCollector:
    """Collects market data from Binance and sentiment data from various sources"""
    
    def __init__(self, symbols=['BTC/USDT', 'MKR/USDT', 'BNB/USDT', 'LTC/USDT'], 
                 timeframe='1m', data_dir='./data'):
        """
        Initialize the data collector
        
        Args:
            symbols: List of trading pairs to collect data for
            timeframe: Candlestick timeframe (1m, 5m, 15m, 1h, 4h, 1d)
            data_dir: Directory to save collected data
        """
        self.symbols = symbols
        self.timeframe = timeframe
        self.data_dir = data_dir
        
        # Initialize Binance exchange with US endpoint
        self.exchange = ccxt.binance({
            'enableRateLimit': True,
            'options': {'defaultType': 'spot'},
            'urls': {
                'api': {
                    'public': 'https://data-api.binance.vision/api/v3',
                    'private': 'https://api.binance.com/api/v3',
                }
            }
        })
        
        # Create data directory if it doesn't exist
        os.makedirs(data_dir, exist_ok=True)
        
        print(f"DataCollector initialized for {symbols}")
    
    def fetch_historical_ohlcv(self, symbol, since=None, limit=1000):
        """
        Fetch historical OHLCV data from Binance
        
        Args:
            symbol: Trading pair (e.g., 'BTC/USDT')
            since: Start timestamp in milliseconds (None for recent data)
            limit: Number of candles to fetch (max 1000)
        
        Returns:
            pandas DataFrame with OHLCV data
        """
        try:
            print(f"Fetching historical data for {symbol}...")
            ohlcv = self.exchange.fetch_ohlcv(symbol, self.timeframe, since, limit)
            
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df['symbol'] = symbol
            
            print(f"Fetched {len(df)} candles for {symbol}")
            return df
            
        except Exception as e:
            print(f"Error fetching data for {symbol}: {e}")
            return pd.DataFrame()
    
    def fetch_historical_data_range(self, symbol, start_date, end_date):
        """
        Fetch historical data for a date range (handles pagination)
        
        Args:
            symbol: Trading pair
            start_date: Start date as datetime object
            end_date: End date as datetime object
        
        Returns:
            pandas DataFrame with complete historical data
        """
        all_data = []
        current_date = start_date
        
        while current_date < end_date:
            since = int(current_date.timestamp() * 1000)
            df = self.fetch_historical_ohlcv(symbol, since=since, limit=1000)
            
            if df.empty:
                break
            
            all_data.append(df)
            
            # Move to next batch
            last_timestamp = df['timestamp'].iloc[-1]
            current_date = last_timestamp + timedelta(minutes=1)
            
            # Rate limiting
            time.sleep(self.exchange.rateLimit / 1000)
        
        if all_data:
            combined_df = pd.concat(all_data, ignore_index=True)
            combined_df = combined_df.drop_duplicates(subset=['timestamp']).reset_index(drop=True)
            return combined_df
        else:
            return pd.DataFrame()
    
    def fetch_all_symbols_historical(self, days=730):
        """
        Fetch historical data for all configured symbols
        
        Args:
            days: Number of days of historical data to fetch (default 730 = 2 years)
        
        Returns:
            Dictionary with symbol as key and DataFrame as value
        """
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        all_data = {}
        
        for symbol in self.symbols:
            print(f"\n{'='*60}")
            print(f"Collecting data for {symbol}")
            print(f"{'='*60}")
            
            df = self.fetch_historical_data_range(symbol, start_date, end_date)
            
            if not df.empty:
                # Save to CSV
                filename = f"{self.data_dir}/{symbol.replace('/', '_')}_{self.timeframe}_historical.csv"
                df.to_csv(filename, index=False)
                print(f"Saved {len(df)} records to {filename}")
                
                all_data[symbol] = df
            else:
                print(f"No data collected for {symbol}")
        
        return all_data
    
    def fetch_current_price(self, symbol):
        """
        Fetch current ticker price for a symbol
        
        Args:
            symbol: Trading pair
        
        Returns:
            Dictionary with price information
        """
        try:
            ticker = self.exchange.fetch_ticker(symbol)
            return {
                'symbol': symbol,
                'price': ticker['last'],
                'bid': ticker['bid'],
                'ask': ticker['ask'],
                'volume': ticker['quoteVolume'],
                'timestamp': datetime.now()
            }
        except Exception as e:
            print(f"Error fetching current price for {symbol}: {e}")
            return None
    
    def fetch_fear_greed_index(self):
        """
        Fetch Fear & Greed Index from alternative.me
        
        Returns:
            Dictionary with fear & greed data
        """
        try:
            url = "https://api.alternative.me/fng/?limit=1"
            response = requests.get(url, timeout=10)
            data = response.json()
            
            if 'data' in data and len(data['data']) > 0:
                fng_data = data['data'][0]
                return {
                    'value': int(fng_data['value']),
                    'classification': fng_data['value_classification'],
                    'timestamp': datetime.fromtimestamp(int(fng_data['timestamp']))
                }
            else:
                return None
                
        except Exception as e:
            print(f"Error fetching Fear & Greed Index: {e}")
            return None
    
    def fetch_order_book(self, symbol, limit=20):
        """
        Fetch order book data
        
        Args:
            symbol: Trading pair
            limit: Depth of order book
        
        Returns:
            Dictionary with bids and asks
        """
        try:
            order_book = self.exchange.fetch_order_book(symbol, limit)
            return {
                'symbol': symbol,
                'bids': order_book['bids'][:limit],
                'asks': order_book['asks'][:limit],
                'timestamp': datetime.now()
            }
        except Exception as e:
            print(f"Error fetching order book for {symbol}: {e}")
            return None
    
    def get_market_summary(self):
        """
        Get current market summary for all symbols
        
        Returns:
            pandas DataFrame with market summary
        """
        summary_data = []
        
        for symbol in self.symbols:
            price_data = self.fetch_current_price(symbol)
            if price_data:
                summary_data.append(price_data)
        
        # Add Fear & Greed Index
        fng = self.fetch_fear_greed_index()
        
        df = pd.DataFrame(summary_data)
        
        if fng:
            df['fear_greed_value'] = fng['value']
            df['fear_greed_class'] = fng['classification']
        
        return df
    
    def load_historical_data(self, symbol):
        """
        Load historical data from saved CSV file
        
        Args:
            symbol: Trading pair
        
        Returns:
            pandas DataFrame
        """
        filename = f"{self.data_dir}/{symbol.replace('/', '_')}_{self.timeframe}_historical.csv"
        
        if os.path.exists(filename):
            df = pd.read_csv(filename)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            print(f"Loaded {len(df)} records from {filename}")
            return df
        else:
            print(f"File not found: {filename}")
            return pd.DataFrame()


def main():
    """Test the data collector"""
    
    # Initialize collector
    collector = DataCollector(
        symbols=['BTC/USDT', 'MKR/USDT', 'BNB/USDT', 'LTC/USDT'],
        timeframe='1h',  # Use 1h for faster testing
        data_dir='./data'
    )
    
    # Test 1: Fetch recent data
    print("\n" + "="*60)
    print("TEST 1: Fetching recent OHLCV data")
    print("="*60)
    df = collector.fetch_historical_ohlcv('BTC/USDT', limit=100)
    print(df.head())
    print(f"\nData shape: {df.shape}")
    
    # Test 2: Fetch current prices
    print("\n" + "="*60)
    print("TEST 2: Fetching current prices")
    print("="*60)
    summary = collector.get_market_summary()
    print(summary)
    
    # Test 3: Fetch Fear & Greed Index
    print("\n" + "="*60)
    print("TEST 3: Fetching Fear & Greed Index")
    print("="*60)
    fng = collector.fetch_fear_greed_index()
    print(json.dumps(fng, indent=2, default=str))
    
    # Test 4: Fetch order book
    print("\n" + "="*60)
    print("TEST 4: Fetching order book")
    print("="*60)
    order_book = collector.fetch_order_book('BTC/USDT', limit=5)
    if order_book:
        print(f"Top 5 Bids: {order_book['bids'][:5]}")
        print(f"Top 5 Asks: {order_book['asks'][:5]}")
    
    print("\n" + "="*60)
    print("Data collection tests completed!")
    print("="*60)


if __name__ == "__main__":
    main()
