"""
Trading Bot and Backtesting Engine
Executes trades based on ML model predictions with risk management
"""

import pandas as pd
import numpy as np
from datetime import datetime
import json
import os
from data_collector_yf import DataCollectorYF
from feature_engineer import FeatureEngineer
from ml_models import TradingModelTrainer


class TradingBot:
    """Automated cryptocurrency trading bot"""
    
    def __init__(self, symbols, initial_capital=10000, max_position_size=0.25,
                 stop_loss_pct=0.03, take_profit_pct=0.08, models_dir='./models'):
        """
        Initialize trading bot
        
        Args:
            symbols: List of trading symbols
            initial_capital: Starting capital in USD
            max_position_size: Maximum position size as fraction of portfolio
            stop_loss_pct: Stop loss percentage
            take_profit_pct: Take profit percentage
            models_dir: Directory containing trained models
        """
        self.symbols = symbols
        self.initial_capital = initial_capital
        self.capital = initial_capital
        self.max_position_size = max_position_size
        self.stop_loss_pct = stop_loss_pct
        self.take_profit_pct = take_profit_pct
        self.models_dir = models_dir
        
        # Portfolio tracking
        self.positions = {symbol: 0 for symbol in symbols}
        self.entry_prices = {symbol: 0 for symbol in symbols}
        self.cash = initial_capital
        
        # Performance tracking
        self.trades = []
        self.portfolio_values = []
        
        # Initialize components
        self.collector = DataCollectorYF(symbols=symbols, data_dir='./data')
        self.engineer = FeatureEngineer(scaler_type='standard')
        self.trainer = TradingModelTrainer(models_dir=models_dir)
        
        print(f"TradingBot initialized with ${initial_capital:,.2f} capital")
    
    def load_models(self, symbol):
        """Load trained models for a symbol"""
        self.trainer.load_models(symbol)
    
    def generate_signal(self, df, symbol, fear_greed_value=None):
        """
        Generate trading signal for a symbol
        
        Args:
            df: Historical OHLCV data
            symbol: Trading symbol
            fear_greed_value: Current Fear & Greed Index
        
        Returns:
            Signal (-1, 0, 1) and confidence score
        """
        # Calculate features
        df_features = self.engineer.calculate_all_features(df, fear_greed_value)
        
        if df_features.empty:
            return 0, 0.0
        
        # Get feature columns
        feature_cols = self.engineer.get_feature_columns(df_features)
        
        # Scale features using existing scaler
        df_features = self.engineer.scale_features(df_features, symbol, fit=False)
        
        # Get latest features
        X = df_features[feature_cols].iloc[-1:].values
        
        # Ensemble prediction
        signal = self.trainer.ensemble_predict(X)[0]
        
        # Calculate confidence (simplified - could be improved)
        confidence = 0.75  # Default confidence
        
        return signal, confidence
    
    def calculate_position_size(self, price, confidence):
        """
        Calculate position size based on available capital and confidence
        
        Args:
            price: Current asset price
            confidence: Signal confidence (0-1)
        
        Returns:
            Number of units to buy/sell
        """
        # Maximum position value
        max_position_value = self.capital * self.max_position_size
        
        # Adjust by confidence
        position_value = max_position_value * confidence
        
        # Calculate units
        units = position_value / price
        
        return units
    
    def execute_buy(self, symbol, price, units, timestamp):
        """Execute buy order"""
        cost = price * units
        
        if cost > self.cash:
            # Insufficient funds
            return False
        
        self.positions[symbol] += units
        self.entry_prices[symbol] = price
        self.cash -= cost
        
        trade = {
            'timestamp': timestamp,
            'symbol': symbol,
            'action': 'BUY',
            'price': price,
            'units': units,
            'cost': cost,
            'cash_remaining': self.cash
        }
        self.trades.append(trade)
        
        return True
    
    def execute_sell(self, symbol, price, units, timestamp):
        """Execute sell order"""
        if units > self.positions[symbol]:
            units = self.positions[symbol]
        
        if units <= 0:
            return False
        
        proceeds = price * units
        self.positions[symbol] -= units
        self.cash += proceeds
        
        # Calculate profit/loss
        entry_price = self.entry_prices[symbol]
        pnl = (price - entry_price) * units
        pnl_pct = (price / entry_price - 1) * 100 if entry_price > 0 else 0
        
        trade = {
            'timestamp': timestamp,
            'symbol': symbol,
            'action': 'SELL',
            'price': price,
            'units': units,
            'proceeds': proceeds,
            'pnl': pnl,
            'pnl_pct': pnl_pct,
            'cash_remaining': self.cash
        }
        self.trades.append(trade)
        
        return True
    
    def check_stop_loss_take_profit(self, symbol, current_price, timestamp):
        """Check if stop loss or take profit should be triggered"""
        if self.positions[symbol] <= 0:
            return False
        
        entry_price = self.entry_prices[symbol]
        price_change = (current_price / entry_price - 1)
        
        # Check stop loss
        if price_change <= -self.stop_loss_pct:
            units = self.positions[symbol]
            self.execute_sell(symbol, current_price, units, timestamp)
            return True
        
        # Check take profit
        if price_change >= self.take_profit_pct:
            units = self.positions[symbol]
            self.execute_sell(symbol, current_price, units, timestamp)
            return True
        
        return False
    
    def calculate_portfolio_value(self, prices):
        """
        Calculate total portfolio value
        
        Args:
            prices: Dictionary of current prices for each symbol
        
        Returns:
            Total portfolio value
        """
        portfolio_value = self.cash
        
        for symbol in self.symbols:
            if symbol in prices:
                portfolio_value += self.positions[symbol] * prices[symbol]
        
        return portfolio_value
    
    def backtest(self, start_date=None, end_date=None, lookback_periods=200):
        """
        Run backtest on historical data
        
        Args:
            start_date: Start date for backtest
            end_date: End date for backtest
            lookback_periods: Number of periods to use for feature calculation
        
        Returns:
            Backtest results dictionary
        """
        print(f"\n{'='*60}")
        print("Running Backtest")
        print(f"{'='*60}")
        
        # Load historical data for all symbols
        all_data = {}
        for symbol in self.symbols:
            df = self.collector.load_historical_data(symbol, interval='1h')
            if not df.empty:
                all_data[symbol] = df
                # Load models for this symbol
                self.load_models(symbol)
        
        if not all_data:
            print("No historical data available for backtesting")
            return None
        
        # Get common date range
        min_length = min(len(df) for df in all_data.values())
        
        # Get Fear & Greed Index
        fng = self.collector.fetch_fear_greed_index()
        fng_value = fng['value'] if fng else 50
        
        print(f"Backtesting on {min_length} periods")
        print(f"Initial Capital: ${self.initial_capital:,.2f}")
        
        # Run backtest
        for i in range(lookback_periods, min_length):
            if i % 500 == 0:
                print(f"Progress: {i}/{min_length} ({i/min_length*100:.1f}%)")
            
            current_prices = {}
            
            for symbol in self.symbols:
                if symbol not in all_data:
                    continue
                
                df = all_data[symbol]
                current_price = df.iloc[i]['close']
                current_prices[symbol] = current_price
                timestamp = df.iloc[i]['timestamp']
                
                # Check stop loss / take profit
                self.check_stop_loss_take_profit(symbol, current_price, timestamp)
                
                # Generate signal using lookback data
                lookback_df = df.iloc[i-lookback_periods:i].copy()
                signal, confidence = self.generate_signal(lookback_df, symbol, fng_value)
                
                # Execute trades based on signal
                if signal == 1 and self.positions[symbol] == 0:  # BUY signal
                    units = self.calculate_position_size(current_price, confidence)
                    self.execute_buy(symbol, current_price, units, timestamp)
                
                elif signal == -1 and self.positions[symbol] > 0:  # SELL signal
                    units = self.positions[symbol]
                    self.execute_sell(symbol, current_price, units, timestamp)
            
            # Record portfolio value
            portfolio_value = self.calculate_portfolio_value(current_prices)
            self.portfolio_values.append({
                'timestamp': timestamp,
                'value': portfolio_value
            })
        
        # Calculate final metrics
        final_value = self.calculate_portfolio_value(current_prices)
        total_return = (final_value / self.initial_capital - 1) * 100
        
        # Calculate buy & hold return for comparison
        buy_hold_returns = {}
        for symbol in self.symbols:
            if symbol in all_data:
                df = all_data[symbol]
                initial_price = df.iloc[lookback_periods]['close']
                final_price = df.iloc[-1]['close']
                buy_hold_returns[symbol] = (final_price / initial_price - 1) * 100
        
        results = {
            'initial_capital': self.initial_capital,
            'final_value': final_value,
            'total_return_pct': total_return,
            'total_trades': len(self.trades),
            'buy_hold_returns': buy_hold_returns,
            'trades': self.trades,
            'portfolio_values': self.portfolio_values
        }
        
        print(f"\n{'='*60}")
        print("Backtest Results")
        print(f"{'='*60}")
        print(f"Initial Capital: ${self.initial_capital:,.2f}")
        print(f"Final Value: ${final_value:,.2f}")
        print(f"Total Return: {total_return:.2f}%")
        print(f"Total Trades: {len(self.trades)}")
        print(f"\nBuy & Hold Returns:")
        for symbol, ret in buy_hold_returns.items():
            print(f"  {symbol}: {ret:.2f}%")
        
        return results
    
    def save_backtest_results(self, results, filename='backtest_results.json'):
        """Save backtest results to file"""
        filepath = f"./backtests/{filename}"
        
        # Convert datetime objects to strings
        results_copy = results.copy()
        results_copy['trades'] = [
            {k: str(v) if isinstance(v, (pd.Timestamp, datetime)) else v 
             for k, v in trade.items()}
            for trade in results['trades']
        ]
        results_copy['portfolio_values'] = [
            {k: str(v) if isinstance(v, (pd.Timestamp, datetime)) else v 
             for k, v in pv.items()}
            for pv in results['portfolio_values']
        ]
        
        with open(filepath, 'w') as f:
            json.dump(results_copy, f, indent=2)
        
        print(f"\nBacktest results saved to {filepath}")


def main():
    """Run backtest"""
    
    # Initialize trading bot
    bot = TradingBot(
        symbols=['BTC-USD', 'MKR-USD', 'BNB-USD', 'LTC-USD'],
        initial_capital=10000,
        max_position_size=0.25,
        stop_loss_pct=0.03,
        take_profit_pct=0.08,
        models_dir='./models'
    )
    
    # Run backtest
    results = bot.backtest(lookback_periods=200)
    
    if results:
        # Save results
        bot.save_backtest_results(results)
        
        # Display sample trades
        print(f"\n{'='*60}")
        print("Sample Trades (First 10)")
        print(f"{'='*60}")
        trades_df = pd.DataFrame(results['trades'][:10])
        print(trades_df.to_string())


if __name__ == "__main__":
    main()
