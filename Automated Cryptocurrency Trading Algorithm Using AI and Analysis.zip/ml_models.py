"""
Machine Learning Models Module for Cryptocurrency Trading Bot
Trains and evaluates ensemble models for trading signal generation
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import train_test_split, cross_val_score, TimeSeriesSplit
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.metrics import precision_score, recall_score, f1_score
import xgboost as xgb
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
import joblib
import os
import json
from datetime import datetime


class TradingModelTrainer:
    """Trains and manages ML models for trading signal generation"""
    
    def __init__(self, models_dir='./models'):
        """
        Initialize the model trainer
        
        Args:
            models_dir: Directory to save trained models
        """
        self.models_dir = models_dir
        self.models = {}
        self.model_scores = {}
        
        # Create models directory if it doesn't exist
        os.makedirs(models_dir, exist_ok=True)
        
        print(f"TradingModelTrainer initialized")
    
    def train_random_forest(self, X_train, y_train, X_test, y_test, 
                           n_estimators=200, max_depth=15, random_state=42):
        """
        Train Random Forest classifier
        
        Args:
            X_train, y_train: Training data
            X_test, y_test: Test data
            n_estimators: Number of trees
            max_depth: Maximum tree depth
            random_state: Random seed
        
        Returns:
            Trained model and performance metrics
        """
        print(f"\n{'='*60}")
        print("Training Random Forest Classifier")
        print(f"{'='*60}")
        
        model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=random_state,
            n_jobs=-1,
            class_weight='balanced'
        )
        
        model.fit(X_train, y_train)
        
        # Predictions
        y_pred_train = model.predict(X_train)
        y_pred_test = model.predict(X_test)
        
        # Calculate metrics
        train_acc = accuracy_score(y_train, y_pred_train)
        test_acc = accuracy_score(y_test, y_pred_test)
        
        print(f"\nTraining Accuracy: {train_acc:.4f}")
        print(f"Test Accuracy: {test_acc:.4f}")
        
        print("\nTest Set Classification Report:")
        print(classification_report(y_test, y_pred_test, 
                                   target_names=['SELL', 'HOLD', 'BUY']))
        
        # Feature importance
        feature_importance = model.feature_importances_
        
        metrics = {
            'model_name': 'RandomForest',
            'train_accuracy': float(train_acc),
            'test_accuracy': float(test_acc),
            'test_precision': float(precision_score(y_test, y_pred_test, average='weighted')),
            'test_recall': float(recall_score(y_test, y_pred_test, average='weighted')),
            'test_f1': float(f1_score(y_test, y_pred_test, average='weighted'))
        }
        
        self.models['random_forest'] = model
        self.model_scores['random_forest'] = metrics
        
        return model, metrics, feature_importance
    
    def train_xgboost(self, X_train, y_train, X_test, y_test,
                     n_estimators=200, max_depth=10, learning_rate=0.1, random_state=42):
        """
        Train XGBoost classifier
        
        Args:
            X_train, y_train: Training data
            X_test, y_test: Test data
            n_estimators: Number of boosting rounds
            max_depth: Maximum tree depth
            learning_rate: Learning rate
            random_state: Random seed
        
        Returns:
            Trained model and performance metrics
        """
        print(f"\n{'='*60}")
        print("Training XGBoost Classifier")
        print(f"{'='*60}")
        
        # Adjust labels to be 0, 1, 2 for XGBoost
        y_train_adj = y_train + 1
        y_test_adj = y_test + 1
        
        model = xgb.XGBClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            random_state=random_state,
            n_jobs=-1,
            eval_metric='mlogloss'
        )
        
        model.fit(X_train, y_train_adj)
        
        # Predictions
        y_pred_train = model.predict(X_train)
        y_pred_test = model.predict(X_test)
        
        # Convert back to -1, 0, 1
        y_pred_train = y_pred_train - 1
        y_pred_test = y_pred_test - 1
        
        # Calculate metrics
        train_acc = accuracy_score(y_train, y_pred_train)
        test_acc = accuracy_score(y_test, y_pred_test)
        
        print(f"\nTraining Accuracy: {train_acc:.4f}")
        print(f"Test Accuracy: {test_acc:.4f}")
        
        print("\nTest Set Classification Report:")
        print(classification_report(y_test, y_pred_test,
                                   target_names=['SELL', 'HOLD', 'BUY']))
        
        metrics = {
            'model_name': 'XGBoost',
            'train_accuracy': float(train_acc),
            'test_accuracy': float(test_acc),
            'test_precision': float(precision_score(y_test, y_pred_test, average='weighted')),
            'test_recall': float(recall_score(y_test, y_pred_test, average='weighted')),
            'test_f1': float(f1_score(y_test, y_pred_test, average='weighted'))
        }
        
        self.models['xgboost'] = model
        self.model_scores['xgboost'] = metrics
        
        return model, metrics
    
    def train_gradient_boosting(self, X_train, y_train, X_test, y_test,
                               n_estimators=100, max_depth=5, learning_rate=0.1, random_state=42):
        """
        Train Gradient Boosting classifier
        
        Args:
            X_train, y_train: Training data
            X_test, y_test: Test data
            n_estimators: Number of boosting stages
            max_depth: Maximum tree depth
            learning_rate: Learning rate
            random_state: Random seed
        
        Returns:
            Trained model and performance metrics
        """
        print(f"\n{'='*60}")
        print("Training Gradient Boosting Classifier")
        print(f"{'='*60}")
        
        # Adjust labels to be 0, 1, 2
        y_train_adj = y_train + 1
        y_test_adj = y_test + 1
        
        model = GradientBoostingClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            random_state=random_state
        )
        
        model.fit(X_train, y_train_adj)
        
        # Predictions
        y_pred_train = model.predict(X_train)
        y_pred_test = model.predict(X_test)
        
        # Convert back to -1, 0, 1
        y_pred_train = y_pred_train - 1
        y_pred_test = y_pred_test - 1
        
        # Calculate metrics
        train_acc = accuracy_score(y_train, y_pred_train)
        test_acc = accuracy_score(y_test, y_pred_test)
        
        print(f"\nTraining Accuracy: {train_acc:.4f}")
        print(f"Test Accuracy: {test_acc:.4f}")
        
        print("\nTest Set Classification Report:")
        print(classification_report(y_test, y_pred_test,
                                   target_names=['SELL', 'HOLD', 'BUY']))
        
        metrics = {
            'model_name': 'GradientBoosting',
            'train_accuracy': float(train_acc),
            'test_accuracy': float(test_acc),
            'test_precision': float(precision_score(y_test, y_pred_test, average='weighted')),
            'test_recall': float(recall_score(y_test, y_pred_test, average='weighted')),
            'test_f1': float(f1_score(y_test, y_pred_test, average='weighted'))
        }
        
        self.models['gradient_boosting'] = model
        self.model_scores['gradient_boosting'] = metrics
        
        return model, metrics
    
    def build_lstm_model(self, input_shape, num_classes=3):
        """
        Build LSTM neural network model
        
        Args:
            input_shape: Shape of input data (timesteps, features)
            num_classes: Number of output classes
        
        Returns:
            Compiled Keras model
        """
        model = Sequential([
            LSTM(64, return_sequences=True, input_shape=input_shape),
            Dropout(0.2),
            LSTM(32, return_sequences=False),
            Dropout(0.2),
            Dense(16, activation='relu'),
            Dense(num_classes, activation='softmax')
        ])
        
        model.compile(
            optimizer='adam',
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def ensemble_predict(self, X, weights=None):
        """
        Make ensemble predictions using weighted voting
        
        Args:
            X: Feature matrix
            weights: Dictionary of model weights (default: equal weights)
        
        Returns:
            Array of ensemble predictions
        """
        if weights is None:
            weights = {
                'random_forest': 0.4,
                'xgboost': 0.4,
                'gradient_boosting': 0.2
            }
        
        predictions = {}
        
        # Get predictions from each model
        if 'random_forest' in self.models:
            predictions['random_forest'] = self.models['random_forest'].predict(X)
        
        if 'xgboost' in self.models:
            pred = self.models['xgboost'].predict(X)
            predictions['xgboost'] = pred - 1  # Convert back to -1, 0, 1
        
        if 'gradient_boosting' in self.models:
            pred = self.models['gradient_boosting'].predict(X)
            predictions['gradient_boosting'] = pred - 1  # Convert back to -1, 0, 1
        
        # Weighted voting
        ensemble_pred = np.zeros(len(X))
        
        for model_name, pred in predictions.items():
            weight = weights.get(model_name, 0)
            ensemble_pred += pred * weight
        
        # Round to nearest class
        ensemble_pred = np.round(ensemble_pred).astype(int)
        
        return ensemble_pred
    
    def save_models(self, symbol):
        """
        Save trained models to disk
        
        Args:
            symbol: Trading pair symbol
        """
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        for model_name, model in self.models.items():
            filename = f"{self.models_dir}/{symbol}_{model_name}_{timestamp}.pkl"
            joblib.dump(model, filename)
            print(f"Saved {model_name} to {filename}")
        
        # Save model scores
        scores_file = f"{self.models_dir}/{symbol}_model_scores_{timestamp}.json"
        with open(scores_file, 'w') as f:
            json.dump(self.model_scores, f, indent=2)
        print(f"Saved model scores to {scores_file}")
    
    def load_models(self, symbol, timestamp=None):
        """
        Load trained models from disk
        
        Args:
            symbol: Trading pair symbol
            timestamp: Specific timestamp (None for latest)
        """
        # Find model files
        import glob
        
        if timestamp:
            pattern = f"{self.models_dir}/{symbol}_*_{timestamp}.pkl"
        else:
            pattern = f"{self.models_dir}/{symbol}_*.pkl"
        
        model_files = sorted(glob.glob(pattern))
        
        if not model_files:
            print(f"No model files found for {symbol}")
            return
        
        for filepath in model_files:
            model_name = filepath.split('_')[-2]
            model = joblib.load(filepath)
            self.models[model_name] = model
            print(f"Loaded {model_name} from {filepath}")


def main():
    """Test the ML model trainer"""
    from data_collector_yf import DataCollectorYF
    from feature_engineer import FeatureEngineer
    
    # Initialize components
    collector = DataCollectorYF(symbols=['BTC-USD'], data_dir='./data')
    engineer = FeatureEngineer(scaler_type='standard')
    trainer = TradingModelTrainer(models_dir='./models')
    
    # Load historical data from saved CSV
    print("Loading historical data...")
    df = collector.load_historical_data('BTC-USD', interval='1h')
    
    fng = collector.fetch_fear_greed_index()
    fng_value = fng['value'] if fng else None
    
    # Prepare ML dataset
    X, y, feature_names, processed_df = engineer.prepare_ml_dataset(
        df=df,
        symbol='BTC-USD',
        fear_greed_value=fng_value,
        forward_periods=5,
        threshold=0.02,
        scale=True
    )
    
    # Split data (80% train, 20% test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=False
    )
    
    print(f"\nTrain set: {X_train.shape}, Test set: {X_test.shape}")
    
    # Train models
    rf_model, rf_metrics, rf_importance = trainer.train_random_forest(
        X_train, y_train, X_test, y_test
    )
    
    xgb_model, xgb_metrics = trainer.train_xgboost(
        X_train, y_train, X_test, y_test
    )
    
    gb_model, gb_metrics = trainer.train_gradient_boosting(
        X_train, y_train, X_test, y_test
    )
    
    # Ensemble prediction
    print(f"\n{'='*60}")
    print("Ensemble Model Evaluation")
    print(f"{'='*60}")
    
    ensemble_pred = trainer.ensemble_predict(X_test)
    ensemble_acc = accuracy_score(y_test, ensemble_pred)
    
    print(f"\nEnsemble Test Accuracy: {ensemble_acc:.4f}")
    print("\nEnsemble Classification Report:")
    print(classification_report(y_test, ensemble_pred,
                               target_names=['SELL', 'HOLD', 'BUY']))
    
    # Display top features
    print(f"\n{'='*60}")
    print("Top 10 Most Important Features (Random Forest)")
    print(f"{'='*60}")
    
    feature_importance_df = pd.DataFrame({
        'feature': feature_names,
        'importance': rf_importance
    }).sort_values('importance', ascending=False)
    
    print(feature_importance_df.head(10))
    
    # Save models
    trainer.save_models('BTC-USD')
    
    print(f"\n{'='*60}")
    print("Model training completed!")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
