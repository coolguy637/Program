"""
Feature Engineering Module for Cryptocurrency Trading Bot
Calculates technical indicators and prepares features for ML models
"""

import pandas as pd
import numpy as np
from ta.trend import SMAIndicator, EMAIndicator, MACD
from ta.momentum import RSIIndicator, StochasticOscillator, ROCIndicator
from ta.volatility import BollingerBands, AverageTrueRange
from ta.volume import OnBalanceVolumeIndicator, VolumeWeightedAveragePrice
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import warnings
warnings.filterwarnings('ignore')


class FeatureEngineer:
    """Calculates technical indicators and prepares ML features"""
    
    def __init__(self, scaler_type='standard'):
        """
        Initialize the feature engineer
        
        Args:
            scaler_type: Type of scaler to use ('standard' or 'minmax')
        """
        self.scaler_type = scaler_type
        self.scalers = {}  # Store scalers for each symbol
        
        print(f"FeatureEngineer initialized with {scaler_type} scaler")
    
    def add_trend_indicators(self, df):
        """
        Add trend-based technical indicators
        
        Args:
            df: DataFrame with OHLCV data
        
        Returns:
            DataFrame with added trend indicators
        """
        # Simple Moving Averages
        df['sma_20'] = SMAIndicator(close=df['close'], window=20).sma_indicator()
        df['sma_50'] = SMAIndicator(close=df['close'], window=50).sma_indicator()
        df['sma_200'] = SMAIndicator(close=df['close'], window=200).sma_indicator()
        
        # Exponential Moving Averages
        df['ema_12'] = EMAIndicator(close=df['close'], window=12).ema_indicator()
        df['ema_26'] = EMAIndicator(close=df['close'], window=26).ema_indicator()
        
        # MACD
        macd = MACD(close=df['close'])
        df['macd'] = macd.macd()
        df['macd_signal'] = macd.macd_signal()
        df['macd_diff'] = macd.macd_diff()
        
        # Price position relative to moving averages
        df['price_sma20_ratio'] = df['close'] / df['sma_20']
        df['price_sma50_ratio'] = df['close'] / df['sma_50']
        
        return df
    
    def add_momentum_indicators(self, df):
        """
        Add momentum-based technical indicators
        
        Args:
            df: DataFrame with OHLCV data
        
        Returns:
            DataFrame with added momentum indicators
        """
        # RSI (Relative Strength Index)
        df['rsi_14'] = RSIIndicator(close=df['close'], window=14).rsi()
        
        # Stochastic Oscillator
        stoch = StochasticOscillator(
            high=df['high'],
            low=df['low'],
            close=df['close'],
            window=14,
            smooth_window=3
        )
        df['stoch_k'] = stoch.stoch()
        df['stoch_d'] = stoch.stoch_signal()
        
        # Rate of Change
        df['roc_10'] = ROCIndicator(close=df['close'], window=10).roc()
        df['roc_30'] = ROCIndicator(close=df['close'], window=30).roc()
        
        return df
    
    def add_volatility_indicators(self, df):
        """
        Add volatility-based technical indicators
        
        Args:
            df: DataFrame with OHLCV data
        
        Returns:
            DataFrame with added volatility indicators
        """
        # Bollinger Bands
        bb = BollingerBands(close=df['close'], window=20, window_dev=2)
        df['bb_high'] = bb.bollinger_hband()
        df['bb_mid'] = bb.bollinger_mavg()
        df['bb_low'] = bb.bollinger_lband()
        df['bb_width'] = bb.bollinger_wband()
        df['bb_pband'] = bb.bollinger_pband()
        
        # Average True Range
        df['atr_14'] = AverageTrueRange(
            high=df['high'],
            low=df['low'],
            close=df['close'],
            window=14
        ).average_true_range()
        
        # Historical volatility
        df['volatility_20'] = df['close'].pct_change().rolling(window=20).std()
        
        return df
    
    def add_volume_indicators(self, df):
        """
        Add volume-based technical indicators
        
        Args:
            df: DataFrame with OHLCV data
        
        Returns:
            DataFrame with added volume indicators
        """
        # On-Balance Volume
        df['obv'] = OnBalanceVolumeIndicator(
            close=df['close'],
            volume=df['volume']
        ).on_balance_volume()
        
        # Volume Moving Average
        df['volume_sma_20'] = df['volume'].rolling(window=20).mean()
        
        # Volume ratio
        df['volume_ratio'] = df['volume'] / df['volume_sma_20']
        
        # VWAP (Volume Weighted Average Price)
        try:
            df['vwap'] = VolumeWeightedAveragePrice(
                high=df['high'],
                low=df['low'],
                close=df['close'],
                volume=df['volume']
            ).volume_weighted_average_price()
        except:
            # Fallback if VWAP calculation fails
            df['vwap'] = df['close']
        
        return df
    
    def add_price_features(self, df):
        """
        Add price-based features
        
        Args:
            df: DataFrame with OHLCV data
        
        Returns:
            DataFrame with added price features
        """
        # Price changes
        df['price_change_1'] = df['close'].pct_change(1)
        df['price_change_5'] = df['close'].pct_change(5)
        df['price_change_10'] = df['close'].pct_change(10)
        df['price_change_20'] = df['close'].pct_change(20)
        
        # High-Low spread
        df['hl_spread'] = (df['high'] - df['low']) / df['close']
        
        # Close position in range
        df['close_position'] = (df['close'] - df['low']) / (df['high'] - df['low'] + 1e-10)
        
        # Price momentum
        df['momentum_5'] = df['close'] - df['close'].shift(5)
        df['momentum_10'] = df['close'] - df['close'].shift(10)
        
        return df
    
    def add_sentiment_features(self, df, fear_greed_value=None):
        """
        Add sentiment-based features
        
        Args:
            df: DataFrame with market data
            fear_greed_value: Current Fear & Greed Index value (0-100)
        
        Returns:
            DataFrame with added sentiment features
        """
        if fear_greed_value is not None:
            df['fear_greed'] = fear_greed_value
            df['fear_greed_normalized'] = fear_greed_value / 100.0
        else:
            df['fear_greed'] = 50  # Neutral default
            df['fear_greed_normalized'] = 0.5
        
        return df
    
    def calculate_all_features(self, df, fear_greed_value=None):
        """
        Calculate all technical indicators and features
        
        Args:
            df: DataFrame with OHLCV data
            fear_greed_value: Current Fear & Greed Index value
        
        Returns:
            DataFrame with all features
        """
        print(f"Calculating features for {len(df)} records...")
        
        # Make a copy to avoid modifying original
        df = df.copy()
        
        # Add all indicators
        df = self.add_trend_indicators(df)
        df = self.add_momentum_indicators(df)
        df = self.add_volatility_indicators(df)
        df = self.add_volume_indicators(df)
        df = self.add_price_features(df)
        df = self.add_sentiment_features(df, fear_greed_value)
        
        # Drop rows with NaN values (from indicator calculations)
        initial_rows = len(df)
        df = df.dropna()
        dropped_rows = initial_rows - len(df)
        
        print(f"Features calculated. Dropped {dropped_rows} rows with NaN values.")
        print(f"Final dataset: {len(df)} records with {len(df.columns)} features")
        
        return df
    
    def create_labels(self, df, forward_periods=5, threshold=0.02):
        """
        Create trading labels (BUY=1, HOLD=0, SELL=-1) based on future price movement
        
        Args:
            df: DataFrame with price data
            forward_periods: Number of periods to look ahead
            threshold: Minimum price change percentage to trigger BUY/SELL
        
        Returns:
            DataFrame with 'label' column added
        """
        # Calculate future returns
        df['future_return'] = df['close'].shift(-forward_periods) / df['close'] - 1
        
        # Create labels
        df['label'] = 0  # HOLD
        df.loc[df['future_return'] > threshold, 'label'] = 1  # BUY
        df.loc[df['future_return'] < -threshold, 'label'] = -1  # SELL
        
        # Drop rows without future data
        df = df[:-forward_periods]
        
        label_counts = df['label'].value_counts()
        print(f"\nLabel distribution:")
        print(f"  BUY (1):  {label_counts.get(1, 0)} ({label_counts.get(1, 0)/len(df)*100:.1f}%)")
        print(f"  HOLD (0): {label_counts.get(0, 0)} ({label_counts.get(0, 0)/len(df)*100:.1f}%)")
        print(f"  SELL (-1): {label_counts.get(-1, 0)} ({label_counts.get(-1, 0)/len(df)*100:.1f}%)")
        
        return df
    
    def get_feature_columns(self, df):
        """
        Get list of feature columns (excluding non-feature columns)
        
        Args:
            df: DataFrame with features
        
        Returns:
            List of feature column names
        """
        exclude_cols = ['timestamp', 'symbol', 'open', 'high', 'low', 'close', 'volume', 
                       'label', 'future_return']
        
        feature_cols = [col for col in df.columns if col not in exclude_cols]
        
        return feature_cols
    
    def scale_features(self, df, symbol, fit=True):
        """
        Scale features using StandardScaler or MinMaxScaler
        
        Args:
            df: DataFrame with features
            symbol: Trading pair symbol
            fit: Whether to fit the scaler (True for training, False for prediction)
        
        Returns:
            DataFrame with scaled features
        """
        feature_cols = self.get_feature_columns(df)
        
        if fit:
            # Create and fit new scaler
            if self.scaler_type == 'standard':
                scaler = StandardScaler()
            else:
                scaler = MinMaxScaler()
            
            df[feature_cols] = scaler.fit_transform(df[feature_cols])
            self.scalers[symbol] = scaler
            print(f"Fitted {self.scaler_type} scaler for {symbol}")
        else:
            # Use existing scaler
            if symbol in self.scalers:
                df[feature_cols] = self.scalers[symbol].transform(df[feature_cols])
            else:
                print(f"Warning: No scaler found for {symbol}. Features not scaled.")
        
        return df
    
    def prepare_ml_dataset(self, df, symbol, fear_greed_value=None, 
                          forward_periods=5, threshold=0.02, scale=True):
        """
        Complete pipeline to prepare dataset for ML training
        
        Args:
            df: Raw OHLCV DataFrame
            symbol: Trading pair symbol
            fear_greed_value: Current Fear & Greed Index
            forward_periods: Periods to look ahead for labels
            threshold: Price change threshold for labels
            scale: Whether to scale features
        
        Returns:
            Tuple of (X, y, feature_names, processed_df)
        """
        print(f"\n{'='*60}")
        print(f"Preparing ML dataset for {symbol}")
        print(f"{'='*60}")
        
        # Calculate features
        df = self.calculate_all_features(df, fear_greed_value)
        
        # Create labels
        df = self.create_labels(df, forward_periods, threshold)
        
        # Get feature columns
        feature_cols = self.get_feature_columns(df)
        
        # Scale features
        if scale:
            df = self.scale_features(df, symbol, fit=True)
        
        # Prepare X and y
        X = df[feature_cols].values
        y = df['label'].values
        
        print(f"\nDataset prepared:")
        print(f"  X shape: {X.shape}")
        print(f"  y shape: {y.shape}")
        print(f"  Features: {len(feature_cols)}")
        
        return X, y, feature_cols, df


def main():
    """Test the feature engineer"""
    from data_collector_yf import DataCollectorYF
    
    # Initialize data collector
    collector = DataCollectorYF(
        symbols=['BTC-USD'],
        data_dir='./data'
    )
    
    # Fetch historical data
    print("Fetching historical data...")
    df = collector.fetch_historical_ohlcv('BTC-USD', period='1y', interval='1h')
    
    # Get Fear & Greed Index
    fng = collector.fetch_fear_greed_index()
    fng_value = fng['value'] if fng else None
    
    # Initialize feature engineer
    engineer = FeatureEngineer(scaler_type='standard')
    
    # Prepare ML dataset
    X, y, feature_names, processed_df = engineer.prepare_ml_dataset(
        df=df,
        symbol='BTC-USD',
        fear_greed_value=fng_value,
        forward_periods=5,
        threshold=0.02,
        scale=True
    )
    
    # Display sample features
    print(f"\n{'='*60}")
    print("Sample features (first 5 records):")
    print(f"{'='*60}")
    print(processed_df[feature_names[:10]].head())
    
    print(f"\n{'='*60}")
    print("Feature engineering tests completed!")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
