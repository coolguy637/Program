# Cryptocurrency Trading Algorithm Research Notes

## Data Sources and APIs

### Market Data APIs

#### Binance API
- **Base Endpoints**: 
  - https://api.binance.com (primary)
  - https://data-api.binance.vision (market data only)
- **Features**:
  - REST API for spot trading
  - WebSocket streams for real-time data
  - Historical kline/candlestick data
  - Order book data
  - Trade execution capabilities
- **Authentication**: HMAC, RSA, Ed25519 keys
- **Response Format**: JSON (default)
- **Rate Limits**: 10-second timeout per request
- **Supported Coins**: BTC, BNB, LTC, MKR (all available on Binance)

#### CoinGecko API
- Free tier available for market data
- Historical price data
- Market cap and volume data

#### Alternative Data Sources
- CryptoCompare API
- Messari API

### Sentiment Analysis APIs

#### Augmento.ai
- AI-powered sentiment data for Bitcoin and crypto
- Social media sentiment quantification
- Designed for institutional use

#### The Tie
- 7+ years of Twitter sentiment history
- 500+ tokens coverage
- Minute-level granularity
- Point-in-time sentiment data

#### Stockgeist.ai
- Real-time crypto sentiment REST API
- Social media sentiment tracking

#### Alternative.me Fear & Greed Index
- Free crypto market sentiment indicator
- Combines multiple factors:
  - Volatility (25%)
  - Market momentum/volume (25%)
  - Social media (15%)
  - Surveys (15%)
  - Dominance (10%)
  - Trends (10%)

#### Santiment
- Social trends and sentiment analysis
- Trending coins detection
- Multi-timeframe topic analysis

### Machine Learning Considerations
- Historical price data: Binance API (klines endpoint)
- Technical indicators: Calculate from OHLCV data
- Sentiment features: Fear & Greed Index, social media sentiment
- Training data: Minimum 1-2 years of historical data recommended

## Next Steps
1. Design algorithm architecture
2. Select specific APIs to integrate
3. Define technical indicators to use
4. Design ML model architecture


## Machine Learning Research Findings

### Best Performing Models (from arXiv paper 2407.18334)

The comprehensive study evaluated **41 machine learning models** (21 classifiers, 20 regressors) for Bitcoin algorithmic trading.

**Top Performers**:
- **Random Forest**: Excellent for profit and risk management
- **Stochastic Gradient Descent (SGD)**: Strong performance in trading metrics
- **Support Vector Machine (SVM)**: High accuracy, especially during market turmoil
- **XGBoost/LightGBM**: Strong ensemble performance
- **K-Nearest Neighbors (KNN)**: Good overall performance

### Evaluation Metrics Used
- **ML Metrics**: MAE (Mean Absolute Error), RMSE (Root Mean Squared Error), R-squared
- **Trading Metrics**: P&L percentage, Sharpe Ratio, Maximum Drawdown
- **Testing**: Backtesting + Forward testing + Real-world scenarios

### Model Architectures

#### Deep Learning Approaches
- **LSTM (Long Short-Term Memory)**: Most popular for time series prediction
- **GRU (Gated Recurrent Unit)**: Alternative to LSTM, faster training
- **Bi-LSTM**: Bidirectional LSTM for better context
- **Hybrid LSTM+XGBoost**: Combines sequential learning with ensemble methods

#### Reinforcement Learning
- **Deep Q-Networks (DQN)**: For trading decision optimization
- **Policy Gradient Methods**: Direct strategy optimization
- **Actor-Critic Models**: Balance exploration and exploitation

### Feature Engineering

**Technical Indicators**:
- Moving Averages (SMA, EMA)
- RSI (Relative Strength Index)
- MACD (Moving Average Convergence Divergence)
- Bollinger Bands
- Volume indicators
- Momentum indicators

**Market Features**:
- OHLCV data (Open, High, Low, Close, Volume)
- Price changes and returns
- Volatility measures
- Order book depth

**Sentiment Features**:
- Social media sentiment scores
- Fear & Greed Index
- News sentiment
- Twitter/X mentions and trends

### Recommended Approach for Our Algorithm

1. **Primary Model**: Random Forest or XGBoost for classification (Buy/Sell/Hold signals)
2. **Secondary Model**: LSTM for price prediction and trend analysis
3. **Ensemble Strategy**: Combine multiple models for robust predictions
4. **Feature Set**: Technical indicators + Sentiment data + Historical prices
5. **Training**: Use 70-80% historical data for training, 20-30% for testing
6. **Validation**: Implement walk-forward optimization and backtesting
