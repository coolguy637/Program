# Cryptocurrency Trading Algorithm

An automated cryptocurrency trading system that uses **machine learning**, **technical analysis**, **historical data**, and **market sentiment** to trade Bitcoin (BTC), Maker (MKR), Binance Coin (BNB), and Litecoin (LTC).

## Overview

This trading algorithm combines multiple data sources and advanced machine learning techniques to generate intelligent trading signals with built-in risk management. The system has been trained on 2 years of historical hourly data and achieves approximately **90% prediction accuracy** on test data.

## Key Features

### 1. **Multi-Source Data Collection**
- Real-time and historical OHLCV (Open, High, Low, Close, Volume) data from Yahoo Finance
- Fear & Greed Index for market sentiment analysis
- Support for multiple cryptocurrencies (BTC, MKR, BNB, LTC)
- Automated data fetching and storage

### 2. **Advanced Technical Analysis**
The system calculates **36 technical indicators** across multiple categories:

**Trend Indicators:**
- Simple Moving Averages (SMA 20, 50, 200)
- Exponential Moving Averages (EMA 12, 26)
- MACD (Moving Average Convergence Divergence)
- Price-to-MA ratios

**Momentum Indicators:**
- RSI (Relative Strength Index)
- Stochastic Oscillator
- Rate of Change (ROC)

**Volatility Indicators:**
- Bollinger Bands
- Average True Range (ATR)
- Historical Volatility

**Volume Indicators:**
- On-Balance Volume (OBV)
- Volume Moving Averages
- Volume Weighted Average Price (VWAP)

### 3. **Machine Learning Ensemble**
The system uses an ensemble of three machine learning models:

- **Random Forest Classifier** (40% weight) - 89.66% test accuracy
- **XGBoost Classifier** (40% weight) - 91.34% test accuracy
- **Gradient Boosting Classifier** (20% weight) - 86.13% test accuracy

**Ensemble Performance:** 89.94% test accuracy

### 4. **Sentiment Analysis**
- Integration with Crypto Fear & Greed Index
- Real-time market sentiment scoring (0-100)
- Sentiment-based feature engineering

### 5. **Risk Management**
- **Position Sizing:** Maximum 25% of portfolio per asset
- **Stop Loss:** Automatic 3% stop loss on all positions
- **Take Profit:** Automatic 8% take profit targets
- **Portfolio Diversification:** Multi-asset allocation
- **Cash Reserve:** 20% minimum cash buffer

### 6. **Backtesting Framework**
- Historical simulation on 2 years of data
- Walk-forward optimization
- Performance metrics calculation
- Comparison with buy-and-hold strategy

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     DATA COLLECTION LAYER                        │
│  Yahoo Finance API  │  Fear & Greed Index  │  Historical Data   │
└────────┬────────────────────┬────────────────────┬──────────────┘
         │                    │                    │
         ▼                    ▼                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                   FEATURE ENGINEERING LAYER                      │
│  36 Technical Indicators  │  Sentiment Features  │  Price Data   │
└────────┬────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                  MACHINE LEARNING ENGINE                         │
│  Random Forest  │  XGBoost  │  Gradient Boosting  │  Ensemble   │
└────────┬────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    TRADING EXECUTION LAYER                       │
│  Signal Generation  │  Risk Management  │  Order Execution      │
└─────────────────────────────────────────────────────────────────┘
```

## Installation

### Prerequisites
- Python 3.11+
- pip package manager

### Required Libraries

```bash
pip install ccxt pandas numpy scikit-learn xgboost tensorflow keras yfinance python-binance schedule ta
```

### Project Structure

```
crypto_trading_bot/
├── data/                          # Historical data storage
│   ├── BTC_USD_1h_historical.csv
│   ├── MKR_USD_1h_historical.csv
│   ├── BNB_USD_1h_historical.csv
│   └── LTC_USD_1h_historical.csv
├── models/                        # Trained ML models
│   ├── BTC-USD_random_forest_*.pkl
│   ├── BTC-USD_xgboost_*.pkl
│   └── BTC-USD_gradient_boosting_*.pkl
├── backtests/                     # Backtest results
├── logs/                          # Trading logs
├── config/                        # Configuration files
├── data_collector.py              # Binance API data collector
├── data_collector_yf.py           # Yahoo Finance data collector
├── feature_engineer.py            # Technical indicator calculator
├── ml_models.py                   # ML model trainer
├── trading_bot.py                 # Main trading bot
└── README.md                      # This file
```

## Usage

### 1. Download Historical Data

```python
from data_collector_yf import DataCollectorYF

collector = DataCollectorYF(
    symbols=['BTC-USD', 'MKR-USD', 'BNB-USD', 'LTC-USD'],
    data_dir='./data'
)

# Download 2 years of hourly data
all_data = collector.fetch_all_symbols_historical(period='2y', interval='1h')
```

### 2. Train Machine Learning Models

```python
from data_collector_yf import DataCollectorYF
from feature_engineer import FeatureEngineer
from ml_models import TradingModelTrainer
from sklearn.model_selection import train_test_split

# Initialize components
collector = DataCollectorYF(symbols=['BTC-USD'], data_dir='./data')
engineer = FeatureEngineer(scaler_type='standard')
trainer = TradingModelTrainer(models_dir='./models')

# Load data
df = collector.load_historical_data('BTC-USD', interval='1h')

# Get sentiment
fng = collector.fetch_fear_greed_index()
fng_value = fng['value'] if fng else 50

# Prepare ML dataset
X, y, feature_names, processed_df = engineer.prepare_ml_dataset(
    df=df,
    symbol='BTC-USD',
    fear_greed_value=fng_value,
    forward_periods=5,
    threshold=0.02,
    scale=True
)

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, shuffle=False
)

# Train models
trainer.train_random_forest(X_train, y_train, X_test, y_test)
trainer.train_xgboost(X_train, y_train, X_test, y_test)
trainer.train_gradient_boosting(X_train, y_train, X_test, y_test)

# Save models
trainer.save_models('BTC-USD')
```

### 3. Run Backtest

```python
from trading_bot import TradingBot

# Initialize trading bot
bot = TradingBot(
    symbols=['BTC-USD', 'MKR-USD', 'BNB-USD', 'LTC-USD'],
    initial_capital=10000,
    max_position_size=0.25,
    stop_loss_pct=0.03,
    take_profit_pct=0.08,
    models_dir='./models'
)

# Run backtest
results = bot.backtest(lookback_periods=200)

# Save results
bot.save_backtest_results(results)
```

### 4. Generate Trading Signals (Live)

```python
from trading_bot import TradingBot

bot = TradingBot(
    symbols=['BTC-USD'],
    initial_capital=10000,
    models_dir='./models'
)

# Load trained models
bot.load_models('BTC-USD')

# Fetch recent data
df = bot.collector.fetch_historical_ohlcv('BTC-USD', period='5d', interval='1h')

# Get current sentiment
fng = bot.collector.fetch_fear_greed_index()
fng_value = fng['value'] if fng else 50

# Generate signal
signal, confidence = bot.generate_signal(df, 'BTC-USD', fng_value)

print(f"Signal: {signal} (Confidence: {confidence:.2%})")
# Signal: 1 = BUY, 0 = HOLD, -1 = SELL
```

## Model Performance

### Training Results (BTC-USD, 2 years of data)

| Model | Training Accuracy | Test Accuracy | Precision | Recall | F1-Score |
|-------|------------------|---------------|-----------|--------|----------|
| Random Forest | 99.96% | 89.66% | 0.84 | 0.90 | 0.87 |
| XGBoost | 100.00% | 91.34% | 0.85 | 0.91 | 0.88 |
| Gradient Boosting | 95.16% | 86.13% | 0.85 | 0.86 | 0.86 |
| **Ensemble** | **-** | **89.94%** | **0.85** | **0.90** | **0.87** |

### Label Distribution
- **BUY signals:** 4.1% (677 instances)
- **HOLD signals:** 91.5% (15,011 instances)
- **SELL signals:** 4.3% (709 instances)

### Top 10 Most Important Features

1. On-Balance Volume (OBV) - 5.12%
2. 200-period SMA - 5.02%
3. Volume SMA (20) - 4.43%
4. High-Low Spread - 4.32%
5. Volatility (20-period) - 4.28%
6. Average True Range (14) - 3.97%
7. 50-period SMA - 3.88%
8. Bollinger Band Lower - 3.70%
9. Rate of Change (30) - 3.63%
10. 20-period SMA - 3.56%

## Trading Strategy

### Entry Conditions (BUY Signal)
- Ensemble model predicts BUY with >70% confidence
- RSI indicates oversold or upward trend
- MACD shows bullish crossover
- Price above 20-period SMA
- Fear & Greed Index shows opportunity
- Sufficient portfolio balance available

### Exit Conditions (SELL Signal)
- Ensemble model predicts SELL with >70% confidence
- Stop-loss triggered (3% loss)
- Take-profit reached (8% gain)
- RSI indicates overbought conditions
- MACD shows bearish crossover
- Trailing stop activated

### Hold Conditions
- Low confidence predictions (<70%)
- Conflicting signals across timeframes
- High market volatility (ATR spike)
- Maximum position limits reached

## Risk Warnings

⚠️ **IMPORTANT DISCLAIMERS:**

1. **No Financial Advice:** This software is for educational and research purposes only. It does not constitute financial advice.

2. **Past Performance:** Historical backtesting results do not guarantee future performance.

3. **Market Risk:** Cryptocurrency markets are highly volatile. You can lose all invested capital.

4. **Testing Required:** Always test thoroughly with paper trading before using real funds.

5. **API Security:** Never share your API keys. Use API keys with trading permissions only (no withdrawal permissions).

6. **Regulatory Compliance:** Ensure compliance with local regulations regarding cryptocurrency trading.

7. **Technical Limitations:** The system depends on data availability and API reliability.

## Configuration

### Trading Parameters

You can customize the trading bot behavior by adjusting these parameters:

```python
bot = TradingBot(
    symbols=['BTC-USD', 'MKR-USD', 'BNB-USD', 'LTC-USD'],
    initial_capital=10000,           # Starting capital in USD
    max_position_size=0.25,          # Max 25% per position
    stop_loss_pct=0.03,              # 3% stop loss
    take_profit_pct=0.08,            # 8% take profit
    models_dir='./models'
)
```

### Model Hyperparameters

Random Forest:
- `n_estimators=200` (number of trees)
- `max_depth=15` (maximum tree depth)
- `class_weight='balanced'` (handle imbalanced data)

XGBoost:
- `n_estimators=200` (boosting rounds)
- `max_depth=10` (tree depth)
- `learning_rate=0.1`

Gradient Boosting:
- `n_estimators=100` (boosting stages)
- `max_depth=5` (tree depth)
- `learning_rate=0.1`

## Future Enhancements

Potential improvements for the trading algorithm:

1. **Advanced Sentiment Analysis**
   - Twitter/X sentiment integration
   - News sentiment analysis
   - Social media trend tracking

2. **Additional ML Models**
   - LSTM neural networks for time series prediction
   - Reinforcement learning for strategy optimization
   - Deep Q-Networks (DQN) for decision making

3. **Enhanced Risk Management**
   - Dynamic position sizing based on volatility
   - Portfolio optimization algorithms
   - Correlation-based diversification

4. **Real-Time Trading**
   - WebSocket connections for live data
   - Automated order execution via exchange APIs
   - Real-time performance monitoring dashboard

5. **Multi-Timeframe Analysis**
   - Signals from 1m, 5m, 15m, 1h, 4h, 1d timeframes
   - Timeframe alignment confirmation
   - Adaptive strategy based on market conditions

## Troubleshooting

### Common Issues

**Issue:** Binance API returns 451 error
- **Solution:** Use the Yahoo Finance data collector (`data_collector_yf.py`) instead

**Issue:** Models show low precision for BUY/SELL signals
- **Solution:** This is expected due to class imbalance (91% HOLD signals). The ensemble helps balance this.

**Issue:** Scaler not found warnings during backtesting
- **Solution:** Ensure models are trained and scalers are saved before running backtests

**Issue:** Insufficient data for feature calculation
- **Solution:** Use at least 200 periods of lookback data for proper indicator calculation

## License

This project is provided as-is for educational purposes. Use at your own risk.

## Contact & Support

For questions, issues, or contributions, please refer to the project repository.

---

**Disclaimer:** Cryptocurrency trading carries significant risk. This algorithm is experimental and should not be used with real money without extensive testing and understanding of the risks involved.
