"""
Alternative Data Collection Module using yfinance
For testing when Binance API is restricted
"""

import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import os


class DataCollectorYF:
    """Collects market data using yfinance (Yahoo Finance)"""
    
    def __init__(self, symbols=['BTC-USD', 'MKR-USD', 'BNB-USD', 'LTC-USD'], 
                 data_dir='./data'):
        """
        Initialize the data collector
        
        Args:
            symbols: List of ticker symbols (Yahoo Finance format)
            data_dir: Directory to save collected data
        """
        self.symbols = symbols
        self.data_dir = data_dir
        
        # Create data directory if it doesn't exist
        os.makedirs(data_dir, exist_ok=True)
        
        print(f"DataCollectorYF initialized for {symbols}")
    
    def fetch_historical_ohlcv(self, symbol, period='2y', interval='1h'):
        """
        Fetch historical OHLCV data from Yahoo Finance
        
        Args:
            symbol: Ticker symbol (e.g., 'BTC-USD')
            period: Time period ('1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', 'max')
            interval: Data interval ('1m', '2m', '5m', '15m', '30m', '60m', '1h', '1d', '1wk', '1mo')
        
        Returns:
            pandas DataFrame with OHLCV data
        """
        try:
            print(f"Fetching historical data for {symbol}...")
            ticker = yf.Ticker(symbol)
            df = ticker.history(period=period, interval=interval)
            
            if df.empty:
                print(f"No data returned for {symbol}")
                return pd.DataFrame()
            
            # Rename columns to match our format
            df = df.reset_index()
            df.columns = [col.lower() for col in df.columns]
            
            # Rename datetime/date column to timestamp
            if 'datetime' in df.columns:
                df = df.rename(columns={'datetime': 'timestamp'})
            elif 'date' in df.columns:
                df = df.rename(columns={'date': 'timestamp'})
            
            # Add symbol column
            df['symbol'] = symbol
            
            # Select relevant columns
            df = df[['timestamp', 'open', 'high', 'low', 'close', 'volume', 'symbol']]
            
            print(f"Fetched {len(df)} candles for {symbol}")
            return df
            
        except Exception as e:
            print(f"Error fetching data for {symbol}: {e}")
            return pd.DataFrame()
    
    def fetch_all_symbols_historical(self, period='2y', interval='1h'):
        """
        Fetch historical data for all configured symbols
        
        Args:
            period: Time period to fetch
            interval: Data interval
        
        Returns:
            Dictionary with symbol as key and DataFrame as value
        """
        all_data = {}
        
        for symbol in self.symbols:
            print(f"\n{'='*60}")
            print(f"Collecting data for {symbol}")
            print(f"{'='*60}")
            
            df = self.fetch_historical_ohlcv(symbol, period=period, interval=interval)
            
            if not df.empty:
                # Save to CSV
                filename = f"{self.data_dir}/{symbol.replace('-', '_')}_{interval}_historical.csv"
                df.to_csv(filename, index=False)
                print(f"Saved {len(df)} records to {filename}")
                
                all_data[symbol] = df
            else:
                print(f"No data collected for {symbol}")
        
        return all_data
    
    def fetch_current_price(self, symbol):
        """
        Fetch current ticker price for a symbol
        
        Args:
            symbol: Ticker symbol
        
        Returns:
            Dictionary with price information
        """
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            
            return {
                'symbol': symbol,
                'price': info.get('regularMarketPrice', info.get('currentPrice', 0)),
                'volume': info.get('regularMarketVolume', info.get('volume', 0)),
                'timestamp': datetime.now()
            }
        except Exception as e:
            print(f"Error fetching current price for {symbol}: {e}")
            return None
    
    def fetch_fear_greed_index(self):
        """
        Fetch Fear & Greed Index from alternative.me
        
        Returns:
            Dictionary with fear & greed data
        """
        try:
            url = "https://api.alternative.me/fng/?limit=1"
            response = requests.get(url, timeout=10)
            data = response.json()
            
            if 'data' in data and len(data['data']) > 0:
                fng_data = data['data'][0]
                return {
                    'value': int(fng_data['value']),
                    'classification': fng_data['value_classification'],
                    'timestamp': datetime.fromtimestamp(int(fng_data['timestamp']))
                }
            else:
                return None
                
        except Exception as e:
            print(f"Error fetching Fear & Greed Index: {e}")
            return None
    
    def get_market_summary(self):
        """
        Get current market summary for all symbols
        
        Returns:
            pandas DataFrame with market summary
        """
        summary_data = []
        
        for symbol in self.symbols:
            price_data = self.fetch_current_price(symbol)
            if price_data:
                summary_data.append(price_data)
        
        # Add Fear & Greed Index
        fng = self.fetch_fear_greed_index()
        
        df = pd.DataFrame(summary_data)
        
        if fng:
            df['fear_greed_value'] = fng['value']
            df['fear_greed_class'] = fng['classification']
        
        return df
    
    def load_historical_data(self, symbol, interval='1h'):
        """
        Load historical data from saved CSV file
        
        Args:
            symbol: Ticker symbol
            interval: Data interval
        
        Returns:
            pandas DataFrame
        """
        filename = f"{self.data_dir}/{symbol.replace('-', '_')}_{interval}_historical.csv"
        
        if os.path.exists(filename):
            df = pd.read_csv(filename)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            print(f"Loaded {len(df)} records from {filename}")
            return df
        else:
            print(f"File not found: {filename}")
            return pd.DataFrame()


def main():
    """Test the data collector"""
    
    # Initialize collector
    collector = DataCollectorYF(
        symbols=['BTC-USD', 'MKR-USD', 'BNB-USD', 'LTC-USD'],
        data_dir='./data'
    )
    
    # Test 1: Fetch recent data
    print("\n" + "="*60)
    print("TEST 1: Fetching recent OHLCV data")
    print("="*60)
    df = collector.fetch_historical_ohlcv('BTC-USD', period='5d', interval='1h')
    print(df.head())
    print(f"\nData shape: {df.shape}")
    
    # Test 2: Fetch current prices
    print("\n" + "="*60)
    print("TEST 2: Fetching current prices")
    print("="*60)
    summary = collector.get_market_summary()
    print(summary)
    
    # Test 3: Fetch Fear & Greed Index
    print("\n" + "="*60)
    print("TEST 3: Fetching Fear & Greed Index")
    print("="*60)
    fng = collector.fetch_fear_greed_index()
    if fng:
        print(f"Value: {fng['value']}, Classification: {fng['classification']}")
    
    print("\n" + "="*60)
    print("Data collection tests completed!")
    print("="*60)


if __name__ == "__main__":
    main()
