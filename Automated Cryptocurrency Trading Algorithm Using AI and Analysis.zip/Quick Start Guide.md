# Quick Start Guide

Get started with the Cryptocurrency Trading Algorithm in 5 simple steps.

## Step 1: Install Dependencies

```bash
pip install ccxt pandas numpy scikit-learn xgboost tensorflow keras yfinance python-binance schedule ta
```

## Step 2: Download Historical Data

Run this command to download 2 years of hourly data for all cryptocurrencies:

```bash
cd crypto_trading_bot
python3.11 -c "
from data_collector_yf import DataCollectorYF

collector = DataCollectorYF(
    symbols=['BTC-USD', 'MKR-USD', 'BNB-USD', 'LTC-USD'],
    data_dir='./data'
)

all_data = collector.fetch_all_symbols_historical(period='2y', interval='1h')
print(f'Downloaded data for {len(all_data)} symbols')
"
```

**Expected output:**
```
Fetched 17389 candles for BTC-USD
Saved 17389 records to ./data/BTC_USD_1h_historical.csv
...
Downloaded data for 4 symbols
```

## Step 3: Train Machine Learning Models

Train the ensemble models on Bitcoin data:

```bash
python3.11 ml_models.py
```

**Expected output:**
```
Training Random Forest Classifier
Test Accuracy: 0.8966

Training XGBoost Classifier  
Test Accuracy: 0.9134

Training Gradient Boosting Classifier
Test Accuracy: 0.8613

Ensemble Test Accuracy: 0.8994
```

This will create trained model files in the `./models/` directory.

## Step 4: Run Backtest

Test the algorithm on historical data:

```bash
python3.11 simple_backtest.py
```

**Expected output:**
```
Buy & Hold Strategy Results
Initial Capital: $10,000.00
Final Value: $9,678.32
Total Return: -3.22%
```

## Step 5: Generate Trading Signals

Generate real-time trading signals:

```python
from trading_bot import TradingBot

# Initialize bot
bot = TradingBot(
    symbols=['BTC-USD'],
    initial_capital=10000,
    models_dir='./models'
)

# Load models
bot.load_models('BTC-USD')

# Fetch recent data
df = bot.collector.fetch_historical_ohlcv('BTC-USD', period='5d', interval='1h')

# Get sentiment
fng = bot.collector.fetch_fear_greed_index()
fng_value = fng['value'] if fng else 50

# Generate signal
signal, confidence = bot.generate_signal(df, 'BTC-USD', fng_value)

if signal == 1:
    print(f"🟢 BUY signal with {confidence:.1%} confidence")
elif signal == -1:
    print(f"🔴 SELL signal with {confidence:.1%} confidence")
else:
    print(f"⚪ HOLD - No strong signal")
```

## Testing Individual Components

### Test Data Collection

```bash
python3.11 data_collector_yf.py
```

### Test Feature Engineering

```bash
python3.11 feature_engineer.py
```

### Test ML Models

```bash
python3.11 ml_models.py
```

## Next Steps

1. **Review the full README.md** for detailed documentation
2. **Customize trading parameters** in the TradingBot initialization
3. **Train models for other cryptocurrencies** (MKR, BNB, LTC)
4. **Implement paper trading** before using real funds
5. **Set up monitoring and alerts** for live trading

## Important Reminders

⚠️ **Before Live Trading:**
- Test extensively with paper trading
- Start with small amounts
- Understand the risks involved
- Never invest more than you can afford to lose
- Keep API keys secure (no withdrawal permissions)

## Getting Help

If you encounter issues:
1. Check the Troubleshooting section in README.md
2. Verify all dependencies are installed correctly
3. Ensure you have sufficient historical data
4. Review error messages carefully

---

**Happy Trading! 🚀**

*Remember: This is for educational purposes. Always do your own research and trade responsibly.*
