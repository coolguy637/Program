import pandas as pd
from data_collector import DataCollector
from ta_engine import TAEngine
from ml_model import MLModel
from sentiment_analyzer import SentimentAnalyzer
from options_evaluator import OptionsEvaluator
import time

# Top 30 Optionable Stocks
TICKERS = [
    "NVDA", "AAPL", "GOOG", "MSFT", "AMZN", "TSM", "META", "TSLA", "AVGO", "BRK-B",
    "WMT", "LLY", "JPM", "XOM", "V", "JNJ", "ASML", "MU", "MA", "ORCL",
    "COST", "ABBV", "HD", "BAC", "PG", "BABA", "CVX", "CAT", "KO", "AMD"
]

def run_bot():
    print("🚀 Starting Trading Bot Analysis...")
    collector = DataCollector(TICKERS)
    ml = MLModel()
    
    results = []

    for ticker in TICKERS:
        print(f"Analyzing {ticker}...")
        try:
            # 1. Collect Data
            df = collector.get_stock_data(ticker)
            if df is None or df.empty: continue
            
            # 2. Technical Analysis
            df_ta = TAEngine.add_indicators(df)
            ta_signal = TAEngine.get_signals(df_ta)
            
            # 3. Machine Learning Prediction
            prediction = ml.train_and_predict(df_ta)
            if not prediction: continue
            
            # 4. Sentiment Analysis
            headlines = collector.get_news_headlines(ticker)
            sentiment_score = SentimentAnalyzer.analyze_sentiment(headlines)
            sentiment_label = SentimentAnalyzer.get_sentiment_label(sentiment_score)
            
            # 5. Options Evaluation
            options_chain = collector.get_options_chain(ticker)
            if not options_chain: continue
            
            evaluator = OptionsEvaluator(
                current_price=df['Close'].iloc[-1],
                predicted_change=prediction['pct_change'],
                sentiment_score=sentiment_score
            )
            
            opt_result = evaluator.evaluate_contracts(options_chain)
            
            if opt_result and opt_result['best_contract'] is not None:
                best = opt_result['best_contract']
                results.append({
                    'Ticker': ticker,
                    'Price': round(df['Close'].iloc[-1], 2),
                    'TA Signal': ta_signal,
                    'ML Pred %': f"{prediction['pct_change']*100:.2f}%",
                    'Sentiment': sentiment_label,
                    'Option Type': opt_result['type'],
                    'Strike': best['strike'],
                    'Exp': options_chain['expiration'],
                    'Last Price': best['lastPrice'],
                    'Score': round(best['attractiveness_score'], 2)
                })
            
            # Rate limiting / polite fetching
            time.sleep(1)
            
        except Exception as e:
            print(f"Error analyzing {ticker}: {e}")

    # Display Results
    if results:
        results_df = pd.DataFrame(results)
        # Sort by score
        results_df = results_df.sort_values(by='Score', ascending=False)
        
        print("\n" + "="*50)
        print("🔥 TOP OPTIONS OPPORTUNITIES 🔥")
        print("="*50)
        print(results_df.to_string(index=False))
        
        # Save to CSV
        results_df.to_csv("trading_signals.csv", index=False)
        print(f"\nResults saved to trading_signals.csv")
    else:
        print("No significant opportunities found.")

if __name__ == "__main__":
    run_bot()
