import pandas as pd
from ta.momentum import RSIIndicator
from ta.trend import MACD, SMAIndicator
from ta.volatility import BollingerBands

class TAEngine:
    @staticmethod
    def add_indicators(df):
        """Add TA indicators to the dataframe."""
        if df is None or len(df) < 50:
            return None
        
        # Ensure we have a copy to avoid SettingWithCopyWarning
        df = df.copy()
        
        # RSI
        df['RSI'] = RSIIndicator(close=df['Close']).rsi()
        
        # MACD
        macd = MACD(close=df['Close'])
        df['MACD'] = macd.macd()
        df['MACD_Signal'] = macd.macd_signal()
        
        # Moving Averages
        df['SMA_50'] = SMAIndicator(close=df['Close'], window=50).sma_indicator()
        df['SMA_200'] = SMAIndicator(close=df['Close'], window=200).sma_indicator()
        
        # Bollinger Bands
        bb = BollingerBands(close=df['Close'])
        df['BB_High'] = bb.bollinger_hband()
        df['BB_Low'] = bb.bollinger_lband()
        
        # Drop rows with NaN values created by indicators
        return df.dropna()

    @staticmethod
    def get_signals(df):
        """Generate simple signals based on TA."""
        if df is None or len(df) == 0:
            return "Neutral"
        
        last_row = df.iloc[-1]
        
        # Simple Bullish/Bearish logic
        bullish_score = 0
        if last_row['RSI'] < 30: bullish_score += 1  # Oversold
        if last_row['MACD'] > last_row['MACD_Signal']: bullish_score += 1
        if last_row['Close'] > last_row['SMA_50']: bullish_score += 1
        
        bearish_score = 0
        if last_row['RSI'] > 70: bearish_score += 1  # Overbought
        if last_row['MACD'] < last_row['MACD_Signal']: bearish_score += 1
        if last_row['Close'] < last_row['SMA_50']: bearish_score += 1
        
        if bullish_score > bearish_score:
            return "Bullish"
        elif bearish_score > bullish_score:
            return "Bearish"
        else:
            return "Neutral"
