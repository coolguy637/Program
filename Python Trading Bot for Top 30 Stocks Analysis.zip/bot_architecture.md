# Trading Bot Architecture

## Overview
The bot is designed to analyze the top 30 stocks by market capitalization using a multi-factor approach: technical analysis, machine learning for price prediction, and sentiment analysis. It then evaluates available options contracts to find the best risk-reward opportunities.

## Modules

### 1. Data Collection (`data_collector.py`)
- **Stock Data**: Fetch historical price data (OHLCV) using `yfinance`.
- **Options Data**: Fetch options chains (calls/puts, strike prices, expirations, Greeks, implied volatility) using `yfinance`.
- **News/Sentiment Data**: Fetch recent news headlines using `yfinance` or web scraping (e.g., Google News).

### 2. Technical Analysis (`ta_engine.py`)
- Calculate indicators: RSI, MACD, Moving Averages (50, 200), Bollinger Bands, ATR.
- Generate signals based on TA patterns.

### 3. Machine Learning (`ml_model.py`)
- **Model**: Random Forest Regressor or LSTM (Random Forest is more robust for a general script).
- **Features**: Historical prices, TA indicators, volume trends.
- **Target**: Predicted price change over the next 5-10 trading days.

### 4. Sentiment Analysis (`sentiment_analyzer.py`)
- Use `nltk.sentiment.vader` or `textblob` to analyze news headlines.
- Aggregate sentiment scores for each stock.

### 5. Options Evaluator (`options_evaluator.py`)
- Filter options based on:
  - Expiration (e.g., 30-45 days out).
  - Moneyness (Near-the-money).
  - Liquidity (Open Interest, Volume).
- Calculate "Best Value" based on predicted price move vs. option premium and Greeks (Delta, Theta).

### 6. Main Controller (`main.py`)
- Orchestrate the workflow: Data -> TA -> ML -> Sentiment -> Options Ranking -> Output.

## Required Libraries
- `yfinance`: Financial data.
- `pandas`, `numpy`: Data manipulation.
- `pandas_ta`: Technical analysis indicators.
- `scikit-learn`: Machine learning.
- `nltk`: Sentiment analysis.
- `matplotlib`: Visualization (optional).
