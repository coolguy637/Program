import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class DataCollector:
    def __init__(self, tickers):
        self.tickers = tickers

    def get_stock_data(self, ticker, period="2y", interval="1d"):
        """Fetch historical stock price data."""
        try:
            stock = yf.Ticker(ticker)
            df = stock.history(period=period, interval=interval)
            return df
        except Exception as e:
            print(f"Error fetching stock data for {ticker}: {e}")
            return None

    def get_options_chain(self, ticker):
        """Fetch the options chain for a given ticker."""
        try:
            stock = yf.Ticker(ticker)
            expirations = stock.options
            if not expirations:
                return None
            
            # Target expiration between 30 and 60 days
            target_date = datetime.now() + timedelta(days=45)
            # Find the closest expiration date
            closest_exp = min(expirations, key=lambda x: abs(datetime.strptime(x, '%Y-%m-%d') - target_date))
            
            opt_chain = stock.option_chain(closest_exp)
            return {
                'expiration': closest_exp,
                'calls': opt_chain.calls,
                'puts': opt_chain.puts
            }
        except Exception as e:
            print(f"Error fetching options for {ticker}: {e}")
            return None

    def get_news_headlines(self, ticker):
        """Fetch recent news headlines for sentiment analysis."""
        try:
            stock = yf.Ticker(ticker)
            news = stock.news
            headlines = []
            for item in news:
                # Handle both old and new yfinance news structures
                if 'title' in item:
                    headlines.append(item['title'])
                elif 'content' in item and 'title' in item['content']:
                    headlines.append(item['content']['title'])
            return headlines
        except Exception as e:
            print(f"Error fetching news for {ticker}: {e}")
            return []

if __name__ == "__main__":
    # Test with a single ticker
    collector = DataCollector(["AAPL"])
    data = collector.get_stock_data("AAPL")
    print(f"Stock data shape: {data.shape}")
    options = collector.get_options_chain("AAPL")
    if options:
        print(f"Options expiration: {options['expiration']}")
        print(f"Calls count: {len(options['calls'])}")
    news = collector.get_news_headlines("AAPL")
    print(f"News headlines: {len(news)}")
