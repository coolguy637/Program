import yfinance as yf
ticker = yf.Ticker("AAPL")
print(ticker.news[0] if ticker.news else "No news")
