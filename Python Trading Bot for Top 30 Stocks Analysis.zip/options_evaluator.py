import pandas as pd
import numpy as np

class OptionsEvaluator:
    def __init__(self, current_price, predicted_change, sentiment_score):
        self.current_price = current_price
        self.predicted_change = predicted_change # % change
        self.sentiment_score = sentiment_score

    def evaluate_contracts(self, options_chain):
        """Evaluate and rank options contracts."""
        if not options_chain:
            return None
        
        # Determine strategy: Call if bullish, Put if bearish
        # We combine ML prediction and sentiment for direction
        total_score = self.predicted_change + (self.sentiment_score * 0.05) # Weight sentiment
        
        is_bullish = total_score > 0.01 # Expecting > 1% move
        is_bearish = total_score < -0.01 # Expecting < -1% move
        
        contracts = options_chain['calls'] if is_bullish else options_chain['puts']
        
        if contracts.empty:
            return None

        # Filter for Near-The-Money (NTM) options (within 5% of current price)
        # and reasonable liquidity (volume > 10)
        contracts = contracts.copy()
        contracts['distance_to_strike'] = abs(contracts['strike'] - self.current_price) / self.current_price
        
        filtered = contracts[
            (contracts['distance_to_strike'] < 0.10) & 
            (contracts['volume'] > 5)
        ].copy()
        
        if filtered.empty:
            # Fallback to most liquid if none meet distance criteria
            filtered = contracts.sort_values(by='volume', ascending=False).head(5).copy()

        # Calculate a "Contract Score"
        # For calls: we want low premium relative to predicted move
        # For simplicity, we'll use a basic attractiveness score
        # Attractiveness = (Potential Profit / Cost) * Liquidity factor
        
        def calculate_attractiveness(row):
            cost = row['lastPrice']
            if cost == 0: return 0
            
            strike = row['strike']
            # Predicted price after the move
            pred_price = self.current_price * (1 + self.predicted_change)
            
            if is_bullish:
                potential_profit = max(0, pred_price - strike) - cost
            else:
                potential_profit = max(0, strike - pred_price) - cost
            
            roi = potential_profit / cost
            liquidity = np.log1p(row['volume'] + row['openInterest'])
            
            return roi * liquidity

        filtered['attractiveness_score'] = filtered.apply(calculate_attractiveness, axis=1)
        
        best_contracts = filtered.sort_values(by='attractiveness_score', ascending=False)
        
        return {
            'type': 'Call' if is_bullish else 'Put',
            'best_contract': best_contracts.iloc[0] if not best_contracts.empty else None,
            'direction': 'Bullish' if is_bullish else ('Bearish' if is_bearish else 'Neutral')
        }
