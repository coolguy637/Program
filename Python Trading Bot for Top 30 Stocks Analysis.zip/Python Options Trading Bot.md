# Python Options Trading Bot

This bot analyzes the top 30 US-listed stocks by market capitalization to identify potential options trading opportunities. It integrates technical analysis, machine learning for price prediction, and sentiment analysis of recent news.

## Features
- **Data Collection**: Uses `yfinance` to fetch historical stock data, options chains, and news.
- **Technical Analysis**: Calculates RSI, MACD, Moving Averages, and Bollinger Bands using the `ta` library.
- **Machine Learning**: Employs a `RandomForestRegressor` to predict price movements over a 5-day horizon.
- **Sentiment Analysis**: Analyzes news headlines using `TextBlob` to gauge market sentiment.
- **Options Evaluation**: Filters and ranks options contracts based on predicted price moves, Greeks (implied), and liquidity.

## Project Structure
- `main.py`: The entry point that orchestrates the analysis.
- `data_collector.py`: Handles all data fetching from Yahoo Finance.
- `ta_engine.py`: Contains logic for technical indicators and signal generation.
- `ml_model.py`: Implements the price prediction model.
- `sentiment_analyzer.py`: Performs NLP on news headlines.
- `options_evaluator.py`: Ranks options contracts based on a custom attractiveness score.

## How to Run
1. Install dependencies:
   ```bash
   pip install yfinance pandas numpy scikit-learn textblob ta
   ```
2. Execute the bot:
   ```bash
   python main.py
   ```

## Output
The bot prints a table of the top opportunities and saves the results to `trading_signals.csv`.

### Attractiveness Score
The score is calculated based on:
- **Potential ROI**: (Predicted Price Move - Strike - Premium) / Premium.
- **Liquidity**: Log-scaled Volume and Open Interest.
- **Sentiment Weighting**: Sentiment scores adjust the directional bias.

## Disclaimer
This bot is for educational purposes only. Trading stocks and options involves significant risk. Always perform your own due diligence before making investment decisions.
