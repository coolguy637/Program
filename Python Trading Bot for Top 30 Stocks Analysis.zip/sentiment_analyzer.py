from textblob import TextBlob
import numpy as np

class SentimentAnalyzer:
    @staticmethod
    def analyze_sentiment(headlines):
        """Calculate average sentiment score from headlines."""
        if not headlines:
            return 0.0 # Neutral
        
        scores = []
        for headline in headlines:
            analysis = TextBlob(headline)
            # Polarity is between -1.0 and 1.0
            scores.append(analysis.sentiment.polarity)
        
        return np.mean(scores)

    @staticmethod
    def get_sentiment_label(score):
        if score > 0.1:
            return "Positive"
        elif score < -0.1:
            return "Negative"
        else:
            return "Neutral"
