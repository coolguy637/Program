import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

class MLModel:
    def __init__(self):
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.feature_cols = ['Close', 'RSI', 'MACD', 'MACD_Signal', 'SMA_50', 'SMA_200', 'BB_High', 'BB_Low']

    def prepare_data(self, df, forecast_out=5):
        """Prepare features and target for prediction."""
        df = df.copy()
        # Target: Price 'forecast_out' days in the future
        df['Target'] = df['Close'].shift(-forecast_out)
        
        # Features
        X = df[self.feature_cols].values
        y = df['Target'].values
        
        # Remove last 'forecast_out' rows which have NaN target
        X_train_val = X[:-forecast_out]
        y_train_val = y[:-forecast_out]
        
        # Last row for prediction
        X_latest = X[-1:]
        
        return X_train_val, y_train_val, X_latest

    def train_and_predict(self, df, forecast_out=5):
        """Train model and predict future price."""
        try:
            X, y, X_latest = self.prepare_data(df, forecast_out)
            
            if len(X) < 100: # Not enough data to train
                return None
            
            self.model.fit(X, y)
            prediction = self.model.predict(X_latest)[0]
            
            current_price = df['Close'].iloc[-1]
            pct_change = (prediction - current_price) / current_price
            
            return {
                'predicted_price': prediction,
                'pct_change': pct_change
            }
        except Exception as e:
            print(f"ML Error: {e}")
            return None
