# Automated Metal Trading Algorithm Documentation

## 1. Introduction
This document details an automated metal trading algorithm designed to trade gold, silver, and copper. The algorithm integrates market sentiment, technical analysis, historical price data, and machine learning to generate trading signals. The primary goal is to identify potential price movements and execute trades to achieve profitable returns, while managing risk.

## 2. Algorithm Architecture
The algorithm is structured into several modular components, ensuring maintainability and scalability. The architecture encompasses data ingestion, feature engineering, machine learning model development, trading strategy formulation, and a robust backtesting framework.

### 2.1. Data Ingestion Module
This module is responsible for acquiring both historical and real-time market data. For historical price data, the `yfinance` library is utilized to fetch open, high, low, close prices, and trading volume for key metal-related exchange-traded funds (ETFs) or futures contracts. Specifically, `GLD` (SPDR Gold Shares), `SLV` (iShares Silver Trust), and `CPER` (United States Copper Index Fund) are used as proxies for gold, silver, and copper prices, respectively. Sentiment data, crucial for gauging market mood, is currently simulated using the `vaderSentiment` library, processing hypothetical news headlines. In a production environment, this would involve integrating with actual news APIs or social media feeds.

### 2.2. Feature Engineering Module
Raw market data is transformed into a rich set of features for machine learning models within this module. Technical indicators, calculated using the `ta` library, include various Moving Averages (SMA, EMA), MACD, RSI, Stochastic Oscillator, Bollinger Bands, and ATR. These indicators provide insights into price trends, momentum, and volatility. Sentiment scores, derived from the `vaderSentiment` analyzer, quantify the emotional tone of market-related text. Additionally, lagged price data and technical indicators are incorporated to capture temporal dependencies, which are vital for time-series forecasting.

### 2.3. Machine Learning Model Module
The core of the algorithm lies in its machine learning models, which predict future price movements. For this implementation, a **Random Forest Classifier** is employed. This model is trained to predict the direction of the next day's price movement (up or down). Random Forests are chosen for their ability to handle complex, non-linear relationships within financial data, their robustness to overfitting, and their interpretability. While regression models for direct price prediction and advanced deep learning models like LSTMs were considered, the classification approach for directional prediction offers a more straightforward path to generating actionable trading signals.

### 2.4. Trading Strategy Module
This module defines the rules for generating buy and sell signals based on the machine learning model's predictions. When the model predicts an upward movement (classification label 1), a buy signal is generated. Conversely, a prediction of no upward movement (classification label 0) can lead to a sell signal or holding a short position, depending on the current portfolio state. Basic risk management principles, such as position sizing and implicit stop-loss mechanisms (by selling when the prediction changes), are integrated into the strategy.

### 2.5. Backtesting and Evaluation Module
To assess the strategy's historical performance, the `Backtrader` framework is utilized. This module simulates trades on historical data, allowing for the evaluation of key performance metrics. The backtesting process helps in understanding the strategy's profitability, risk exposure, and overall effectiveness before any potential live deployment. Performance metrics such as final portfolio value are tracked to gauge success.

## 3. Implementation Details

### 3.1. Data Collection (`data_collection.py`)
The `data_collection.py` script fetches historical price data using `yfinance` and calculates technical indicators using the `ta` library. It also simulates market sentiment scores for each trading day. The processed data for each metal (GLD, SLV, CPER) is then saved into separate CSV files.

### 3.2. Model Training (`model_training.py`)
The `model_training.py` script loads the processed data, prepares it for machine learning by creating a 'Target' variable (1 for next day's price increase, 0 otherwise), and splits the data into training and testing sets. A `RandomForestClassifier` is then trained on this data. The trained model for each metal is saved using `joblib`.

### 3.3. Backtesting (`backtesting.py`)
The `backtesting.py` script implements the `MLStrategy` using `Backtrader`. This strategy loads the pre-trained machine learning model and the processed data. For each trading day in the backtesting period, it uses the model to predict the next day's price movement and executes buy or sell orders accordingly. The script then runs the backtest and reports the starting and final portfolio values.

## 4. Backtesting Results
The backtesting was performed on the last 20% of the historical data for each metal, starting with an initial cash of $10,000 and a commission of 0.1% per trade. The results are summarized below:

| Metal | Starting Portfolio Value | Final Portfolio Value |
|-------|--------------------------|-----------------------|
| GLD   | $10,000.00               | $10,012.43            |
| SLV   | $10,000.00               | $9,999.81             |
| CPER  | $10,000.00               | $10,003.14            |

The backtesting results indicate a modest positive return for GLD and CPER, while SLV showed a slight decrease. It is important to note that these results are based on simulated sentiment data and a simplified trading strategy. Further optimization and real-world sentiment data integration are necessary for more robust performance.

## 5. Usage Instructions
To run the automated metal trading algorithm:

1.  **Install Dependencies**: Ensure all required Python libraries are installed:
    ```bash
    sudo pip3 install yfinance ta scikit-learn vaderSentiment backtrader matplotlib
    ```
2.  **Collect and Preprocess Data**: Execute the data collection script:
    ```bash
    python3 /home/ubuntu/data_collection.py
    ```
    This will generate `GLD_processed.csv`, `SLV_processed.csv`, and `CPER_processed.csv` in the `/home/ubuntu/` directory.
3.  **Train Machine Learning Models**: Run the model training script:
    ```bash
    python3 /home/ubuntu/model_training.py
    ```
    This will save `GLD_model.joblib`, `SLV_model.joblib`, and `CPER_model.joblib` in the `/home/ubuntu/` directory.
4.  **Run Backtesting**: Execute the backtesting script:
    ```bash
    python3 /home/ubuntu/backtesting.py
    ```
    This will display the backtesting results for each metal.

## 6. Future Work
-   **Real-time Sentiment Integration**: Replace simulated sentiment data with actual news and social media sentiment analysis.
-   **Advanced Machine Learning Models**: Explore deep learning architectures like LSTMs for improved time-series forecasting.
-   **Optimization**: Implement hyperparameter tuning for machine learning models and strategy parameters.
-   **Risk Management**: Develop more sophisticated risk management techniques, including dynamic position sizing and portfolio diversification.
-   **Live Trading Integration**: Connect the algorithm to a brokerage API for live trading (after thorough testing and validation).

## References
[1] `yfinance` documentation: [https://pypi.org/project/yfinance/](https://pypi.org/project/yfinance/)
[2] `ta` library documentation: [https://technical-analysis-library-in-python.readthedocs.io/en/latest/](https://technical-analysis-library-in-python.readthedocs.io/en/latest/)
[3] `vaderSentiment` documentation: [https://pypi.org/project/vaderSentiment/](https://pypi.org/project/vaderSentiment/)
[4] `scikit-learn` documentation: [https://scikit-learn.org/stable/](https://scikit-learn.org/stable/)
[5] `Backtrader` documentation: [https://www.backtrader.com/](https://www.backtrader.com/)
