import yfinance as yf
import pandas as pd
import numpy as np
from ta import add_all_ta_features
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import datetime

def fetch_metal_data(tickers, start_date, end_date):
    """Fetch historical price data for given tickers."""
    data = {}
    for ticker in tickers:
        print(f"Fetching data for {ticker}...")
        df = yf.download(ticker, start=start_date, end=end_date)
        # Flatten multi-index columns if necessary
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
        data[ticker] = df
    return data

def preprocess_data(df):
    """Add technical indicators and clean data."""
    # Add all technical analysis features
    df = add_all_ta_features(
        df, open="Open", high="High", low="Low", close="Close", volume="Volume", fillna=True
    )
    return df

def simulate_sentiment_data(dates):
    """Simulate sentiment data for demonstration purposes."""
    analyzer = SentimentIntensityAnalyzer()
    # In a real scenario, you would fetch news headlines for each date
    # Here we simulate some headlines and get their sentiment
    headlines = [
        "Gold prices surge as inflation fears rise",
        "Silver market remains stable despite economic uncertainty",
        "Copper demand increases due to electric vehicle production",
        "Central banks increase gold reserves",
        "Silver prices dip as dollar strengthens",
        "Copper supply concerns arise from mining strikes"
    ]
    
    sentiment_scores = []
    for date in dates:
        # Randomly pick a headline for simulation
        headline = np.random.choice(headlines)
        score = analyzer.polarity_scores(headline)['compound']
        sentiment_scores.append(score)
    
    return pd.Series(sentiment_scores, index=dates, name="Sentiment")

def main():
    # Define tickers for Gold, Silver, and Copper
    # GLD: SPDR Gold Shares, SLV: iShares Silver Trust, CPER: United States Copper Index Fund
    tickers = ["GLD", "SLV", "CPER"]
    start_date = "2020-01-01"
    end_date = datetime.datetime.now().strftime("%Y-%m-%d")
    
    # Fetch data
    metal_data = fetch_metal_data(tickers, start_date, end_date)
    
    # Process each metal's data
    for ticker, df in metal_data.items():
        print(f"Processing {ticker}...")
        df = preprocess_data(df)
        
        # Add simulated sentiment data
        sentiment = simulate_sentiment_data(df.index)
        df["Sentiment"] = sentiment
        
        # Save to CSV
        filename = f"/home/ubuntu/{ticker}_processed.csv"
        df.to_csv(filename)
        print(f"Saved processed data for {ticker} to {filename}")

if __name__ == "__main__":
    main()
