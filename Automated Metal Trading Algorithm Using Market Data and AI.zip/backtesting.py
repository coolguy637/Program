import backtrader as bt
import pandas as pd
import joblib
import numpy as np
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings("ignore")

class MLStrategy(bt.Strategy):
    params = (
        ('model', None),
        ('processed_df', None),
    )

    def __init__(self):
        self.model = self.params.model
        self.df = self.params.processed_df
        self.dataclose = self.datas[0].close

    def next(self):
        current_date = self.datas[0].datetime.date(0)
        
        if current_date in self.df.index:
            # Extract features for the current date
            features_row = self.df.loc[current_date].drop(['Open', 'High', 'Low', 'Close', 'Volume'])
            # Convert to DataFrame to keep feature names and avoid warnings
            features_df = pd.DataFrame([features_row])
            
            # Predict next day's movement
            prediction = self.model.predict(features_df)[0]
            
            if not self.position:
                if prediction == 1:
                    self.buy()
            else:
                if prediction == 0:
                    self.sell()

def run_backtest(ticker):
    print(f"Running backtest for {ticker}...")
    cerebro = bt.Cerebro()
    
    # Load processed data
    df = pd.read_csv(f"/home/ubuntu/{ticker}_processed.csv", index_col=0, parse_dates=True)
    df.index = df.index.date
    
    # Filter for the test period (last 20% of data)
    test_size = int(len(df) * 0.2)
    test_df = df.iloc[-test_size:]
    
    # Load model
    model = joblib.load(f"/home/ubuntu/{ticker}_model.joblib")
    
    # Prepare data feed for Backtrader
    # We need to convert the index back to datetime for Backtrader
    bt_df = test_df.copy()
    bt_df.index = pd.to_datetime(bt_df.index)
    data = bt.feeds.PandasData(dataname=bt_df)
    cerebro.adddata(data)
    
    # Add strategy
    cerebro.addstrategy(MLStrategy, model=model, processed_df=test_df)
    
    # Set initial cash
    cerebro.broker.setcash(10000.0)
    
    # Set commission
    cerebro.broker.setcommission(commission=0.001)
    
    print(f"Starting Portfolio Value: {cerebro.broker.getvalue():.2f}")
    cerebro.run()
    final_value = cerebro.broker.getvalue()
    print(f"Final Portfolio Value: {final_value:.2f}")
    
    return final_value

def main():
    tickers = ["GLD", "SLV", "CPER"]
    results = {}
    for ticker in tickers:
        final_value = run_backtest(ticker)
        results[ticker] = final_value
    
    print("\nBacktesting Results Summary:")
    for ticker, value in results.items():
        print(f"{ticker}: {value:.2f}")

if __name__ == "__main__":
    main()
