# Metal Trading Algorithm Research Findings

## 1. Data Sources
- **Price Data**: `yfinance` (Yahoo Finance) provides historical and real-time data for:
  - Gold: `GLD` (SPDR Gold Shares) or `GC=F` (Gold Futures)
  - Silver: `SLV` (iShares Silver Trust) or `SI=F` (Silver Futures)
  - Copper: `CPER` (United States Copper Index Fund) or `HG=F` (Copper Futures)
- **Sentiment Data**: 
  - News APIs: `NewsAPI.org` or `GNews` for headlines.
  - Social Media: Reddit (r/commodities, r/gold) or Twitter (X) via scraping or APIs.
  - Sentiment Tools: `VADER` (Valence Aware Dictionary and sEntiment Reasoner) or `TextBlob`.

## 2. Technical Analysis
- **Libraries**: `pandas-ta` is highly recommended for its ease of use with pandas DataFrames.
- **Key Indicators**:
  - Trend: Moving Averages (SMA, EMA), MACD.
  - Momentum: RSI, Stochastic Oscillator.
  - Volatility: Bollinger Bands, ATR (Average True Range).
  - Volume: On-Balance Volume (OBV).

## 3. Machine Learning Models
- **Regression**: Predict next-day price or return using Linear Regression, Random Forest Regressor, or XGBoost.
- **Classification**: Predict price movement (Up/Down/Neutral) using Random Forest Classifier or SVM.
- **Deep Learning**: LSTM (Long Short-Term Memory) networks for time-series forecasting.

## 4. Backtesting Frameworks
- **Backtrader**: Feature-rich and widely used.
- **Vectorbt**: Extremely fast for large-scale backtesting.
- **Custom**: Simple loop-based backtester for specific needs.

## 5. Proposed Architecture
1. **Data Ingestion**: Fetch historical price and news data.
2. **Feature Engineering**:
   - Calculate technical indicators.
   - Perform sentiment analysis on news headlines.
   - Lagged features (previous days' prices/returns).
3. **Model Training**: Train a machine learning model (e.g., Random Forest) on historical features.
4. **Signal Generation**: Combine ML predictions with technical rules and sentiment scores.
5. **Backtesting**: Evaluate performance on historical data.
6. **Execution (Simulated)**: Generate buy/sell signals for the current day.
