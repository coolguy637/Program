import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import joblib

def prepare_ml_data(df):
    """Prepare data for machine learning model."""
    # Define target: 1 if next day's close is higher than today's close, else 0
    df['Target'] = (df['Close'].shift(-1) > df['Close']).astype(int)
    
    # Drop rows with NaN values (from technical indicators and target shift)
    df = df.dropna()
    
    # Select features (all columns except target and original price data)
    # We'll exclude 'Open', 'High', 'Low', 'Close', 'Adj Close', 'Volume'
    # and keep technical indicators and sentiment
    features = df.drop(['Open', 'High', 'Low', 'Close', 'Volume', 'Target'], axis=1)
    target = df['Target']
    
    return features, target

def train_model(ticker):
    """Train a Random Forest model for a given ticker."""
    print(f"Training model for {ticker}...")
    df = pd.read_csv(f"/home/ubuntu/{ticker}_processed.csv", index_col=0)
    
    features, target = prepare_ml_data(df)
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, shuffle=False)
    
    # Initialize and train Random Forest Classifier
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Evaluate model
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy for {ticker}: {accuracy:.2f}")
    print(classification_report(y_test, y_pred))
    
    # Save model
    model_filename = f"/home/ubuntu/{ticker}_model.joblib"
    joblib.dump(model, model_filename)
    print(f"Saved model for {ticker} to {model_filename}")
    
    return model

def main():
    tickers = ["GLD", "SLV", "CPER"]
    for ticker in tickers:
        train_model(ticker)

if __name__ == "__main__":
    main()
