import numpy as np
import gymnasium as gym
from gymnasium import spaces
from ..base_env import BaseEnvironment

class CLVEnvironment(BaseEnvironment):
    """
    Marketing environment for optimizing Customer Lifetime Value (CLV).
    The agent decides on the level of marketing engagement (e.g., discount, email, call)
    to maximize long-term customer value.
    """
    def __init__(self, task_id=0):
        super(CLVEnvironment, self).__init__()
        self.task_id = task_id
        
        # Observation: [Customer Age, Total Spend, Last Purchase Time, Engagement Level]
        self._observation_space = spaces.Box(low=0, high=1, shape=(4,), dtype=np.float32)
        
        # Action: [No Action, Low Discount, High Discount, Personalized Email]
        self._action_space = spaces.Discrete(4)
        
        self.state = None
        self.steps = 0
        self.max_steps = 20

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.state = np.random.rand(4).astype(np.float32)
        self.steps = 0
        return self.state, {}

    def step(self, action):
        self.steps += 1
        
        # Simple transition logic: actions affect spend and engagement
        reward = 0
        if action == 0: # No Action
            reward = 0.1 * self.state[1] # Small reward from existing spend
        elif action == 1: # Low Discount
            reward = 0.5 * self.state[1] - 0.1 # Cost of discount
            self.state[1] *= 1.1 # Increase spend
        elif action == 2: # High Discount
            reward = 0.8 * self.state[1] - 0.3 # Higher cost
            self.state[1] *= 1.3
        elif action == 3: # Personalized Email
            reward = 0.3 * self.state[1] - 0.05
            self.state[3] = min(1.0, self.state[3] + 0.2) # Increase engagement
            
        # Update state randomly to simulate customer behavior
        self.state += np.random.normal(0, 0.05, size=(4,)).astype(np.float32)
        self.state = np.clip(self.state, 0, 1)
        
        terminated = self.steps >= self.max_steps
        truncated = False
        
        return self.state, reward, terminated, truncated, {}

    def get_task_id(self):
        return self.task_id

    @property
    def observation_space(self):
        return self._observation_space

    @property
    def action_space(self):
        return self._action_space
