import numpy as np
import gymnasium as gym
from gymnasium import spaces
from ..base_env import BaseEnvironment

class ResourceAllocationEnvironment(BaseEnvironment):
    """
    Technology environment for optimizing resource allocation in a cloud computing system.
    The agent decides on the allocation of CPU, memory, and storage resources
    to maximize system performance while minimizing costs.
    """
    def __init__(self, task_id=2):
        super(ResourceAllocationEnvironment, self).__init__()
        self.task_id = task_id
        
        # Observation: [CPU Usage, Memory Usage, Storage Usage, System Load]
        self._observation_space = spaces.Box(low=0, high=1, shape=(4,), dtype=np.float32)
        
        # Action: [Increase CPU, Increase Memory, Increase Storage, Optimize Load]
        self._action_space = spaces.Discrete(4)
        
        self.state = None
        self.steps = 0
        self.max_steps = 20

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.state = np.random.rand(4).astype(np.float32)
        self.steps = 0
        return self.state, {}

    def step(self, action):
        self.steps += 1
        
        # Simple transition logic: actions affect resource usage and system load
        reward = 0
        if action == 0: # Increase CPU
            reward = 0.5 * self.state[0] - 0.1 # Cost of CPU
            self.state[0] = min(1.0, self.state[0] + 0.1) # Increase CPU usage
        elif action == 1: # Increase Memory
            reward = 0.5 * self.state[1] - 0.1
            self.state[1] = min(1.0, self.state[1] + 0.1)
        elif action == 2: # Increase Storage
            reward = 0.5 * self.state[2] - 0.1
            self.state[2] = min(1.0, self.state[2] + 0.1)
        elif action == 3: # Optimize Load
            reward = 0.3 * (1.0 - self.state[3]) - 0.05
            self.state[3] = max(0.0, self.state[3] - 0.2) # Decrease system load
            
        # Update state randomly to simulate system dynamics
        self.state += np.random.normal(0, 0.05, size=(4,)).astype(np.float32)
        self.state = np.clip(self.state, 0, 1)
        
        terminated = self.steps >= self.max_steps
        truncated = False
        
        return self.state, reward, terminated, truncated, {}

    def get_task_id(self):
        return self.task_id

    @property
    def observation_space(self):
        return self._observation_space

    @property
    def action_space(self):
        return self._action_space
