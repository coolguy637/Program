import torch
import numpy as np
from ..core.agent import MTRLAgent
from ..environments.marketing.clv_env import CLVEnvironment
from ..environments.finance.portfolio_env import PortfolioOptimizationEnvironment
from ..environments.technology.resource_env import ResourceAllocationEnvironment

def evaluate():
    # Hyperparameters
    state_dim = 4
    num_tasks = 3
    task_embedding_dim = 8
    action_dim = 4
    hidden_dim = 128
    
    # Initialize agent
    agent = MTRLAgent(state_dim, num_tasks, task_embedding_dim, action_dim, hidden_dim)
    
    # Load the trained agent
    try:
        agent.load("checkpoints/mtrl_agent.pth")
        print("Agent loaded successfully.")
    except FileNotFoundError:
        print("Trained agent not found. Please run training first.")
        return
    
    # Initialize environments
    envs = [
        CLVEnvironment(task_id=0),
        PortfolioOptimizationEnvironment(task_id=1),
        ResourceAllocationEnvironment(task_id=2)
    ]
    
    # Evaluate on each task
    for env in envs:
        task_id = env.get_task_id()
        total_reward = 0
        num_episodes = 10
        
        for episode in range(num_episodes):
            state, _ = env.reset()
            episode_reward = 0
            
            for t in range(env.max_steps):
                # Select action
                action, _ = agent.select_action(state, task_id)
                
                # Execute action
                next_state, reward, terminated, truncated, _ = env.step(action)
                
                state = next_state
                episode_reward += reward
                
                if terminated:
                    break
                    
            total_reward += episode_reward
            
        avg_reward = total_reward / num_episodes
        print(f"Task: {env.__class__.__name__} \t Average Reward: {avg_reward:.2f}")

if __name__ == "__main__":
    evaluate()
