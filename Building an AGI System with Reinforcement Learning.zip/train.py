import os
import torch
import numpy as np
from ..core.agent import MTRLAgent
from ..core.algorithms import Memory
from ..environments.marketing.clv_env import CLVEnvironment
from ..environments.finance.portfolio_env import PortfolioOptimizationEnvironment
from ..environments.technology.resource_env import ResourceAllocationEnvironment

def train():
    # Hyperparameters
    state_dim = 4
    num_tasks = 3
    task_embedding_dim = 8
    action_dim = 4
    hidden_dim = 128
    lr = 3e-4
    max_episodes = 1000
    update_timestep = 2000
    
    # Initialize agent and memory
    agent = MTRLAgent(state_dim, num_tasks, task_embedding_dim, action_dim, hidden_dim, lr)
    memory = Memory()
    
    # Initialize environments
    envs = [
        CLVEnvironment(task_id=0),
        PortfolioOptimizationEnvironment(task_id=1),
        ResourceAllocationEnvironment(task_id=2)
    ]
    
    timestep = 0
    for episode in range(1, max_episodes + 1):
        # Randomly select a task for the episode
        env_idx = np.random.randint(num_tasks)
        env = envs[env_idx]
        task_id = env.get_task_id()
        
        state, _ = env.reset()
        episode_reward = 0
        
        for t in range(env.max_steps):
            timestep += 1
            
            # Select action
            action, logprob = agent.select_action(state, task_id)
            
            # Execute action
            next_state, reward, terminated, truncated, _ = env.step(action)
            
            # Store in memory
            memory.states.append(state)
            memory.actions.append(action)
            memory.logprobs.append(logprob)
            memory.rewards.append(reward)
            memory.is_terminals.append(terminated)
            memory.task_ids.append(task_id)
            
            state = next_state
            episode_reward += reward
            
            # Update agent
            if timestep % update_timestep == 0:
                agent.update(memory)
                memory.clear()
                
            if terminated:
                break
                
        if episode % 100 == 0:
            print(f"Episode {episode} \t Last Reward: {episode_reward:.2f} \t Task: {env.__class__.__name__}")
            
    # Save the trained agent
    os.makedirs("checkpoints", exist_ok=True)
    agent.save("checkpoints/mtrl_agent.pth")
    print("Training complete. Agent saved.")

if __name__ == "__main__":
    train()
