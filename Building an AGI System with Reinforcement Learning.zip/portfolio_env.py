import numpy as np
import gymnasium as gym
from gymnasium import spaces
from ..base_env import BaseEnvironment

class PortfolioOptimizationEnvironment(BaseEnvironment):
    """
    Finance environment for optimizing a portfolio of assets.
    The agent decides on the allocation of capital across different assets
    to maximize returns while managing risk.
    """
    def __init__(self, task_id=1):
        super(PortfolioOptimizationEnvironment, self).__init__()
        self.task_id = task_id
        
        # Observation: [Asset 1 Return, Asset 2 Return, Asset 3 Return, Current Allocation]
        self._observation_space = spaces.Box(low=-1, high=1, shape=(4,), dtype=np.float32)
        
        # Action: [Increase Allocation to Asset 1, Increase Allocation to Asset 2, Increase Allocation to Asset 3, Rebalance]
        self._action_space = spaces.Discrete(4)
        
        self.state = None
        self.steps = 0
        self.max_steps = 20

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.state = np.random.uniform(-0.1, 0.1, size=(4,)).astype(np.float32)
        self.steps = 0
        return self.state, {}

    def step(self, action):
        self.steps += 1
        
        # Simple transition logic: actions affect returns and allocation
        reward = 0
        if action == 0: # Increase Allocation to Asset 1
            reward = 0.5 * self.state[0] - 0.05 # Cost of rebalancing
            self.state[3] = min(1.0, self.state[3] + 0.1) # Increase allocation
        elif action == 1: # Increase Allocation to Asset 2
            reward = 0.5 * self.state[1] - 0.05
            self.state[3] = min(1.0, self.state[3] + 0.1)
        elif action == 2: # Increase Allocation to Asset 3
            reward = 0.5 * self.state[2] - 0.05
            self.state[3] = min(1.0, self.state[3] + 0.1)
        elif action == 3: # Rebalance
            reward = 0.2 * (self.state[0] + self.state[1] + self.state[2]) - 0.1
            self.state[3] = 0.5 # Reset allocation
            
        # Update state randomly to simulate market fluctuations
        self.state[:3] += np.random.normal(0, 0.05, size=(3,)).astype(np.float32)
        self.state = np.clip(self.state, -1, 1)
        
        terminated = self.steps >= self.max_steps
        truncated = False
        
        return self.state, reward, terminated, truncated, {}

    def get_task_id(self):
        return self.task_id

    @property
    def observation_space(self):
        return self._observation_space

    @property
    def action_space(self):
        return self._action_space
