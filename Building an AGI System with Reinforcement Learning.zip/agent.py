import torch
from .networks import SharedPolicyNetwork, TaskEncoder
from .algorithms import PPO

class MTRLAgent:
    """
    Multi-Task Reinforcement Learning Agent.
    """
    def __init__(self, state_dim, num_tasks, task_embedding_dim, action_dim, hidden_dim=128, lr=3e-4):
        self.policy_net = SharedPolicyNetwork(state_dim, task_embedding_dim, action_dim, hidden_dim)
        self.task_encoder = TaskEncoder(num_tasks, task_embedding_dim)
        self.ppo = PPO(self.policy_net, self.task_encoder, lr=lr)

    def select_action(self, state, task_id):
        """
        Selects an action based on the current state and task ID.
        """
        return self.ppo.select_action(state, task_id)

    def update(self, memory):
        """
        Updates the agent's policy and value networks.
        """
        self.ppo.update(memory)

    def save(self, path):
        """
        Saves the agent's model parameters.
        """
        torch.save({
            'policy_net_state_dict': self.policy_net.state_dict(),
            'task_encoder_state_dict': self.task_encoder.state_dict(),
            'optimizer_state_dict': self.ppo.optimizer.state_dict(),
        }, path)

    def load(self, path):
        """
        Loads the agent's model parameters.
        """
        checkpoint = torch.load(path)
        self.policy_net.load_state_dict(checkpoint['policy_net_state_dict'])
        self.task_encoder.load_state_dict(checkpoint['task_encoder_state_dict'])
        self.ppo.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
