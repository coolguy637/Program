import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical

class PPO:
    """
    Proximal Policy Optimization (PPO) algorithm adapted for Multi-Task RL.
    """
    def __init__(self, policy_net, task_encoder, lr=3e-4, gamma=0.99, eps_clip=0.2, K_epochs=4):
        self.policy_net = policy_net
        self.task_encoder = task_encoder
        self.optimizer = optim.Adam(list(policy_net.parameters()) + list(task_encoder.parameters()), lr=lr)
        self.gamma = gamma
        self.eps_clip = eps_clip
        self.K_epochs = K_epochs
        self.MseLoss = nn.MSELoss()

    def select_action(self, state, task_id):
        """
        Selects an action based on the current state and task ID.
        """
        state = torch.FloatTensor(state).unsqueeze(0)
        task_id = torch.LongTensor([task_id])
        
        with torch.no_grad():
            task_embedding = self.task_encoder(task_id)
            action_probs, _ = self.policy_net(state, task_embedding)
            
        dist = Categorical(action_probs)
        action = dist.sample()
        
        return action.item(), dist.log_prob(action)

    def update(self, memory):
        """
        Updates the policy and value networks using the collected experiences.
        """
        # Convert memory to tensors
        old_states = torch.FloatTensor(memory.states)
        old_actions = torch.LongTensor(memory.actions)
        old_logprobs = torch.stack(memory.logprobs).detach()
        old_task_ids = torch.LongTensor(memory.task_ids)
        rewards = memory.rewards
        is_terminals = memory.is_terminals

        # Monte Carlo estimate of returns
        returns = []
        discounted_reward = 0
        for reward, is_terminal in zip(reversed(rewards), reversed(is_terminals)):
            if is_terminal:
                discounted_reward = 0
            discounted_reward = reward + (self.gamma * discounted_reward)
            returns.insert(0, discounted_reward)
            
        # Normalizing the returns
        returns = torch.tensor(returns, dtype=torch.float32)
        returns = (returns - returns.mean()) / (returns.std() + 1e-7)

        # Optimize policy for K epochs
        for _ in range(self.K_epochs):
            # Get task embeddings
            task_embeddings = self.task_encoder(old_task_ids)
            
            # Evaluating old actions and values
            action_probs, state_values = self.policy_net(old_states, task_embeddings)
            dist = Categorical(action_probs)
            logprobs = dist.log_prob(old_actions)
            dist_entropy = dist.entropy()
            state_values = torch.squeeze(state_values)
            
            # Finding the ratio (pi_theta / pi_theta__old)
            ratios = torch.exp(logprobs - old_logprobs.detach())

            # Finding Surrogate Loss
            advantages = returns - state_values.detach()   
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1-self.eps_clip, 1+self.eps_clip) * advantages

            # Final loss of clipped objective PPO
            loss = -torch.min(surr1, surr2) + 0.5*self.MseLoss(state_values, returns) - 0.01*dist_entropy

            # Take gradient step
            self.optimizer.zero_grad()
            loss.mean().backward()
            self.optimizer.step()
            
class Memory:
    """
    Simple memory buffer for storing experiences.
    """
    def __init__(self):
        self.actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []
        self.is_terminals = []
        self.task_ids = []

    def clear(self):
        del self.actions[:]
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]
        del self.is_terminals[:]
        del self.task_ids[:]
