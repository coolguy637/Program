from abc import ABC, abstractmethod
import gymnasium as gym

class BaseEnvironment(ABC, gym.Env):
    """
    Abstract base class for all business-related Reinforcement Learning environments.
    Ensures a consistent interface for the MTRL agent.
    """

    @abstractmethod
    def step(self, action):
        """
        Execute one time step within the environment.
        Returns: observation, reward, terminated, truncated, info
        """
        pass

    @abstractmethod
    def reset(self, seed=None, options=None):
        """
        Resets the environment to an initial state and returns an initial observation.
        Returns: observation, info
        """
        pass

    @abstractmethod
    def get_task_id(self):
        """
        Returns a unique identifier for the current task.
        """
        pass

    @property
    @abstractmethod
    def observation_space(self):
        """
        Returns the observation space of the environment.
        """
        pass

    @property
    @abstractmethod
    def action_space(self):
        """
        Returns the action space of the environment.
        """
        pass
