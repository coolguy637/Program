import torch
import torch.nn as nn
import torch.nn.functional as F

class TaskEncoder(nn.Module):
    """
    Encodes task IDs into a continuous embedding space.
    """
    def __init__(self, num_tasks, embedding_dim):
        super(TaskEncoder, self).__init__()
        self.embedding = nn.Embedding(num_tasks, embedding_dim)

    def forward(self, task_id):
        return self.embedding(task_id)

class SharedPolicyNetwork(nn.Module):
    """
    A shared policy network that takes state and task embedding as input.
    """
    def __init__(self, state_dim, task_embedding_dim, action_dim, hidden_dim=128):
        super(SharedPolicyNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim + task_embedding_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.actor = nn.Linear(hidden_dim, action_dim)
        self.critic = nn.Linear(hidden_dim, 1)

    def forward(self, state, task_embedding):
        # Concatenate state and task embedding
        x = torch.cat([state, task_embedding], dim=-1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        
        # Actor: Action probabilities (using softmax for discrete actions)
        action_probs = F.softmax(self.actor(x), dim=-1)
        
        # Critic: State value estimate
        state_value = self.critic(x)
        
        return action_probs, state_value
