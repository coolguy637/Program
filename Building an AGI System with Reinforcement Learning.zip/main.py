import argparse
from mtrl_agi.scripts.train import train
from mtrl_agi.scripts.evaluate import evaluate

def main():
    parser = argparse.ArgumentParser(description="Multi-Task Reinforcement Learning for Business AGI")
    parser.add_argument("--mode", type=str, default="train", choices=["train", "evaluate"], help="Mode to run the system in (train or evaluate)")
    args = parser.parse_args()
    
    if args.mode == "train":
        train()
    elif args.mode == "evaluate":
        evaluate()

if __name__ == "__main__":
    main()
