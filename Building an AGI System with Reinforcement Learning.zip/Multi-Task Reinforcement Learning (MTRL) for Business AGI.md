# Multi-Task Reinforcement Learning (MTRL) for Business AGI

This project implements a foundational Multi-Task Reinforcement Learning (MTRL) framework designed to tackle diverse business challenges across domains such as marketing, finance, and technology. The system leverages a shared policy network and task embeddings to enable a single agent to learn and generalize across multiple related tasks, moving towards an AGI-like capability in specific business contexts.

## Project Structure

The project is organized into a modular structure to ensure scalability, maintainability, and ease of extension:

```
mtrl_agi/
├── environments/             # Business-specific RL environments
│   ├── marketing/            # Marketing-related tasks (e.g., CLV, pricing)
│   ├── finance/              # Finance-related tasks (e.g., portfolio, trading)
│   ├── technology/           # Technology/Operations tasks (e.g., resource allocation)
│   └── base_env.py           # Abstract base class for all environments
├── core/                     # Core MTRL components
│   ├── agent.py              # Defines the MTRL agent (shared policy, task encoder)
│   ├── networks.py           # Neural network architectures (policy, value, task encoder)
│   └── algorithms.py         # RL algorithms (e.g., PPO implementation)
├── utils/                    # Utility functions (logging, data handling, etc.)
├── scripts/                  # Training and evaluation scripts
│   ├── train.py
│   └── evaluate.py
├── config/                   # Configuration files (e.g., config.yaml for hyperparameters)
├── tests/                    # Unit and integration tests
├── README.md
├── requirements.txt
└── main.py                   # Main entry point for running experiments
```

## Core Components

### Shared Policy Network

A central neural network that learns a generalized policy applicable across various tasks. It processes both the current state observation and a task-specific embedding to make decisions.

### Task Encoder

This component translates unique task identifiers into a continuous vector representation (task embedding). This embedding provides crucial context to the shared policy network, allowing it to adapt its behavior to the specific task at hand.

### Reinforcement Learning Algorithm

The system utilizes Proximal Policy Optimization (PPO) as its primary reinforcement learning algorithm. PPO is chosen for its robust performance and stability, making it well-suited for multi-task learning scenarios.

## Business Domain Environments

The framework includes several simulated business environments, each designed to mimic real-world scenarios:

*   **Marketing: Customer Lifetime Value (CLV) Optimization** (`CLVEnvironment`)
    *   **Description**: The agent learns to make decisions regarding marketing engagement (e.g., discounts, emails) to maximize the long-term value of a customer.
    *   **Observation Space**: Includes customer age, total spend, last purchase time, and current engagement level.
    *   **Action Space**: Discrete actions such as 'No Action', 'Low Discount', 'High Discount', and 'Personalized Email'.

*   **Finance: Portfolio Optimization** (`PortfolioOptimizationEnvironment`)
    *   **Description**: The agent manages a portfolio of assets, making allocation decisions to maximize returns while considering risk.
    *   **Observation Space**: Represents asset returns and current allocation.
    *   **Action Space**: Discrete actions like 'Increase Allocation to Asset 1', 'Increase Allocation to Asset 2', 'Increase Allocation to Asset 3', and 'Rebalance'.

*   **Technology: Resource Allocation** (`ResourceAllocationEnvironment`)
    *   **Description**: The agent optimizes the allocation of computing resources (CPU, memory, storage) in a cloud system to enhance performance and minimize costs.
    *   **Observation Space**: Reflects CPU usage, memory usage, storage usage, and overall system load.
    *   **Action Space**: Discrete actions such as 'Increase CPU', 'Increase Memory', 'Increase Storage', and 'Optimize Load'.

## Setup and Installation

To set up the project, follow these steps:

1.  **Clone the repository (if applicable):**
    ```bash
    # Assuming you have the project files in a directory named mtrl_agi
    # If not, create the directory and place the files inside.
    ```

2.  **Navigate to the project directory:**
    ```bash
    cd mtrl_agi
    ```

3.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

## Usage

### Training the Agent

To train the MTRL agent across the defined business environments, run the `main.py` script in `train` mode:

```bash
export PYTHONPATH=$PYTHONPATH:. && python3 main.py --mode train
```

The training process will iterate through episodes, randomly selecting tasks, and updating the agent's policy. Checkpoints of the trained agent will be saved in the `checkpoints/` directory.

### Evaluating the Agent

After training, you can evaluate the agent's performance on each task by running the `main.py` script in `evaluate` mode:

```bash
export PYTHONPATH=$PYTHONPATH:. && python3 main.py --mode evaluate
```

The evaluation script will load the saved agent and report the average reward obtained on each business environment.

## Future Work

*   **More Sophisticated Environments**: Develop more complex and realistic business environments with richer state spaces, action spaces, and reward functions.
*   **Advanced MTRL Techniques**: Explore other MTRL architectures such as progressive neural networks, policy distillation, or meta-learning approaches.
*   **Real-world Data Integration**: Integrate with real-world business data sources for more accurate simulations and training.
*   **Hyperparameter Optimization**: Implement automated hyperparameter tuning for improved agent performance.
*   **Visualization and Analysis Tools**: Develop tools for better visualization of agent behavior and performance across tasks.

## References

[1] Multi-Task Reinforcement Learning Enables Parameter ... (https://arxiv.org/html/2503.05126v3)
[2] Multitask reinforcement learning with metadata-guided ... (https://www.sciencedirect.com/science/article/abs/pii/S1566253525011303)
[3] Mastering Massive Multi-Task Reinforcement Learning via ... (https://icml.cc/virtual/2025/poster/43936)
[4] Meta Reinforcement Learning with Task Embedding and ... (https://arxiv.org/abs/1905.06527)
[5] Reinforcement Learning Explained for Marketers (https://www.braze.com/resources/articles/reinforcement-learning)
[6] Reinforcement Learning in Business Strategy: Machines ... (https://providentiatech.ai/blog/reinforcement-learning-in-business-strategy-machines-that-experiment/)
[7] Reinforcement Learning in Finance (https://extractalpha.com/2024/08/22/reinforcement-learning-in-finance/)
[8] FinRL-Meta: Market environments and benchmarks for data-driven financial reinforcement learning (https://proceedings.neurips.cc/paper_files/paper/2022/hash/0bf54b80686d2c4dc0808c2e98d430f7-Abstract-Datasets_and_Benchmarks.html)
