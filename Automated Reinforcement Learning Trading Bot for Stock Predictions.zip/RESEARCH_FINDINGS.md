# RL Trading Bot Research Findings

## Key Technologies

### 1. Reinforcement Learning Framework
- **Stable-Baselines3 (SB3)**: Industry standard for RL trading bots
  - PPO (Proximal Policy Optimization): Best for trading - combines A2C and TRPO benefits
  - A2C: Alternative with faster convergence
  - Built on OpenAI Gym interface
  - Handles discrete and continuous action spaces

### 2. Interactive Brokers Integration
- **ib_insync**: High-level Python wrapper around TWS API
  - Blocking and async interfaces
  - Real-time market data streaming via `pendingTickersEvent`
  - Order execution and position management
  - Portfolio tracking and P&L monitoring
  - Event-driven architecture (connectedEvent, orderStatusEvent, execDetailsEvent, etc.)
  - **Critical Rule**: User code must not block for too long - framework needs to spin in background

### 3. Feature Extraction Architecture
- **LSTM-based approach**: Extract time-series features from historical price data
  - 128 hidden layer units typical
  - Processes 60-390 day windows
  - Captures temporal dependencies
  
- **Transformer-based approach**: Emerging alternative
  - Better long-term dependency modeling
  - Autoformer, Informer models for time series
  - More computationally expensive

- **Technical Indicators**: RSI, MACD, Bollinger Bands, Volume, etc.
  - Feature engineering combines multiple indicators
  - Normalization critical for neural networks

### 4. Custom Gym Environment
- State representation: [price, volume, technical indicators, portfolio state]
- Action space: {0: hold, 1: buy, 2: sell}
- Reward function: profit/loss + penalties for transaction costs
- Reference implementations:
  - gym-anytrading: Collection of trading environments
  - Stock-Trading-Environment: GitHub reference implementation

### 5. Data Pipeline
- **yfinance**: Free historical data, suitable for backtesting
- **IBKR Historical Data API**: Live data, better for real trading
- Preprocessing: Normalization, technical indicator calculation
- Window size: 60-390 days for LSTM input

## Architecture Pattern

```
Data Pipeline (yfinance/IBKR) 
  ↓
Feature Extraction (LSTM)
  ↓
RL Agent (PPO with SB3)
  ↓
Trading Orchestrator (Risk Management)
  ↓
Interactive Brokers (ib_insync)
  ↓
Dashboard (Real-time monitoring)
```

## Critical Considerations

1. **Non-blocking constraint**: ib_insync requires event loop to keep spinning
2. **Overfitting risk**: PPO agents can overfit on historical data
3. **Transaction costs**: Must be factored into reward function
4. **Position sizing**: Risk management critical for live trading
5. **Model versioning**: Track which model version is trading
6. **Backtesting framework**: Essential before live trading

## Recommended Stack

- **RL Framework**: Stable-Baselines3 (PPO)
- **Broker API**: ib_insync
- **Feature Extraction**: LSTM (simpler) or Transformer (better)
- **Data**: yfinance (backtesting) + IBKR API (live)
- **Database**: MySQL (already in scaffold)
- **Dashboard**: React with real-time updates
- **Orchestration**: APScheduler for scheduled tasks
