"""
Trading bot module containing RL agent, data pipeline, and IBKR integration.
"""

from .data_pipeline import DataPipeline
from .trading_env import TradingEnvironment
from .feature_extractor import LSTMFeatureExtractor, TransformerFeatureExtractor, CombinedFeatureExtractor
from .rl_agent import RLAgent, ModelTrainer
from .ibkr_connector import IBKRConnector, create_ibkr_connector
from .orchestrator import TradingOrchestrator, RiskManager, TradingState

__all__ = [
    'DataPipeline',
    'TradingEnvironment',
    'LSTMFeatureExtractor',
    'TransformerFeatureExtractor',
    'CombinedFeatureExtractor',
    'RLAgent',
    'ModelTrainer',
    'IBKRConnector',
    'create_ibkr_connector',
    'TradingOrchestrator',
    'RiskManager',
    'TradingState',
]
