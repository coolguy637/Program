"""
Online Learning System
Continuously updates models with new data collected during live trading.
"""

import numpy as np
import torch
from typing import Dict, List, Tuple, Optional
from collections import deque
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class OnlineLearningBuffer:
    """
    Maintains a rolling buffer of recent trading data for online learning.
    """
    
    def __init__(self, max_size: int = 1000):
        """
        Initialize online learning buffer.
        
        Args:
            max_size: Maximum number of samples to keep
        """
        self.max_size = max_size
        self.buffer = deque(maxlen=max_size)
    
    def add_sample(self,
                  price_sequence: np.ndarray,
                  sentiment_sequence: np.ndarray,
                  next_price: float,
                  action: int,
                  reward: float,
                  timestamp: datetime):
        """
        Add a sample to the buffer.
        
        Args:
            price_sequence: Sequence of OHLCV data
            sentiment_sequence: Sequence of sentiment scores
            next_price: Next day's price
            action: Action taken
            reward: Reward received
            timestamp: Timestamp of sample
        """
        self.buffer.append({
            'price_sequence': price_sequence,
            'sentiment_sequence': sentiment_sequence,
            'next_price': next_price,
            'action': action,
            'reward': reward,
            'timestamp': timestamp
        })
    
    def get_batch(self, batch_size: int) -> Optional[Dict]:
        """
        Get a random batch from the buffer.
        
        Args:
            batch_size: Size of batch
            
        Returns:
            Dictionary with batch data or None if buffer too small
        """
        if len(self.buffer) < batch_size:
            return None
        
        indices = np.random.choice(len(self.buffer), batch_size, replace=False)
        
        batch = {
            'price_sequences': np.array([self.buffer[i]['price_sequence'] for i in indices]),
            'sentiment_sequences': np.array([self.buffer[i]['sentiment_sequence'] for i in indices]),
            'next_prices': np.array([self.buffer[i]['next_price'] for i in indices]),
            'actions': np.array([self.buffer[i]['action'] for i in indices]),
            'rewards': np.array([self.buffer[i]['reward'] for i in indices])
        }
        
        return batch
    
    def get_all_data(self) -> Dict:
        """
        Get all data in buffer.
        
        Returns:
            Dictionary with all data
        """
        if not self.buffer:
            return None
        
        return {
            'price_sequences': np.array([s['price_sequence'] for s in self.buffer]),
            'sentiment_sequences': np.array([s['sentiment_sequence'] for s in self.buffer]),
            'next_prices': np.array([s['next_price'] for s in self.buffer]),
            'actions': np.array([s['action'] for s in self.buffer]),
            'rewards': np.array([s['reward'] for s in self.buffer])
        }
    
    def size(self) -> int:
        """Get current buffer size."""
        return len(self.buffer)


class OnlineLearner:
    """
    Manages online learning of neural network and RL models.
    """
    
    def __init__(self,
                 price_predictor,
                 rl_agent,
                 buffer_size: int = 1000,
                 update_frequency: int = 100,
                 learning_rate: float = 1e-4):
        """
        Initialize online learner.
        
        Args:
            price_predictor: Price prediction model
            rl_agent: RL agent
            buffer_size: Size of learning buffer
            update_frequency: Update models every N samples
            learning_rate: Learning rate for updates
        """
        self.price_predictor = price_predictor
        self.rl_agent = rl_agent
        self.buffer = OnlineLearningBuffer(buffer_size)
        self.update_frequency = update_frequency
        self.learning_rate = learning_rate
        
        self.samples_collected = 0
        self.updates_performed = 0
        self.update_history = []
    
    def add_experience(self,
                      price_sequence: np.ndarray,
                      sentiment_sequence: np.ndarray,
                      next_price: float,
                      action: int,
                      reward: float):
        """
        Add new experience to learning buffer.
        
        Args:
            price_sequence: Sequence of OHLCV data
            sentiment_sequence: Sequence of sentiment scores
            next_price: Next day's price
            action: Action taken
            reward: Reward received
        """
        self.buffer.add_sample(
            price_sequence,
            sentiment_sequence,
            next_price,
            action,
            reward,
            datetime.now()
        )
        
        self.samples_collected += 1
        
        # Check if we should update models
        if self.samples_collected % self.update_frequency == 0:
            self.update_models()
    
    def update_models(self):
        """
        Update both price predictor and RL agent with recent data.
        """
        if self.buffer.size() < 32:  # Minimum batch size
            logger.warning("Not enough data to update models")
            return
        
        try:
            # Update price predictor
            self._update_price_predictor()
            
            # Update RL agent
            self._update_rl_agent()
            
            self.updates_performed += 1
            logger.info(f"Models updated (Update #{self.updates_performed})")
        
        except Exception as e:
            logger.error(f"Error updating models: {e}")
    
    def _update_price_predictor(self):
        """Update price prediction model."""
        batch = self.buffer.get_batch(batch_size=32)
        
        if batch is None:
            return
        
        try:
            # Convert to tensors
            X = torch.from_numpy(batch['price_sequences']).float()
            sentiment = torch.from_numpy(batch['sentiment_sequences']).float()
            y = torch.from_numpy(batch['next_prices']).unsqueeze(1).float()
            
            device = next(self.price_predictor.model.parameters()).device
            X = X.to(device)
            sentiment = sentiment.to(device)
            y = y.to(device)
            
            # Forward pass
            self.price_predictor.optimizer.zero_grad()
            predictions = self.price_predictor.model(X, sentiment)
            loss = self.price_predictor.criterion(predictions, y)
            
            # Backward pass
            loss.backward()
            self.price_predictor.optimizer.step()
            
            logger.debug(f"Price predictor loss: {loss.item():.6f}")
            
            self.update_history.append({
                'type': 'price_predictor',
                'loss': loss.item(),
                'timestamp': datetime.now()
            })
        
        except Exception as e:
            logger.error(f"Error updating price predictor: {e}")
    
    def _update_rl_agent(self):
        """Update RL agent with recent experiences."""
        batch = self.buffer.get_batch(batch_size=32)
        
        if batch is None:
            return
        
        try:
            # Prepare state data (concatenate price and sentiment)
            states = np.concatenate([
                batch['price_sequences'].reshape(batch['price_sequences'].shape[0], -1),
                batch['sentiment_sequences'].reshape(batch['sentiment_sequences'].shape[0], -1)
            ], axis=1)
            
            actions = batch['actions']
            rewards = batch['rewards']
            
            # Add to agent memory
            for i in range(len(states)):
                # Compute value estimate
                state_tensor = torch.from_numpy(states[i]).float().unsqueeze(0).to(self.rl_agent.device)
                
                with torch.no_grad():
                    _, value = self.rl_agent.network(state_tensor)
                    value = value.item()
                
                # Compute log probability
                with torch.no_grad():
                    action_probs, _ = self.rl_agent.network(state_tensor)
                    dist = torch.distributions.Categorical(action_probs)
                    log_prob = dist.log_prob(torch.tensor(actions[i])).item()
                
                self.rl_agent.store_transition(
                    states[i],
                    actions[i],
                    rewards[i],
                    value,
                    log_prob,
                    False
                )
            
            # Train agent
            self.rl_agent.train(epochs=3, batch_size=16)
            
            logger.debug("RL agent updated")
            
            self.update_history.append({
                'type': 'rl_agent',
                'timestamp': datetime.now()
            })
        
        except Exception as e:
            logger.error(f"Error updating RL agent: {e}")
    
    def get_update_statistics(self) -> Dict:
        """
        Get statistics about model updates.
        
        Returns:
            Dictionary with update statistics
        """
        return {
            'samples_collected': self.samples_collected,
            'updates_performed': self.updates_performed,
            'buffer_size': self.buffer.size(),
            'buffer_capacity': self.buffer.max_size,
            'recent_updates': len(self.update_history[-10:])
        }


class ExperienceReplay:
    """
    Experience replay buffer for improving sample efficiency.
    """
    
    def __init__(self, max_size: int = 10000):
        """
        Initialize experience replay.
        
        Args:
            max_size: Maximum buffer size
        """
        self.max_size = max_size
        self.buffer = deque(maxlen=max_size)
        self.priorities = deque(maxlen=max_size)
    
    def add_experience(self,
                      state: np.ndarray,
                      action: int,
                      reward: float,
                      next_state: np.ndarray,
                      done: bool,
                      td_error: float = 1.0):
        """
        Add experience to replay buffer.
        
        Args:
            state: Current state
            action: Action taken
            reward: Reward received
            next_state: Next state
            done: Whether episode is done
            td_error: Temporal difference error (for prioritization)
        """
        self.buffer.append({
            'state': state,
            'action': action,
            'reward': reward,
            'next_state': next_state,
            'done': done
        })
        
        # Prioritize experiences with high TD error
        self.priorities.append(abs(td_error) + 1e-6)
    
    def sample_batch(self, batch_size: int) -> Optional[Dict]:
        """
        Sample a batch using prioritized experience replay.
        
        Args:
            batch_size: Size of batch
            
        Returns:
            Dictionary with batch data or None
        """
        if len(self.buffer) < batch_size:
            return None
        
        # Compute sampling probabilities
        priorities = np.array(list(self.priorities))
        probabilities = priorities / priorities.sum()
        
        # Sample indices
        indices = np.random.choice(
            len(self.buffer),
            batch_size,
            p=probabilities,
            replace=False
        )
        
        # Compute importance weights
        weights = (len(self.buffer) * probabilities[indices]) ** -0.6
        weights /= weights.max()
        
        # Collect batch
        batch = {
            'states': np.array([self.buffer[i]['state'] for i in indices]),
            'actions': np.array([self.buffer[i]['action'] for i in indices]),
            'rewards': np.array([self.buffer[i]['reward'] for i in indices]),
            'next_states': np.array([self.buffer[i]['next_state'] for i in indices]),
            'dones': np.array([self.buffer[i]['done'] for i in indices]),
            'weights': weights,
            'indices': indices
        }
        
        return batch
    
    def update_priorities(self, indices: np.ndarray, td_errors: np.ndarray):
        """
        Update priorities for sampled experiences.
        
        Args:
            indices: Indices of experiences
            td_errors: New TD errors
        """
        for idx, td_error in zip(indices, td_errors):
            self.priorities[idx] = abs(td_error) + 1e-6
    
    def size(self) -> int:
        """Get current buffer size."""
        return len(self.buffer)


class ContinuousLearningScheduler:
    """
    Schedules when to perform model updates.
    """
    
    def __init__(self,
                 initial_update_frequency: int = 100,
                 min_update_frequency: int = 50,
                 max_update_frequency: int = 500):
        """
        Initialize learning scheduler.
        
        Args:
            initial_update_frequency: Initial update frequency
            min_update_frequency: Minimum update frequency
            max_update_frequency: Maximum update frequency
        """
        self.update_frequency = initial_update_frequency
        self.min_frequency = min_update_frequency
        self.max_frequency = max_update_frequency
        
        self.samples_since_update = 0
        self.recent_losses = deque(maxlen=10)
    
    def should_update(self) -> bool:
        """
        Determine if models should be updated.
        
        Returns:
            True if update should be performed
        """
        self.samples_since_update += 1
        return self.samples_since_update >= self.update_frequency
    
    def record_update(self, loss: float):
        """
        Record that an update was performed.
        
        Args:
            loss: Loss value from update
        """
        self.recent_losses.append(loss)
        self.samples_since_update = 0
        
        # Adjust update frequency based on loss trend
        if len(self.recent_losses) >= 5:
            recent_avg = np.mean(list(self.recent_losses)[-5:])
            older_avg = np.mean(list(self.recent_losses)[:-5])
            
            if recent_avg < older_avg:
                # Loss improving, update less frequently
                self.update_frequency = max(
                    self.min_frequency,
                    int(self.update_frequency * 0.95)
                )
            else:
                # Loss not improving, update more frequently
                self.update_frequency = min(
                    self.max_frequency,
                    int(self.update_frequency * 1.05)
                )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    from neural_network import PricePredictor
    from rl_agent import PPOAgent
    
    price_predictor = PricePredictor()
    price_predictor.build_model()
    
    rl_agent = PPOAgent(state_dim=32)
    
    learner = OnlineLearner(price_predictor, rl_agent)
    
    # Simulate collecting experiences
    for i in range(200):
        price_seq = np.random.randn(30, 5).astype(np.float32)
        sentiment_seq = np.random.randn(30).astype(np.float32)
        next_price = np.random.rand()
        action = np.random.randint(0, 3)
        reward = np.random.randn()
        
        learner.add_experience(price_seq, sentiment_seq, next_price, action, reward)
    
    stats = learner.get_update_statistics()
    print(f"Update Statistics: {stats}")
