# Trading Bot Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Trading Bot Orchestrator                 │
│                      (trading_bot.py)                       │
└──────────────────────┬──────────────────────────────────────┘
                       │
        ┌──────────────┼──────────────┐
        │              │              │
        ▼              ▼              ▼
   ┌─────────┐  ┌──────────┐  ┌──────────────┐
   │  Data   │  │Sentiment │  │ IBKR Live   │
   │Pipeline │  │ Engine   │  │ Trading     │
   └─────────┘  └──────────┘  └──────────────┘
        │              │              │
        ▼              ▼              ▼
   ┌─────────────────────────────────────────┐
   │     Neural Network + RL Agent           │
   │  (Price Prediction + Trading Decisions) │
   └─────────────────────────────────────────┘
        │
        ▼
   ┌─────────────────────────────────────────┐
   │     Online Learning System              │
   │  (Continuous Model Updates)             │
   └─────────────────────────────────────────┘
```

## Component Details

### 1. Data Pipeline (`data_pipeline.py`)

**Purpose**: Collect and preprocess historical price data

**Key Classes**:
- `DataPipeline`: Main data collection and preprocessing
- `RealTimeDataBuffer`: Rolling buffer for live price data

**Workflow**:
```
Fetch Data (yfinance)
    ↓
Remove NaN values
    ↓
Normalize (MinMax or ZScore)
    ↓
Create Sequences (sliding window)
    ↓
Split Train/Test
    ↓
Ready for training
```

**Input**: Stock symbols, lookback period
**Output**: Normalized OHLCV sequences (batch_size, 30, 5)

### 2. Sentiment Engine (`sentiment_engine.py`)

**Purpose**: Aggregate market sentiment from multiple sources

**Sources**:
- News sentiment (NewsAPI) - 40% weight
- Social sentiment (Twitter API) - 30% weight
- Market sentiment (volume, volatility) - 30% weight

**Key Classes**:
- `SentimentEngine`: Main sentiment analyzer
- `SentimentBuffer`: Rolling buffer for sentiment scores

**Sentiment Calculation**:
```
News Sentiment: VADER sentiment analysis on headlines
Social Sentiment: VADER sentiment analysis on tweets
Market Sentiment: Volume ratio + price momentum - volatility

Combined = 0.4 * news + 0.3 * social + 0.3 * market
Range: -1 (very negative) to +1 (very positive)
```

**Output**: Sentiment score (-1 to 1) and trend

### 3. Neural Network (`neural_network.py`)

**Purpose**: Learn price patterns from raw OHLCV data

**Architecture**: Hybrid LSTM + CNN

```
Input: (batch_size, 30, 5)  # 30 days OHLCV
  │
  ├─→ CNN Branch
  │   └─ Conv1D(5→32) → Conv1D(32→64) → Conv1D(64→128)
  │   └─ Output: (batch_size, 3840)
  │
  ├─→ LSTM Branch
  │   └─ LSTM(5→64, 2 layers)
  │   └─ Output: (batch_size, 64)
  │
  └─→ Sentiment Input: (batch_size, 30)
  
Concatenate: (batch_size, 3934)
  ↓
Dense Layers: 256 → 128 → 1
  ↓
Output: (batch_size, 1)  # Normalized price (0-1)
```

**Key Classes**:
- `HybridPricePredictor`: Main model
- `PricePredictor`: Training wrapper

**Training**:
- Loss: MSE (Mean Squared Error)
- Optimizer: Adam
- Epochs: 10-50
- Batch size: 32

### 4. RL Agent (`rl_agent.py`)

**Purpose**: Learn optimal trading actions (buy, sell, hold)

**Algorithm**: PPO (Proximal Policy Optimization)

```
State: (batch_size, 32)
  │ 30 sentiment scores + 2 portfolio features
  │
  ├─→ Shared Feature Extraction
  │   └─ Linear(32→128) → ReLU → Linear(128→128)
  │
  ├─→ Actor (Policy)
  │   └─ Linear(128→64) → ReLU → Linear(64→3) → Softmax
  │   └─ Output: Action probabilities [hold, buy, sell]
  │
  └─→ Critic (Value)
      └─ Linear(128→64) → ReLU → Linear(64→1)
      └─ Output: State value estimate

Actions: 0=Hold, 1=Buy, 2=Sell
```

**Key Classes**:
- `ActorCriticNetwork`: Neural network architecture
- `PPOAgent`: PPO training algorithm
- `TradingEnvironment`: Simulated trading environment

**Training**:
- Discount factor (gamma): 0.99
- GAE lambda: 0.95
- Clip ratio: 0.2
- Learning rate: 3e-4

### 5. IBKR Connector (`ibkr_connector.py`)

**Purpose**: Live connection to Interactive Brokers

**Key Classes**:
- `IBKRConnector`: Main IBKR interface
- `OrderManager`: Order execution and tracking

**Capabilities**:
- Market data streaming
- Order execution (market and limit)
- Position tracking
- Account management
- Market hours checking

**Workflow**:
```
Connect to IBKR
  ↓
Subscribe to market data
  ↓
Receive real-time prices
  ↓
Execute orders
  ↓
Track positions
  ↓
Monitor account
```

### 6. Online Learner (`online_learner.py`)

**Purpose**: Continuously update models with live data

**Key Classes**:
- `OnlineLearningBuffer`: Experience storage
- `OnlineLearner`: Model update coordinator
- `ExperienceReplay`: Prioritized replay buffer
- `ContinuousLearningScheduler`: Update scheduling

**Online Learning Process**:
```
Collect Experience
  ↓
Store in Buffer
  ↓
Every N samples:
  ├─ Update Price Predictor
  └─ Update RL Agent
  ↓
Improve Model
  ↓
Better Predictions
```

### 7. Trading Bot (`trading_bot.py`)

**Purpose**: Main orchestrator coordinating all components

**Key Methods**:
- `initialize()`: Setup and initial training
- `run()`: Main trading loop
- `_trading_cycle()`: Execute one trading cycle
- `_make_trading_decision()`: Decide whether to trade
- `_execute_trade()`: Place order

**Trading Cycle**:
```
1. Get Market Data
   └─ Price, volume, bid/ask
   
2. Update Sentiment
   └─ News, social, market sentiment
   
3. Prepare State
   └─ Combine price + sentiment
   
4. Get Predictions
   ├─ Price prediction from neural network
   └─ Action from RL agent
   
5. Calculate Confidence
   └─ Confidence = |sentiment| * 0.3
   
6. Execute Trade (if confidence > threshold)
   ├─ Buy if action=1 and confidence high
   └─ Sell if action=2 and confidence high
   
7. Record Experience
   └─ For online learning
   
8. Update Models (every 100 samples)
   ├─ Price predictor update
   └─ RL agent update
```

## Data Flow

### Training Phase

```
Historical Data
    ↓
Data Pipeline (normalize, sequence)
    ↓
Neural Network Training
    ├─ Input: Price sequences + sentiment
    └─ Output: Price predictions
    ↓
RL Agent Training
    ├─ Input: State (sentiment + portfolio)
    └─ Output: Trading actions
    ↓
Saved Models
```

### Live Trading Phase

```
Real-time Market Data
    ↓
Sentiment Analysis
    ├─ News API
    ├─ Twitter API
    └─ Market metrics
    ↓
State Preparation
    └─ Combine price + sentiment
    ↓
Model Inference
    ├─ Price Predictor: Predict next price
    └─ RL Agent: Decide action
    ↓
Confidence Calculation
    └─ Based on sentiment strength
    ↓
Order Execution (if confident)
    ├─ Market order
    └─ Limit order
    ↓
Experience Recording
    └─ For online learning
    ↓
Periodic Model Updates
    └─ Every 100 trades
```

## Decision Making Logic

### Trading Signal Combination

```
Price Prediction (70% weight)
    ├─ Predicted price > current → Bullish
    └─ Predicted price < current → Bearish

Market Sentiment (30% weight)
    ├─ Positive sentiment → Bullish
    └─ Negative sentiment → Bearish

Combined Signal = 0.7 * price_signal + 0.3 * sentiment

RL Agent Action
    ├─ Buy if combined signal > 0 and confidence high
    ├─ Sell if combined signal < 0 and confidence high
    └─ Hold otherwise

Confidence = |sentiment_score| * 0.3
Execute if confidence > threshold (default 0.6)
```

## Model Training Strategy

### Initial Training (Offline)

```
Historical Data (365 days)
    ↓
Create Sequences (30-day windows)
    ↓
Split 80/20 (train/test)
    ↓
Train Price Predictor
    ├─ Epochs: 10-50
    ├─ Batch size: 32
    └─ Validation loss monitoring
    ↓
Train RL Agent
    ├─ Simulated environment
    ├─ PPO training
    └─ 50,000 timesteps
    ↓
Save Checkpoints
```

### Continuous Learning (Online)

```
Live Trading
    ↓
Collect Experiences
    ├─ Price sequences
    ├─ Sentiment data
    ├─ Actions taken
    └─ Rewards earned
    ↓
Store in Buffer
    └─ Max 1000 recent experiences
    ↓
Every 100 Samples:
    ├─ Update Price Predictor
    │  └─ Mini-batch training (32 samples)
    ├─ Update RL Agent
    │  └─ PPO training (3 epochs)
    └─ Evaluate performance
    ↓
Improved Models
    ↓
Better Predictions
```

## Risk Management

### Position Sizing

```
Portfolio Value = $100,000
Max Position Size = 30%
Max Position = $30,000

For TSLA at $250:
Max Shares = $30,000 / $250 = 120 shares
```

### Total Exposure

```
Max Total Exposure = 90%
Remaining Cash = 10%

If trading 8 symbols:
Average position = 90% / 8 = 11.25% per symbol
```

### Stop Loss & Take Profit

```
Entry Price = $100

Stop Loss (5%):
    └─ Exit if price < $95

Take Profit (10%):
    └─ Exit if price > $110

Prevents large losses and locks in gains
```

## Performance Monitoring

### Key Metrics

```
1. Return Metrics
   ├─ Total return (%)
   ├─ Daily return (%)
   └─ Cumulative return

2. Risk Metrics
   ├─ Sharpe ratio
   ├─ Maximum drawdown
   ├─ Volatility
   └─ Value at Risk (VaR)

3. Trading Metrics
   ├─ Win rate (%)
   ├─ Average profit per trade
   ├─ Profit factor
   └─ Number of trades

4. Model Metrics
   ├─ Price prediction accuracy
   ├─ RL agent reward
   ├─ Model loss
   └─ Update frequency
```

## Configuration Parameters

### IBKR Connection
- `ibkr_host`: Connection host (default: 127.0.0.1)
- `ibkr_port`: Connection port (7497=paper, 7496=live)
- `ibkr_client_id`: Unique client ID

### Risk Management
- `max_position_size`: Max position as % of portfolio (default: 0.3)
- `max_total_exposure`: Max total exposure (default: 0.9)
- `stop_loss_percent`: Stop loss level (default: 0.05)
- `take_profit_percent`: Take profit level (default: 0.10)

### Trading Control
- `trading_enabled`: Enable/disable trading (default: false)
- `trading_start_hour`: Start trading hour (default: 9)
- `trading_end_hour`: End trading hour (default: 16)
- `min_trade_interval`: Minimum seconds between trades (default: 300)
- `confidence_threshold`: Minimum confidence to trade (default: 0.6)

### API Keys
- `newsapi_key`: NewsAPI key for news sentiment
- `twitter_bearer_token`: Twitter API token for social sentiment

## Error Handling

### Connection Errors
```
Connection Failed
    ↓
Retry with exponential backoff
    ↓
Log error
    ↓
Wait before retry
```

### Data Errors
```
Missing Data
    ↓
Use cached data
    ↓
Or skip that symbol
    ↓
Log warning
```

### Order Errors
```
Order Rejected
    ↓
Log error details
    ↓
Check account balance
    ↓
Retry or skip
```

## Deployment Considerations

### Hardware Requirements
- CPU: 4+ cores recommended
- RAM: 8GB minimum, 16GB+ recommended
- GPU: Optional (NVIDIA GPU for faster training)
- Storage: 10GB+ for models and data

### Network Requirements
- Stable internet connection
- Low latency to IBKR servers
- Firewall allows localhost connections

### Software Requirements
- Python 3.8+
- All dependencies from requirements.txt
- TWS or IB Gateway running

### Monitoring
- Log files for debugging
- Trade history tracking
- Performance metrics
- Model checkpoints

---

**Last Updated**: January 2024
**Version**: 1.0.0
