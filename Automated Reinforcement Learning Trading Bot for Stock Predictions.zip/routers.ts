import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Trading bot routers
  trading: router({
    // Get all stocks
    stocks: protectedProcedure.query(async () => {
      return await db.getAllStocks();
    }),
    
    // Get active model
    activeModel: protectedProcedure.query(async () => {
      return await db.getActiveModel();
    }),
    
    // Set active model
    setActiveModel: protectedProcedure
      .input(z.object({ modelId: z.number() }))
      .mutation(async ({ input }) => {
        await db.setActiveModel(input.modelId);
        return { success: true };
      }),
    
    // Get open trades
    openTrades: protectedProcedure
      .input(z.object({ modelId: z.number() }))
      .query(async ({ input }) => {
        return await db.getOpenTrades(input.modelId);
      }),
    
    // Get trade history
    tradeHistory: protectedProcedure
      .input(z.object({ modelId: z.number(), limit: z.number().default(100) }))
      .query(async ({ input }) => {
        return await db.getTradeHistory(input.modelId, input.limit);
      }),
    
    // Get positions
    positions: protectedProcedure
      .input(z.object({ modelId: z.number() }))
      .query(async ({ input }) => {
        return await db.getPositions(input.modelId);
      }),
    
    // Get portfolio metrics
    portfolioMetrics: protectedProcedure
      .input(z.object({ modelId: z.number(), limit: z.number().default(30) }))
      .query(async ({ input }) => {
        return await db.getPortfolioMetrics(input.modelId, input.limit);
      }),
    
    // Get trading config
    config: protectedProcedure.query(async () => {
      return await db.getTradingConfig();
    }),
    
    // Update trading config
    updateConfig: protectedProcedure
      .input(z.object({
        maxPositionSize: z.string().optional(),
        maxTotalExposure: z.string().optional(),
        stopLossPercent: z.string().optional(),
        takeProfitPercent: z.string().optional(),
        tradingEnabled: z.number().optional(),
        tradingStartHour: z.number().optional(),
        tradingEndHour: z.number().optional(),
        rebalanceFrequency: z.string().optional(),
        minTradeInterval: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const updates = Object.fromEntries(
          Object.entries(input).filter(([, v]) => v !== undefined)
        );
        await db.updateTradingConfig(updates);
        return { success: true };
      }),
    
    // Get trading logs
    logs: protectedProcedure
      .input(z.object({ limit: z.number().default(100) }))
      .query(async ({ input }) => {
        return await db.getTradingLogs(input.limit);
      }),
  }),
});

export type AppRouter = typeof appRouter;
