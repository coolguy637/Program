import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, stocks, models, trades, positions, portfolioMetrics, predictions, tradingConfig, tradingLogs } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Trading-specific database queries
 */

export async function createStock(symbol: string, name: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(stocks).values({ symbol, name });
}

export async function getStockBySymbol(symbol: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(stocks).where(eq(stocks.symbol, symbol)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllStocks() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(stocks);
}

export async function createModel(name: string, version: string, modelType: string, hyperparameters: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(models).values({
    name,
    version,
    modelType,
    status: 'trained',
    hyperparameters: JSON.stringify(hyperparameters),
  });
}

export async function getActiveModel() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(models).where(eq(models.isActive, 1)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function setActiveModel(modelId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Deactivate all models
  await db.update(models).set({ isActive: 0 });
  
  // Activate the specified model
  return await db.update(models).set({ isActive: 1 }).where(eq(models.id, modelId));
}

export async function recordTrade(modelId: number, stockId: number, tradeType: 'buy' | 'sell',
                                  quantity: number, entryPrice: string, ibOrderId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(trades).values({
    modelId,
    stockId,
    tradeType,
    quantity,
    entryPrice,
    entryTime: new Date(),
    status: 'open',
    ibOrderId,
  });
}

export async function closeTrade(tradeId: number, exitPrice: string, profitLoss: string, profitLossPercent: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(trades).set({
    status: 'closed',
    exitPrice,
    exitTime: new Date(),
    profitLoss,
    profitLossPercent,
  }).where(eq(trades.id, tradeId));
}

export async function getOpenTrades(modelId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(trades).where(
    and(eq(trades.modelId, modelId), eq(trades.status, 'open'))
  );
}

export async function getTradeHistory(modelId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(trades)
    .where(eq(trades.modelId, modelId))
    .orderBy(desc(trades.createdAt))
    .limit(limit);
}

export async function recordPosition(modelId: number, stockId: number, quantity: number,
                                    averageEntryPrice: string, currentPrice: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Check if position already exists
  const existing = await db.select().from(positions)
    .where(and(eq(positions.modelId, modelId), eq(positions.stockId, stockId)))
    .limit(1);
  
  if (existing.length > 0) {
    // Update existing position
    return await db.update(positions).set({
      quantity,
      averageEntryPrice,
      currentPrice,
    }).where(and(eq(positions.modelId, modelId), eq(positions.stockId, stockId)));
  } else {
    // Create new position
    return await db.insert(positions).values({
      modelId,
      stockId,
      quantity,
      averageEntryPrice,
      currentPrice,
    });
  }
}

export async function getPositions(modelId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(positions).where(eq(positions.modelId, modelId));
}

export async function recordPortfolioMetrics(modelId: number, date: string, metrics: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(portfolioMetrics).values({
    modelId,
    date,
    totalValue: metrics.totalValue.toString(),
    cashBalance: metrics.cashBalance.toString(),
    realizedPnL: metrics.realizedPnL.toString(),
    unrealizedPnL: metrics.unrealizedPnL.toString(),
    totalReturn: metrics.totalReturn?.toString(),
    sharpeRatio: metrics.sharpeRatio?.toString(),
    maxDrawdown: metrics.maxDrawdown?.toString(),
    winRate: metrics.winRate?.toString(),
  });
}

export async function getPortfolioMetrics(modelId: number, limit: number = 30) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(portfolioMetrics)
    .where(eq(portfolioMetrics.modelId, modelId))
    .orderBy(desc(portfolioMetrics.date))
    .limit(limit);
}

export async function recordPrediction(modelId: number, stockId: number, action: 'buy' | 'sell' | 'hold',
                                      confidence: string, predictedPrice?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(predictions).values({
    modelId,
    stockId,
    predictionTime: new Date(),
    action,
    confidence,
    predictedPrice,
  });
}

export async function getTradingConfig() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(tradingConfig).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateTradingConfig(updates: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getTradingConfig();
  
  if (existing) {
    return await db.update(tradingConfig).set(updates).where(eq(tradingConfig.id, existing.id));
  } else {
    return await db.insert(tradingConfig).values({
      maxPositionSize: '0.3',
      maxTotalExposure: '0.9',
      stopLossPercent: '0.05',
      ...updates,
    });
  }
}

export async function recordTradingLog(level: 'info' | 'warning' | 'error' | 'debug',
                                      message: string, modelId?: number, metadata?: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(tradingLogs).values({
    level,
    message,
    modelId,
    metadata: metadata ? JSON.stringify(metadata) : undefined,
  });
}

export async function getTradingLogs(limit: number = 100) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(tradingLogs)
    .orderBy(desc(tradingLogs.createdAt))
    .limit(limit);
}

// TODO: add feature queries here as your schema grows.
