"""
Custom OpenAI Gym environment for RL-based stock trading.
Implements state representation, action space, and reward function.
"""

import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd
from typing import Dict, Tuple, Optional
import logging

logger = logging.getLogger(__name__)


class TradingEnvironment(gym.Env):
    """
    Custom trading environment for RL agents.
    
    State: [current_price, volume, technical_indicators, portfolio_state]
    Actions: [hold, buy, sell]
    Reward: profit/loss - transaction_costs - penalties
    """
    
    metadata = {'render_modes': ['human']}
    
    def __init__(self, data: Dict[str, np.ndarray], 
                 initial_balance: float = 100000,
                 max_position_size: float = 0.3,
                 transaction_cost: float = 0.001,
                 window_size: int = 60):
        """
        Initialize the trading environment.
        
        Args:
            data: Dictionary mapping symbol to feature arrays of shape (n_windows, window_size, n_features)
            initial_balance: Starting cash balance
            max_position_size: Maximum position size as fraction of portfolio
            transaction_cost: Transaction cost as fraction of trade value
            window_size: Number of time steps in observation window
        """
        super().__init__()
        
        self.data = data
        self.symbols = list(data.keys())
        self.initial_balance = initial_balance
        self.max_position_size = max_position_size
        self.transaction_cost = transaction_cost
        self.window_size = window_size
        
        # Get number of features from data
        if self.symbols:
            n_features = data[self.symbols[0]].shape[2]
        else:
            n_features = 30  # Default
        
        # State space: [window_size * n_features for each stock] + [portfolio_state]
        # Portfolio state: [cash_ratio, total_positions, avg_position_value]
        state_size = len(self.symbols) * window_size * n_features + 3
        self.observation_space = spaces.Box(low=-1, high=1, shape=(state_size,), dtype=np.float32)
        
        # Action space: for each stock, we can [hold, buy, sell]
        # Encoded as: 0-2 for stock 0, 3-5 for stock 1, etc.
        self.action_space = spaces.Discrete(len(self.symbols) * 3)
        
        # Initialize state
        self.reset()
    
    def reset(self, seed: Optional[int] = None) -> Tuple[np.ndarray, Dict]:
        """
        Reset the environment to initial state.
        
        Args:
            seed: Random seed for reproducibility
            
        Returns:
            Tuple of (observation, info)
        """
        super().reset(seed=seed)
        
        # Initialize portfolio
        self.balance = self.initial_balance
        self.positions = {symbol: 0 for symbol in self.symbols}  # Quantity held
        self.position_costs = {symbol: 0.0 for symbol in self.symbols}  # Average entry price
        self.portfolio_value = self.initial_balance
        self.step_count = 0
        self.episode_reward = 0.0
        
        # Initialize data indices
        self.current_indices = {symbol: np.random.randint(0, len(self.data[symbol]) - 1) 
                               for symbol in self.symbols}
        
        # Initialize prices
        self.current_prices = {symbol: 100.0 for symbol in self.symbols}  # Placeholder
        
        observation = self._get_observation()
        info = {'portfolio_value': self.portfolio_value}
        
        return observation, info
    
    def _get_observation(self) -> np.ndarray:
        """
        Construct the current observation.
        
        Returns:
            Flattened observation array
        """
        obs_list = []
        
        # Add feature windows for each stock
        for symbol in self.symbols:
            idx = self.current_indices[symbol]
            if idx < len(self.data[symbol]):
                # Get current window
                window = self.data[symbol][idx]
                obs_list.append(window.flatten())
            else:
                # Pad with zeros if index out of bounds
                n_features = self.data[symbol].shape[2]
                obs_list.append(np.zeros(self.window_size * n_features))
        
        # Add portfolio state
        total_position_value = sum(self.positions[s] * self.current_prices[s] for s in self.symbols)
        cash_ratio = self.balance / (self.portfolio_value + 1e-8)
        total_positions = sum(abs(self.positions[s]) for s in self.symbols)
        avg_position_value = total_position_value / (total_positions + 1e-8)
        
        obs_list.extend([
            np.clip(cash_ratio, -1, 1),
            np.clip(total_positions / 100, -1, 1),  # Normalize
            np.clip(avg_position_value / 1000, -1, 1)  # Normalize
        ])
        
        observation = np.concatenate(obs_list).astype(np.float32)
        
        # Ensure correct shape
        if len(observation) < self.observation_space.shape[0]:
            observation = np.pad(observation, (0, self.observation_space.shape[0] - len(observation)))
        else:
            observation = observation[:self.observation_space.shape[0]]
        
        return observation
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """
        Execute one step in the environment.
        
        Args:
            action: Action index (0-2 for stock 0, 3-5 for stock 1, etc.)
            
        Returns:
            Tuple of (observation, reward, terminated, truncated, info)
        """
        # Decode action
        stock_idx = action // 3
        action_type = action % 3  # 0: hold, 1: buy, 2: sell
        
        if stock_idx >= len(self.symbols):
            stock_idx = len(self.symbols) - 1
        
        symbol = self.symbols[stock_idx]
        
        # Execute trade
        reward = 0.0
        
        if action_type == 1:  # Buy
            reward = self._execute_buy(symbol)
        elif action_type == 2:  # Sell
            reward = self._execute_sell(symbol)
        # action_type == 0: hold, no action
        
        # Update step
        self.step_count += 1
        self.episode_reward += reward
        
        # Update data indices
        for symbol in self.symbols:
            self.current_indices[symbol] = min(self.current_indices[symbol] + 1, 
                                              len(self.data[symbol]) - 1)
        
        # Update prices (simulate price movement)
        self._update_prices()
        
        # Calculate portfolio value
        self._update_portfolio_value()
        
        # Get new observation
        observation = self._get_observation()
        
        # Determine if episode is done
        terminated = self.step_count >= 250  # Max 250 steps per episode
        truncated = self.portfolio_value <= self.initial_balance * 0.5  # Stop if lost 50%
        done = terminated or truncated
        
        info = {
            'portfolio_value': self.portfolio_value,
            'balance': self.balance,
            'positions': self.positions.copy(),
            'episode_reward': self.episode_reward,
            'step': self.step_count
        }
        
        return observation, reward, terminated, truncated, info
    
    def _execute_buy(self, symbol: str) -> float:
        """
        Execute a buy order for a symbol.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Reward for this action
        """
        # Determine buy quantity
        max_buy_value = self.portfolio_value * self.max_position_size
        buy_quantity = int(max_buy_value / (self.current_prices[symbol] + 1e-8))
        
        if buy_quantity <= 0 or self.balance < buy_quantity * self.current_prices[symbol]:
            return -0.01  # Penalty for invalid buy
        
        # Execute buy
        trade_value = buy_quantity * self.current_prices[symbol]
        transaction_fee = trade_value * self.transaction_cost
        
        self.balance -= (trade_value + transaction_fee)
        self.positions[symbol] += buy_quantity
        self.position_costs[symbol] = self.current_prices[symbol]
        
        return -0.001  # Small cost for trading
    
    def _execute_sell(self, symbol: str) -> float:
        """
        Execute a sell order for a symbol.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Reward for this action
        """
        if self.positions[symbol] <= 0:
            return -0.01  # Penalty for invalid sell
        
        # Execute sell
        trade_value = self.positions[symbol] * self.current_prices[symbol]
        transaction_fee = trade_value * self.transaction_cost
        profit = trade_value - (self.positions[symbol] * self.position_costs[symbol])
        
        self.balance += (trade_value - transaction_fee)
        self.positions[symbol] = 0
        self.position_costs[symbol] = 0.0
        
        # Reward based on profit
        reward = profit / (self.initial_balance + 1e-8)
        
        return reward
    
    def _update_prices(self):
        """Update current prices based on data."""
        for symbol in self.symbols:
            idx = self.current_indices[symbol]
            if idx < len(self.data[symbol]):
                # Use first feature as price proxy (normalized close price)
                price_feature = self.data[symbol][idx, -1, 0]  # Last timestep, first feature
                # Denormalize price (assuming it was normalized to [-1, 1])
                self.current_prices[symbol] = 100 + price_feature * 20  # Approximate
    
    def _update_portfolio_value(self):
        """Update total portfolio value."""
        position_value = sum(self.positions[s] * self.current_prices[s] for s in self.symbols)
        self.portfolio_value = self.balance + position_value
    
    def render(self):
        """Render the environment (print state)."""
        print(f"Step: {self.step_count}")
        print(f"Portfolio Value: ${self.portfolio_value:.2f}")
        print(f"Balance: ${self.balance:.2f}")
        print(f"Positions: {self.positions}")
        print(f"Episode Reward: {self.episode_reward:.4f}")
        print("---")


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    # Create dummy data
    dummy_data = {
        'AVGO': np.random.randn(100, 60, 30).astype(np.float32),
        'TSLA': np.random.randn(100, 60, 30).astype(np.float32),
    }
    
    env = TradingEnvironment(dummy_data)
    obs, info = env.reset()
    
    for _ in range(10):
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        env.render()
        
        if terminated or truncated:
            break
