"""
LSTM-based feature extractor for RL trading agent.
Extracts temporal patterns from historical price data.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Tuple, Optional
import logging

logger = logging.getLogger(__name__)


class LSTMFeatureExtractor(nn.Module):
    """
    LSTM-based feature extractor for time series data.
    Extracts temporal patterns and outputs fixed-size feature vectors.
    """
    
    def __init__(self, input_size: int, hidden_size: int = 128, 
                 num_layers: int = 2, dropout: float = 0.2):
        """
        Initialize the LSTM feature extractor.
        
        Args:
            input_size: Number of input features per timestep
            hidden_size: Size of LSTM hidden state
            num_layers: Number of LSTM layers
            dropout: Dropout rate
        """
        super().__init__()
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # LSTM layers
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0,
            batch_first=True
        )
        
        # Output projection
        self.fc = nn.Linear(hidden_size, hidden_size)
        self.activation = nn.ReLU()
        
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]:
        """
        Forward pass through the LSTM.
        
        Args:
            x: Input tensor of shape (batch_size, seq_len, input_size)
            
        Returns:
            Tuple of (output features, (hidden state, cell state))
        """
        # LSTM forward pass
        lstm_out, (h_n, c_n) = self.lstm(x)
        
        # Use last output
        last_output = lstm_out[:, -1, :]
        
        # Project to feature space
        features = self.activation(self.fc(last_output))
        
        return features, (h_n, c_n)
    
    def extract_features(self, x: np.ndarray) -> np.ndarray:
        """
        Extract features from numpy array.
        
        Args:
            x: Input array of shape (batch_size, seq_len, input_size) or (seq_len, input_size)
            
        Returns:
            Feature array of shape (batch_size, hidden_size) or (hidden_size,)
        """
        # Convert to tensor
        if x.ndim == 2:
            x = np.expand_dims(x, 0)  # Add batch dimension
            squeeze_output = True
        else:
            squeeze_output = False
        
        x_tensor = torch.from_numpy(x).float()
        
        # Forward pass
        with torch.no_grad():
            features, _ = self.forward(x_tensor)
        
        # Convert back to numpy
        features_np = features.cpu().numpy()
        
        if squeeze_output:
            features_np = features_np[0]
        
        return features_np


class TransformerFeatureExtractor(nn.Module):
    """
    Transformer-based feature extractor for time series data.
    Alternative to LSTM with better long-term dependency modeling.
    """
    
    def __init__(self, input_size: int, hidden_size: int = 128,
                 num_heads: int = 4, num_layers: int = 2, dropout: float = 0.2):
        """
        Initialize the Transformer feature extractor.
        
        Args:
            input_size: Number of input features per timestep
            hidden_size: Size of hidden dimension
            num_heads: Number of attention heads
            num_layers: Number of transformer layers
            dropout: Dropout rate
        """
        super().__init__()
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        
        # Input projection
        self.input_proj = nn.Linear(input_size, hidden_size)
        
        # Positional encoding
        self.pos_encoding = self._create_positional_encoding(hidden_size, max_len=500)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_size,
            nhead=num_heads,
            dim_feedforward=hidden_size * 4,
            dropout=dropout,
            batch_first=True,
            activation='relu'
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        
        # Output projection
        self.fc = nn.Linear(hidden_size, hidden_size)
        self.activation = nn.ReLU()
    
    def _create_positional_encoding(self, d_model: int, max_len: int = 500) -> torch.Tensor:
        """Create positional encoding for transformer."""
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * 
                            (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        return pe
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through the Transformer.
        
        Args:
            x: Input tensor of shape (batch_size, seq_len, input_size)
            
        Returns:
            Output features of shape (batch_size, hidden_size)
        """
        # Project input
        x = self.input_proj(x)
        
        # Add positional encoding
        seq_len = x.size(1)
        pe = self.pos_encoding[:seq_len, :].unsqueeze(0).to(x.device)
        x = x + pe
        
        # Transformer forward pass
        transformer_out = self.transformer_encoder(x)
        
        # Use last output
        last_output = transformer_out[:, -1, :]
        
        # Project to feature space
        features = self.activation(self.fc(last_output))
        
        return features
    
    def extract_features(self, x: np.ndarray) -> np.ndarray:
        """
        Extract features from numpy array.
        
        Args:
            x: Input array of shape (batch_size, seq_len, input_size) or (seq_len, input_size)
            
        Returns:
            Feature array of shape (batch_size, hidden_size) or (hidden_size,)
        """
        # Convert to tensor
        if x.ndim == 2:
            x = np.expand_dims(x, 0)  # Add batch dimension
            squeeze_output = True
        else:
            squeeze_output = False
        
        x_tensor = torch.from_numpy(x).float()
        
        # Forward pass
        with torch.no_grad():
            features = self.forward(x_tensor)
        
        # Convert back to numpy
        features_np = features.cpu().numpy()
        
        if squeeze_output:
            features_np = features_np[0]
        
        return features_np


class CombinedFeatureExtractor(nn.Module):
    """
    Combined feature extractor using both LSTM and Transformer.
    Captures both short-term and long-term dependencies.
    """
    
    def __init__(self, input_size: int, hidden_size: int = 128):
        """
        Initialize the combined feature extractor.
        
        Args:
            input_size: Number of input features per timestep
            hidden_size: Size of hidden dimension
        """
        super().__init__()
        
        self.lstm_extractor = LSTMFeatureExtractor(input_size, hidden_size)
        self.transformer_extractor = TransformerFeatureExtractor(input_size, hidden_size)
        
        # Fusion layer
        self.fusion = nn.Linear(hidden_size * 2, hidden_size)
        self.activation = nn.ReLU()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through combined extractors.
        
        Args:
            x: Input tensor of shape (batch_size, seq_len, input_size)
            
        Returns:
            Output features of shape (batch_size, hidden_size)
        """
        # Extract features from both models
        lstm_features, _ = self.lstm_extractor(x)
        transformer_features = self.transformer_extractor(x)
        
        # Concatenate and fuse
        combined = torch.cat([lstm_features, transformer_features], dim=1)
        fused_features = self.activation(self.fusion(combined))
        
        return fused_features
    
    def extract_features(self, x: np.ndarray) -> np.ndarray:
        """
        Extract features from numpy array.
        
        Args:
            x: Input array of shape (batch_size, seq_len, input_size) or (seq_len, input_size)
            
        Returns:
            Feature array of shape (batch_size, hidden_size) or (hidden_size,)
        """
        # Convert to tensor
        if x.ndim == 2:
            x = np.expand_dims(x, 0)  # Add batch dimension
            squeeze_output = True
        else:
            squeeze_output = False
        
        x_tensor = torch.from_numpy(x).float()
        
        # Forward pass
        with torch.no_grad():
            features = self.forward(x_tensor)
        
        # Convert back to numpy
        features_np = features.cpu().numpy()
        
        if squeeze_output:
            features_np = features_np[0]
        
        return features_np


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    # Create dummy data
    batch_size = 4
    seq_len = 60
    input_size = 30
    
    x = np.random.randn(batch_size, seq_len, input_size).astype(np.float32)
    
    # Test LSTM extractor
    lstm_extractor = LSTMFeatureExtractor(input_size)
    lstm_features = lstm_extractor.extract_features(x)
    print(f"LSTM features shape: {lstm_features.shape}")
    
    # Test Transformer extractor
    transformer_extractor = TransformerFeatureExtractor(input_size)
    transformer_features = transformer_extractor.extract_features(x)
    print(f"Transformer features shape: {transformer_features.shape}")
    
    # Test Combined extractor
    combined_extractor = CombinedFeatureExtractor(input_size)
    combined_features = combined_extractor.extract_features(x)
    print(f"Combined features shape: {combined_features.shape}")
