import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { TrendingUp, BarChart3, Zap, Shield } from "lucide-react";

export default function Home() {
  const { isAuthenticated, user } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-white">IBKR RL Trading Bot</h1>
            <p className="text-slate-400 text-sm">Automated reinforcement learning trading system</p>
          </div>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-slate-300 py-2">Welcome, {user?.name}</span>
                <Button onClick={() => navigate("/dashboard")} className="bg-blue-600 hover:bg-blue-700">
                  Go to Dashboard
                </Button>
              </>
            ) : (
              <Button onClick={() => window.location.href = getLoginUrl()} className="bg-blue-600 hover:bg-blue-700">
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-white mb-4">Intelligent Trading, Automated</h2>
          <p className="text-xl text-slate-400 mb-8">
            Harness the power of reinforcement learning to trade 8 major stocks with precision and discipline
          </p>
          {isAuthenticated ? (
            <Button size="lg" onClick={() => navigate("/dashboard")} className="bg-blue-600 hover:bg-blue-700 text-white">
              Access Dashboard
            </Button>
          ) : (
            <Button size="lg" onClick={() => window.location.href = getLoginUrl()} className="bg-blue-600 hover:bg-blue-700 text-white">
              Get Started
            </Button>
          )}
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-600 transition">
            <CardHeader>
              <TrendingUp className="w-8 h-8 text-blue-400 mb-2" />
              <CardTitle className="text-white">RL Trading Agent</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-slate-400">
                PPO-based agent trained on historical data with LSTM feature extraction
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-green-600 transition">
            <CardHeader>
              <BarChart3 className="w-8 h-8 text-green-400 mb-2" />
              <CardTitle className="text-white">Real-time Monitoring</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-slate-400">
                Live portfolio tracking, P&L charts, and trade history
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-yellow-600 transition">
            <CardHeader>
              <Zap className="w-8 h-8 text-yellow-400 mb-2" />
              <CardTitle className="text-white">IBKR Integration</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-slate-400">
                Direct connection to Interactive Brokers for live trading execution
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-purple-600 transition">
            <CardHeader>
              <Shield className="w-8 h-8 text-purple-400 mb-2" />
              <CardTitle className="text-white">Risk Management</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-slate-400">
                Position sizing, stop-loss, and portfolio rebalancing controls
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Stocks Section */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 mb-16">
          <h3 className="text-2xl font-bold text-white mb-6">Trading Universe</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {["AVGO", "TSLA", "MU", "COST", "ABBV", "NFLX", "INTC", "IBM"].map((symbol) => (
              <div key={symbol} className="bg-slate-700/50 border border-slate-600 rounded p-4 text-center hover:border-blue-500 transition">
                <p className="text-2xl font-bold text-blue-400">{symbol}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-12 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">Ready to Start Trading?</h3>
          <p className="text-lg text-blue-100 mb-8">
            Connect your Interactive Brokers account and let the RL agent handle your portfolio
          </p>
          {isAuthenticated ? (
            <Button size="lg" onClick={() => navigate("/dashboard")} className="bg-white text-blue-600 hover:bg-slate-100">
              Go to Dashboard
            </Button>
          ) : (
            <Button size="lg" onClick={() => window.location.href = getLoginUrl()} className="bg-white text-blue-600 hover:bg-slate-100">
              Sign In to Get Started
            </Button>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-800/50 mt-20 py-8">
        <div className="max-w-7xl mx-auto px-6 text-center text-slate-400 text-sm">
          <p>IBKR RL Trading Bot © 2026. Built with Stable-Baselines3, ib_insync, and React.</p>
        </div>
      </footer>
    </div>
  );
}
