"""
Trading orchestrator that coordinates between RL agent, market data, and IBKR.
Implements risk management, scheduling, and trade execution.
"""

import asyncio
import numpy as np
from typing import Dict, Optional, List
from datetime import datetime, time
import logging
from enum import Enum

logger = logging.getLogger(__name__)


class TradingState(Enum):
    """Trading state enum."""
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"


class RiskManager:
    """
    Manages risk constraints for trading.
    """
    
    def __init__(self, max_position_size: float = 0.3,
                 max_total_exposure: float = 0.9,
                 stop_loss_percent: float = 0.05,
                 take_profit_percent: float = 0.10):
        """
        Initialize risk manager.
        
        Args:
            max_position_size: Max size of single position as % of portfolio
            max_total_exposure: Max total exposure as % of portfolio
            stop_loss_percent: Stop loss percentage
            take_profit_percent: Take profit percentage
        """
        self.max_position_size = max_position_size
        self.max_total_exposure = max_total_exposure
        self.stop_loss_percent = stop_loss_percent
        self.take_profit_percent = take_profit_percent
    
    def validate_trade(self, symbol: str, quantity: int, price: float,
                      portfolio_value: float, current_positions: Dict[str, int],
                      current_prices: Dict[str, float]) -> bool:
        """
        Validate if a trade respects risk constraints.
        
        Args:
            symbol: Stock symbol
            quantity: Quantity to trade
            price: Current price
            portfolio_value: Total portfolio value
            current_positions: Current positions
            current_prices: Current prices for all symbols
            
        Returns:
            True if trade is valid, False otherwise
        """
        # Calculate trade value
        trade_value = quantity * price
        
        # Check position size constraint
        if trade_value > portfolio_value * self.max_position_size:
            logger.warning(f"Trade exceeds max position size: {trade_value} > {portfolio_value * self.max_position_size}")
            return False
        
        # Calculate total exposure
        total_exposure = sum(abs(current_positions.get(s, 0)) * current_prices.get(s, 0) 
                           for s in current_positions)
        total_exposure += trade_value
        
        if total_exposure > portfolio_value * self.max_total_exposure:
            logger.warning(f"Trade exceeds max total exposure: {total_exposure} > {portfolio_value * self.max_total_exposure}")
            return False
        
        return True
    
    def check_stop_loss(self, symbol: str, entry_price: float, current_price: float) -> bool:
        """
        Check if position should be stopped out.
        
        Args:
            symbol: Stock symbol
            entry_price: Entry price
            current_price: Current price
            
        Returns:
            True if stop loss triggered, False otherwise
        """
        loss_percent = (current_price - entry_price) / entry_price
        if loss_percent <= -self.stop_loss_percent:
            logger.info(f"Stop loss triggered for {symbol}: {loss_percent:.2%}")
            return True
        return False
    
    def check_take_profit(self, symbol: str, entry_price: float, current_price: float) -> bool:
        """
        Check if position should take profit.
        
        Args:
            symbol: Stock symbol
            entry_price: Entry price
            current_price: Current price
            
        Returns:
            True if take profit triggered, False otherwise
        """
        profit_percent = (current_price - entry_price) / entry_price
        if profit_percent >= self.take_profit_percent:
            logger.info(f"Take profit triggered for {symbol}: {profit_percent:.2%}")
            return True
        return False


class TradingOrchestrator:
    """
    Orchestrates trading between RL agent, market data, and IBKR.
    """
    
    def __init__(self, rl_agent, ibkr_connector, risk_manager: RiskManager,
                 trading_symbols: List[str],
                 trading_start_hour: int = 9,
                 trading_end_hour: int = 16,
                 min_trade_interval: int = 300):
        """
        Initialize the trading orchestrator.
        
        Args:
            rl_agent: Trained RL agent
            ibkr_connector: IBKR connector instance
            risk_manager: Risk manager instance
            trading_symbols: List of symbols to trade
            trading_start_hour: Start hour for trading (24-hour format)
            trading_end_hour: End hour for trading
            min_trade_interval: Minimum seconds between trades
        """
        self.rl_agent = rl_agent
        self.ibkr_connector = ibkr_connector
        self.risk_manager = risk_manager
        self.trading_symbols = trading_symbols
        self.trading_start_hour = trading_start_hour
        self.trading_end_hour = trading_end_hour
        self.min_trade_interval = min_trade_interval
        
        self.state = TradingState.IDLE
        self.last_trade_time = 0
        self.trade_history: List[Dict] = []
        self.position_entry_prices: Dict[str, float] = {}
    
    async def start_trading(self) -> None:
        """
        Start the trading loop.
        """
        self.state = TradingState.RUNNING
        logger.info("Trading started")
        
        try:
            while self.state == TradingState.RUNNING:
                # Check if market is open
                if not self._is_trading_hours():
                    logger.debug("Outside trading hours, waiting...")
                    await asyncio.sleep(60)
                    continue
                
                # Get current market data
                market_data = await self._get_market_data()
                
                if not market_data:
                    await asyncio.sleep(5)
                    continue
                
                # Get RL agent prediction
                action = await self._get_agent_action(market_data)
                
                # Execute trade if needed
                await self._execute_trade(action, market_data)
                
                # Check stop loss / take profit
                await self._check_risk_management()
                
                # Sleep before next iteration
                await asyncio.sleep(30)
        
        except Exception as e:
            logger.error(f"Error in trading loop: {e}")
            self.state = TradingState.ERROR
    
    def pause_trading(self) -> None:
        """
        Pause trading.
        """
        if self.state == TradingState.RUNNING:
            self.state = TradingState.PAUSED
            logger.info("Trading paused")
    
    def resume_trading(self) -> None:
        """
        Resume trading.
        """
        if self.state == TradingState.PAUSED:
            self.state = TradingState.RUNNING
            logger.info("Trading resumed")
    
    def stop_trading(self) -> None:
        """
        Stop trading.
        """
        self.state = TradingState.IDLE
        logger.info("Trading stopped")
    
    def _is_trading_hours(self) -> bool:
        """
        Check if current time is within trading hours.
        
        Returns:
            True if within trading hours, False otherwise
        """
        now = datetime.now()
        
        # Check if it's a weekday
        if now.weekday() >= 5:
            return False
        
        # Check hour
        if now.hour < self.trading_start_hour or now.hour >= self.trading_end_hour:
            return False
        
        return True
    
    async def _get_market_data(self) -> Optional[Dict]:
        """
        Get current market data for all trading symbols.
        
        Returns:
            Dictionary with market data or None
        """
        market_data = {}
        
        for symbol in self.trading_symbols:
            data = self.ibkr_connector.get_market_data(symbol)
            if data:
                market_data[symbol] = data
        
        if not market_data:
            logger.warning("No market data available")
            return None
        
        return market_data
    
    async def _get_agent_action(self, market_data: Dict) -> Optional[int]:
        """
        Get action from RL agent.
        
        Args:
            market_data: Current market data
            
        Returns:
            Action index or None
        """
        try:
            # Construct observation from market data
            # This is simplified - in practice, you'd use the full feature extraction
            obs = np.array([
                market_data[s]['bid'] for s in self.trading_symbols
            ] + [
                market_data[s]['ask'] for s in self.trading_symbols
            ], dtype=np.float32)
            
            # Get action from agent
            action, _ = self.rl_agent.predict(obs, deterministic=True)
            
            return action
        
        except Exception as e:
            logger.error(f"Error getting agent action: {e}")
            return None
    
    async def _execute_trade(self, action: Optional[int], market_data: Dict) -> None:
        """
        Execute trade based on agent action.
        
        Args:
            action: Action from agent
            market_data: Current market data
        """
        if action is None:
            return
        
        # Check trade interval
        current_time = datetime.now().timestamp()
        if current_time - self.last_trade_time < self.min_trade_interval:
            return
        
        # Decode action
        stock_idx = action // 3
        action_type = action % 3
        
        if stock_idx >= len(self.trading_symbols):
            return
        
        symbol = self.trading_symbols[stock_idx]
        
        if symbol not in market_data:
            return
        
        price = market_data[symbol]['last'] or market_data[symbol]['ask']
        portfolio_value = self.ibkr_connector.get_portfolio_value()
        current_positions = self.ibkr_connector.get_positions()
        current_prices = {s: market_data[s]['last'] for s in market_data}
        
        try:
            if action_type == 1:  # Buy
                quantity = int(portfolio_value * 0.1 / price)  # Buy 10% of portfolio
                
                if quantity > 0 and self.risk_manager.validate_trade(
                    symbol, quantity, price, portfolio_value, current_positions, current_prices
                ):
                    order_id = self.ibkr_connector.place_market_order(symbol, quantity, 'BUY')
                    
                    if order_id:
                        self.position_entry_prices[symbol] = price
                        self.trade_history.append({
                            'timestamp': datetime.now().isoformat(),
                            'symbol': symbol,
                            'action': 'BUY',
                            'quantity': quantity,
                            'price': price,
                            'order_id': order_id
                        })
                        self.last_trade_time = current_time
                        logger.info(f"Executed BUY order for {quantity} shares of {symbol} @ ${price}")
            
            elif action_type == 2:  # Sell
                quantity = current_positions.get(symbol, 0)
                
                if quantity > 0:
                    order_id = self.ibkr_connector.place_market_order(symbol, quantity, 'SELL')
                    
                    if order_id:
                        entry_price = self.position_entry_prices.get(symbol, price)
                        profit = (price - entry_price) * quantity
                        
                        self.trade_history.append({
                            'timestamp': datetime.now().isoformat(),
                            'symbol': symbol,
                            'action': 'SELL',
                            'quantity': quantity,
                            'price': price,
                            'entry_price': entry_price,
                            'profit': profit,
                            'order_id': order_id
                        })
                        self.last_trade_time = current_time
                        logger.info(f"Executed SELL order for {quantity} shares of {symbol} @ ${price}, Profit: ${profit:.2f}")
                        
                        if symbol in self.position_entry_prices:
                            del self.position_entry_prices[symbol]
        
        except Exception as e:
            logger.error(f"Error executing trade: {e}")
    
    async def _check_risk_management(self) -> None:
        """
        Check and enforce risk management rules (stop loss, take profit).
        """
        current_positions = self.ibkr_connector.get_positions()
        
        for symbol in current_positions:
            if current_positions[symbol] <= 0:
                continue
            
            market_data = self.ibkr_connector.get_market_data(symbol)
            if not market_data:
                continue
            
            current_price = market_data['last'] or market_data['ask']
            entry_price = self.position_entry_prices.get(symbol)
            
            if not entry_price:
                continue
            
            # Check stop loss
            if self.risk_manager.check_stop_loss(symbol, entry_price, current_price):
                quantity = current_positions[symbol]
                self.ibkr_connector.place_market_order(symbol, quantity, 'SELL')
                logger.warning(f"Stop loss triggered for {symbol}")
            
            # Check take profit
            elif self.risk_manager.check_take_profit(symbol, entry_price, current_price):
                quantity = current_positions[symbol]
                self.ibkr_connector.place_market_order(symbol, quantity, 'SELL')
                logger.info(f"Take profit triggered for {symbol}")
    
    def get_trade_history(self) -> List[Dict]:
        """
        Get trade history.
        
        Returns:
            List of trade records
        """
        return self.trade_history.copy()
    
    def get_status(self) -> Dict:
        """
        Get current trading status.
        
        Returns:
            Status dictionary
        """
        return {
            'state': self.state.value,
            'portfolio_value': self.ibkr_connector.get_portfolio_value(),
            'cash_balance': self.ibkr_connector.get_cash_balance(),
            'positions': self.ibkr_connector.get_positions(),
            'total_trades': len(self.trade_history)
        }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    logger.info("Trading orchestrator module loaded")
