"""
Hybrid Neural Network Architecture combining LSTM and CNN
for learning price patterns from raw OHLCV data.
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import Tuple, Dict, List
import logging

logger = logging.getLogger(__name__)


class CNNBlock(nn.Module):
    """
    CNN block for local pattern detection.
    """
    
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3):
        """
        Initialize CNN block.
        
        Args:
            in_channels: Number of input channels
            out_channels: Number of output channels
            kernel_size: Size of convolution kernel
        """
        super(CNNBlock, self).__init__()
        
        self.conv = nn.Conv1d(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            padding=kernel_size // 2
        )
        self.bn = nn.BatchNorm1d(out_channels)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)
    
    def forward(self, x):
        """Forward pass."""
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        x = self.dropout(x)
        return x


class LSTMBlock(nn.Module):
    """
    LSTM block for temporal pattern learning.
    """
    
    def __init__(self, input_size: int, hidden_size: int, num_layers: int = 2):
        """
        Initialize LSTM block.
        
        Args:
            input_size: Size of input features
            hidden_size: Size of hidden state
            num_layers: Number of LSTM layers
        """
        super(LSTMBlock, self).__init__()
        
        self.lstm = nn.LSTM(
            input_size,
            hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.2 if num_layers > 1 else 0
        )
        self.dropout = nn.Dropout(0.2)
    
    def forward(self, x):
        """Forward pass."""
        lstm_out, (h_n, c_n) = self.lstm(x)
        # Use last hidden state
        out = lstm_out[:, -1, :]
        out = self.dropout(out)
        return out, lstm_out


class HybridPricePredictor(nn.Module):
    """
    Hybrid neural network combining CNN and LSTM for price prediction.
    """
    
    def __init__(self,
                 sequence_length: int = 30,
                 num_features: int = 5,  # OHLCV
                 cnn_channels: List[int] = None,
                 lstm_hidden_size: int = 64,
                 lstm_layers: int = 2,
                 dense_units: List[int] = None,
                 sentiment_dim: int = 30):
        """
        Initialize hybrid network.
        
        Args:
            sequence_length: Length of input sequences
            num_features: Number of features (OHLCV = 5)
            cnn_channels: List of CNN channel sizes
            lstm_hidden_size: LSTM hidden state size
            lstm_layers: Number of LSTM layers
            dense_units: List of dense layer sizes
            sentiment_dim: Dimension of sentiment input
        """
        super(HybridPricePredictor, self).__init__()
        
        if cnn_channels is None:
            cnn_channels = [32, 64, 128]
        if dense_units is None:
            dense_units = [256, 128]
        
        self.sequence_length = sequence_length
        self.num_features = num_features
        self.sentiment_dim = sentiment_dim
        
        # CNN branch for local pattern detection
        self.cnn_layers = nn.ModuleList()
        in_channels = num_features
        
        for out_channels in cnn_channels:
            self.cnn_layers.append(CNNBlock(in_channels, out_channels, kernel_size=3))
            in_channels = out_channels
        
        # LSTM branch for temporal patterns
        self.lstm = LSTMBlock(num_features, lstm_hidden_size, lstm_layers)
        
        # Combine CNN and LSTM outputs
        cnn_output_size = cnn_channels[-1] * sequence_length
        lstm_output_size = lstm_hidden_size
        
        # Dense layers after concatenation
        combined_size = cnn_output_size + lstm_output_size + sentiment_dim
        
        self.dense_layers = nn.ModuleList()
        in_size = combined_size
        
        for out_size in dense_units:
            self.dense_layers.append(nn.Linear(in_size, out_size))
            self.dense_layers.append(nn.ReLU())
            self.dense_layers.append(nn.Dropout(0.3))
            in_size = out_size
        
        # Output layer for price prediction
        self.output_layer = nn.Linear(in_size, 1)
        self.output_activation = nn.Sigmoid()  # Output normalized to 0-1
    
    def forward(self, price_data: torch.Tensor, sentiment_data: torch.Tensor = None):
        """
        Forward pass.
        
        Args:
            price_data: Tensor of shape (batch_size, sequence_length, num_features)
            sentiment_data: Optional tensor of shape (batch_size, sentiment_dim)
            
        Returns:
            Predicted normalized price (0-1)
        """
        # CNN branch: transpose to (batch_size, num_features, sequence_length)
        cnn_input = price_data.transpose(1, 2)
        cnn_out = cnn_input
        
        for cnn_layer in self.cnn_layers:
            cnn_out = cnn_layer(cnn_out)
        
        # Flatten CNN output
        cnn_out = cnn_out.reshape(cnn_out.size(0), -1)
        
        # LSTM branch
        lstm_out, _ = self.lstm(price_data)
        
        # Concatenate CNN and LSTM outputs
        combined = torch.cat([cnn_out, lstm_out], dim=1)
        
        # Add sentiment if provided
        if sentiment_data is not None:
            combined = torch.cat([combined, sentiment_data], dim=1)
        else:
            # Pad with zeros if sentiment not provided
            batch_size = combined.size(0)
            sentiment_padding = torch.zeros(batch_size, self.sentiment_dim, device=combined.device)
            combined = torch.cat([combined, sentiment_padding], dim=1)
        
        # Dense layers
        x = combined
        for layer in self.dense_layers:
            x = layer(x)
        
        # Output
        output = self.output_layer(x)
        output = self.output_activation(output)
        
        return output


class PricePredictor:
    """
    Wrapper for training and using the price prediction model.
    """
    
    def __init__(self, 
                 device: str = 'cuda' if torch.cuda.is_available() else 'cpu',
                 learning_rate: float = 0.001):
        """
        Initialize predictor.
        
        Args:
            device: Device to use ('cuda' or 'cpu')
            learning_rate: Learning rate for optimizer
        """
        self.device = device
        self.learning_rate = learning_rate
        self.model = None
        self.optimizer = None
        self.criterion = nn.MSELoss()
        self.training_history = []
    
    def build_model(self, 
                   sequence_length: int = 30,
                   num_features: int = 5,
                   sentiment_dim: int = 30):
        """
        Build the neural network model.
        
        Args:
            sequence_length: Length of input sequences
            num_features: Number of features (OHLCV)
            sentiment_dim: Dimension of sentiment input
        """
        self.model = HybridPricePredictor(
            sequence_length=sequence_length,
            num_features=num_features,
            sentiment_dim=sentiment_dim
        ).to(self.device)
        
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        
        logger.info(f"Model built with {sum(p.numel() for p in self.model.parameters())} parameters")
    
    def train(self,
             X_train: np.ndarray,
             y_train: np.ndarray,
             X_val: np.ndarray = None,
             y_val: np.ndarray = None,
             sentiment_train: np.ndarray = None,
             sentiment_val: np.ndarray = None,
             epochs: int = 50,
             batch_size: int = 32):
        """
        Train the model.
        
        Args:
            X_train: Training input data
            y_train: Training target data
            X_val: Validation input data
            y_val: Validation target data
            sentiment_train: Training sentiment data
            sentiment_val: Validation sentiment data
            epochs: Number of training epochs
            batch_size: Batch size for training
        """
        if self.model is None:
            raise ValueError("Model not built. Call build_model() first.")
        
        self.model.train()
        
        # Convert to tensors
        X_train_tensor = torch.from_numpy(X_train).to(self.device)
        y_train_tensor = torch.from_numpy(y_train).unsqueeze(1).to(self.device)
        
        if sentiment_train is not None:
            sentiment_train_tensor = torch.from_numpy(sentiment_train).to(self.device)
        else:
            sentiment_train_tensor = None
        
        num_batches = len(X_train) // batch_size
        
        for epoch in range(epochs):
            epoch_loss = 0.0
            
            # Shuffle data
            indices = np.random.permutation(len(X_train))
            X_train_shuffled = X_train[indices]
            y_train_shuffled = y_train[indices]
            
            if sentiment_train is not None:
                sentiment_train_shuffled = sentiment_train[indices]
            
            # Mini-batch training
            for batch_idx in range(num_batches):
                start_idx = batch_idx * batch_size
                end_idx = start_idx + batch_size
                
                X_batch = torch.from_numpy(X_train_shuffled[start_idx:end_idx]).to(self.device)
                y_batch = torch.from_numpy(y_train_shuffled[start_idx:end_idx]).unsqueeze(1).to(self.device)
                
                if sentiment_train is not None:
                    sentiment_batch = torch.from_numpy(sentiment_train_shuffled[start_idx:end_idx]).to(self.device)
                else:
                    sentiment_batch = None
                
                # Forward pass
                self.optimizer.zero_grad()
                predictions = self.model(X_batch, sentiment_batch)
                loss = self.criterion(predictions, y_batch)
                
                # Backward pass
                loss.backward()
                self.optimizer.step()
                
                epoch_loss += loss.item()
            
            avg_loss = epoch_loss / num_batches
            
            # Validation
            if X_val is not None and y_val is not None:
                val_loss = self.evaluate(X_val, y_val, sentiment_val)
                logger.info(f"Epoch {epoch+1}/{epochs} - Train Loss: {avg_loss:.6f}, Val Loss: {val_loss:.6f}")
                self.training_history.append({'epoch': epoch+1, 'train_loss': avg_loss, 'val_loss': val_loss})
            else:
                logger.info(f"Epoch {epoch+1}/{epochs} - Train Loss: {avg_loss:.6f}")
                self.training_history.append({'epoch': epoch+1, 'train_loss': avg_loss})
    
    def evaluate(self, X_val: np.ndarray, y_val: np.ndarray, sentiment_val: np.ndarray = None) -> float:
        """
        Evaluate model on validation data.
        
        Args:
            X_val: Validation input data
            y_val: Validation target data
            sentiment_val: Validation sentiment data
            
        Returns:
            Validation loss
        """
        self.model.eval()
        
        with torch.no_grad():
            X_val_tensor = torch.from_numpy(X_val).to(self.device)
            y_val_tensor = torch.from_numpy(y_val).unsqueeze(1).to(self.device)
            
            if sentiment_val is not None:
                sentiment_val_tensor = torch.from_numpy(sentiment_val).to(self.device)
            else:
                sentiment_val_tensor = None
            
            predictions = self.model(X_val_tensor, sentiment_val_tensor)
            loss = self.criterion(predictions, y_val_tensor)
        
        self.model.train()
        return loss.item()
    
    def predict(self, X: np.ndarray, sentiment: np.ndarray = None) -> np.ndarray:
        """
        Make predictions.
        
        Args:
            X: Input data
            sentiment: Optional sentiment data
            
        Returns:
            Predicted normalized prices
        """
        self.model.eval()
        
        with torch.no_grad():
            X_tensor = torch.from_numpy(X).to(self.device)
            
            if sentiment is not None:
                sentiment_tensor = torch.from_numpy(sentiment).to(self.device)
            else:
                sentiment_tensor = None
            
            predictions = self.model(X_tensor, sentiment_tensor)
        
        return predictions.cpu().numpy()
    
    def save_model(self, path: str):
        """Save model to file."""
        torch.save(self.model.state_dict(), path)
        logger.info(f"Model saved to {path}")
    
    def load_model(self, path: str):
        """Load model from file."""
        if self.model is None:
            raise ValueError("Model not built. Call build_model() first.")
        
        self.model.load_state_dict(torch.load(path, map_location=self.device))
        logger.info(f"Model loaded from {path}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    predictor = PricePredictor()
    predictor.build_model(sequence_length=30, num_features=5, sentiment_dim=30)
    
    # Create dummy data
    X_train = np.random.randn(1000, 30, 5).astype(np.float32)
    y_train = np.random.rand(1000).astype(np.float32)
    X_val = np.random.randn(200, 30, 5).astype(np.float32)
    y_val = np.random.rand(200).astype(np.float32)
    sentiment_train = np.random.randn(1000, 30).astype(np.float32)
    sentiment_val = np.random.randn(200, 30).astype(np.float32)
    
    # Train
    predictor.train(X_train, y_train, X_val, y_val, sentiment_train, sentiment_val, epochs=5)
    
    # Predict
    predictions = predictor.predict(X_val[:10], sentiment_val[:10])
    print(f"Predictions shape: {predictions.shape}")
    print(f"Sample predictions: {predictions[:5].flatten()}")
