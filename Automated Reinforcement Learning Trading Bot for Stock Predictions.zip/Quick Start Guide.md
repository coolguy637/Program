# Quick Start Guide

Get the IBKR RL Trading Bot up and running in 5 minutes.

## Prerequisites

- Python 3.8+
- Interactive Brokers account
- TWS or IB Gateway installed and running

## Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

This installs:
- PyTorch (neural networks)
- TensorFlow (optional, for alternative models)
- Stable Baselines3 (RL algorithms)
- ib_insync (IBKR connection)
- yfinance (historical data)
- VADER Sentiment (sentiment analysis)
- And more...

## Step 2: Configure IBKR Connection

1. **Start TWS or IB Gateway**
   - Download from https://www.interactivebrokers.com
   - Log in with your credentials
   - Go to Settings → API → Enable API

2. **Create config.json**
   ```bash
   cp config.example.json config.json
   ```

3. **Edit config.json** with your settings:
   ```json
   {
     "ibkr_host": "127.0.0.1",
     "ibkr_port": 7497,
     "ibkr_client_id": 1,
     "trading_enabled": false,
     "initial_balance": 100000
   }
   ```

## Step 3: Test Connection

```python
import asyncio
from ibkr_connector import IBKRConnector

async def test():
    connector = IBKRConnector()
    if await connector.connect():
        print("Connected to IBKR!")
        print(f"Portfolio Value: ${connector.get_portfolio_value():.2f}")
        connector.disconnect()
    else:
        print("Failed to connect")

asyncio.run(test())
```

## Step 4: Train Models (Optional)

Train models on historical data before live trading:

```python
from data_pipeline import DataPipeline
from neural_network import PricePredictor
import numpy as np

# Fetch data
symbols = ['TSLA', 'AAPL']
pipeline = DataPipeline(symbols)
pipeline.fetch_historical_data()
pipeline.normalize_data()

# Create sequences
X, y = pipeline.create_sequences(sequence_length=30)

# Train
predictor = PricePredictor()
predictor.build_model()

# Combine data
X_train = np.vstack([X[s] for s in symbols if s in X])
y_train = np.hstack([y[s] for s in symbols if s in y])

predictor.train(X_train, y_train, epochs=10)
predictor.save_model('models/price_predictor.pt')
```

## Step 5: Run the Bot

```bash
python trading_bot.py
```

The bot will:
1. Connect to IBKR
2. Fetch historical data
3. Train initial models
4. Subscribe to market data
5. Start trading (if enabled in config)

## Paper Trading (Recommended First)

Before live trading, test on paper account:

1. Ensure `ibkr_port` is 7497 (paper trading)
2. Set `trading_enabled` to false
3. Run bot to collect data
4. Review decisions in logs
5. Verify performance

## Live Trading

⚠️ **WARNING**: This uses real money!

1. Switch to live account in TWS
2. Set `ibkr_port` to 7496
3. Set `trading_enabled` to true
4. Start with small position sizes
5. Monitor closely

## Monitoring

### Check Logs

```bash
# View main log
tail -f trading_bot.log

# View recent trades
tail -f logs/trades_*.json
```

### Check Portfolio

```python
from ibkr_connector import IBKRConnector

connector = IBKRConnector()
connector.connect()
print(connector.get_positions())
print(f"Portfolio: ${connector.get_portfolio_value():.2f}")
```

## Common Issues

### "Connection refused"
- Check TWS/IB Gateway is running
- Verify port is correct (7497 or 7496)
- Check API is enabled

### "No market data"
- Verify market is open (9:30 AM - 4:00 PM ET)
- Check symbols are valid
- Verify subscription is active

### "Out of memory"
- Reduce batch size
- Use CPU instead of GPU
- Reduce buffer size

## Next Steps

1. Read full README.md for detailed documentation
2. Customize configuration for your strategy
3. Add sentiment API keys for better decisions
4. Monitor performance and adjust parameters
5. Scale up gradually with live trading

## Getting Help

1. Check README.md troubleshooting section
2. Review log files for error messages
3. Verify configuration is correct
4. Test with paper trading first

## Key Files

| File | Purpose |
|------|---------|
| `trading_bot.py` | Main bot orchestrator |
| `data_pipeline.py` | Historical data fetching |
| `neural_network.py` | Price prediction model |
| `rl_agent.py` | Trading RL agent |
| `sentiment_engine.py` | Sentiment analysis |
| `ibkr_connector.py` | IBKR connection |
| `online_learner.py` | Continuous learning |
| `config.json` | Configuration |

## Quick Reference

```python
# Connect to IBKR
from ibkr_connector import IBKRConnector
connector = IBKRConnector()
await connector.connect()

# Get market data
data = connector.get_market_data('TSLA')

# Place order
order_id = connector.place_market_order('TSLA', 10, 'BUY')

# Get positions
positions = connector.get_positions()

# Fetch historical data
from data_pipeline import DataPipeline
pipeline = DataPipeline(['TSLA'])
pipeline.fetch_historical_data()

# Train model
from neural_network import PricePredictor
predictor = PricePredictor()
predictor.build_model()
predictor.train(X, y)

# Get sentiment
from sentiment_engine import SentimentEngine
engine = SentimentEngine()
sentiment = engine.get_combined_sentiment('TSLA')
```

---

**Ready to trade?** Start with paper trading first! 📈
