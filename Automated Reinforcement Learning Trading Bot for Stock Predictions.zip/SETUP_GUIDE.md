# Interactive Brokers Setup Guide

This guide walks through setting up the IBKR RL Trading Bot to connect to your Interactive Brokers account.

## Prerequisites

- Active Interactive Brokers account
- TWS (Trader Workstation) or IB Gateway installed
- Python 3.8+ and Node.js 18+

## Step 1: Enable API Access in IB Account

1. Log in to your Interactive Brokers account at https://www.interactivebrokers.com
2. Go to **Account Settings** → **API**
3. Enable **API** and select your preferred settings:
   - **API Version**: Select the latest version
   - **Socket Port**: Default is 7497 (paper trading) or 7496 (live trading)
   - **Enable ActiveX and Socket Clients**: Check this box

## Step 2: Install and Configure TWS or IB Gateway

### Option A: Using Trader Workstation (TWS)

1. Download TWS from https://www.interactivebrokers.com/en/trading/platforms/tws.php
2. Install and launch TWS
3. Log in with your Interactive Brokers credentials
4. Go to **Edit** → **Preferences** → **API** → **Settings**
5. Configure:
   - **Enable ActiveX and Socket Clients**: Check
   - **Socket Port**: 7497 (paper) or 7496 (live)
   - **Master Client ID**: Leave blank or set to a unique ID
6. Click **OK** and restart TWS

### Option B: Using IB Gateway (Recommended for Automation)

1. Download IB Gateway from https://www.interactivebrokers.com/en/trading/platforms/ibgateway.php
2. Install and launch IB Gateway
3. Log in with your Interactive Brokers credentials
4. The gateway will automatically start listening on the configured port

## Step 3: Configure the Trading Bot

### Environment Variables

Create a `.env` file in the project root:

```bash
# Database Configuration
DATABASE_URL=mysql://username:password@localhost:3306/trading_bot

# Interactive Brokers Configuration
IBKR_HOST=127.0.0.1
IBKR_PORT=7497              # 7497 for paper trading, 7496 for live
IBKR_CLIENT_ID=1            # Unique client ID
IBKR_ACCOUNT=DU123456       # Your account number (optional)

# Trading Configuration
TRADING_ENABLED=1
TRADING_START_HOUR=9
TRADING_END_HOUR=16
MAX_POSITION_SIZE=0.3
MAX_TOTAL_EXPOSURE=0.9
STOP_LOSS_PERCENT=0.05
TAKE_PROFIT_PERCENT=0.10
MIN_TRADE_INTERVAL=300
```

### Database Setup

1. Create a MySQL database:
```bash
mysql -u root -p
CREATE DATABASE trading_bot;
EXIT;
```

2. Run migrations:
```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

3. Initialize default configuration:
```bash
mysql -u root -p trading_bot < init_config.sql
```

## Step 4: Initialize Trading Data

### Load Stock Data

```python
from server.trading import DataPipeline

# Fetch historical data for all trading symbols
pipeline = DataPipeline(lookback_days=365)
data = pipeline.fetch_historical_data()

# Prepare training data
training_data = pipeline.prepare_training_data(window_size=60)
```

### Create Initial Model

```python
from server.trading import RLAgent, TradingEnvironment

# Create environment
env = TradingEnvironment(training_data, initial_balance=100000)

# Create and train agent
agent = RLAgent(env, model_type="ppo")
agent.create_model(learning_rate=3e-4)
results = agent.train(total_timesteps=50000)

# Save model
agent.save_model("models/initial_model.zip")
```

## Step 5: Test Connection

### Test IBKR Connection

```python
import asyncio
from server.trading import create_ibkr_connector

async def test_connection():
    try:
        connector = await create_ibkr_connector(
            host='127.0.0.1',
            port=7497,
            client_id=1
        )
        
        # Get account info
        print(f"Portfolio Value: ${connector.get_portfolio_value():.2f}")
        print(f"Cash Balance: ${connector.get_cash_balance():.2f}")
        print(f"Positions: {connector.get_positions()}")
        
        # Subscribe to market data
        connector.subscribe_market_data(['AAPL', 'MSFT'])
        
        # Get market data
        await asyncio.sleep(2)
        data = connector.get_market_data('AAPL')
        print(f"AAPL Market Data: {data}")
        
        connector.disconnect()
        
    except Exception as e:
        print(f"Connection error: {e}")

# Run test
asyncio.run(test_connection())
```

## Step 6: Start Trading

### Start the Application

```bash
# Start development server
pnpm dev

# In another terminal, start the trading bot
python -m server.trading.main
```

### Access Dashboard

1. Open http://localhost:3000 in your browser
2. Log in with your credentials
3. Navigate to the Trading Dashboard
4. Verify that:
   - Portfolio value is displayed
   - Market data is streaming
   - Configuration is correct

### Enable Live Trading

1. In the dashboard, go to **Settings**
2. Set `tradingEnabled` to 1
3. Verify trading hours are correct
4. Click **Start Trading**

## Troubleshooting

### Connection Refused

**Problem**: "Connection refused" error when connecting to IBKR

**Solutions**:
1. Verify TWS/IB Gateway is running
2. Check the correct port (7497 for paper, 7496 for live)
3. Ensure firewall allows connections to localhost
4. Verify API is enabled in account settings

### No Market Data

**Problem**: Market data not streaming

**Solutions**:
1. Verify subscription to market data is active
2. Check that symbols are valid
3. Ensure market is open (9:30 AM - 4:00 PM ET, weekdays only)
4. Verify data subscription level in IB account

### Orders Not Executing

**Problem**: Orders placed but not executing

**Solutions**:
1. Verify account has sufficient buying power
2. Check order type and parameters
3. Ensure market is open
4. Verify trading is enabled in configuration
5. Check trading logs for error messages

### Database Connection Error

**Problem**: Cannot connect to database

**Solutions**:
1. Verify MySQL is running
2. Check DATABASE_URL is correct
3. Verify database exists and is accessible
4. Check user permissions

## Paper Trading vs Live Trading

### Paper Trading (Recommended for Testing)

- **Port**: 7497
- **Capital**: Virtual cash (typically $1,000,000)
- **Risk**: None (no real money)
- **Best for**: Testing strategies and system

### Live Trading

- **Port**: 7496
- **Capital**: Real money from your account
- **Risk**: Real losses possible
- **Best for**: Production deployment

**IMPORTANT**: Always thoroughly test on paper trading before switching to live trading.

## Security Considerations

1. **API Key**: Never commit `.env` file to version control
2. **Credentials**: Use environment variables, never hardcode
3. **Network**: Only run on secure networks
4. **Account**: Use sub-account for trading bot if available
5. **Monitoring**: Monitor all trades and account activity

## Performance Optimization

### Reduce Latency

1. Run bot on same machine as TWS/Gateway
2. Use IB Gateway instead of TWS (lighter weight)
3. Optimize network connection
4. Use limit orders instead of market orders when possible

### Reduce Data Usage

1. Subscribe to only necessary symbols
2. Adjust data update frequency
3. Use appropriate bar sizes (5 min, 15 min, etc.)
4. Archive old data periodically

## Monitoring

### Key Metrics to Monitor

1. **Connection Status**: Verify connected to IBKR
2. **Portfolio Value**: Track account value
3. **Open Positions**: Monitor active trades
4. **Trade Execution**: Verify orders are executing
5. **System Logs**: Check for errors and warnings

### Recommended Monitoring Tools

1. Dashboard: Real-time monitoring via web interface
2. Logs: Check trading logs for detailed events
3. Alerts: Set up notifications for important events
4. IB Account**: Monitor account directly in TWS

## Support

For issues or questions:

1. Check the troubleshooting section above
2. Review Interactive Brokers documentation
3. Check system logs for error messages
4. Contact Interactive Brokers support

## Next Steps

1. Start with paper trading to test the system
2. Monitor performance and adjust parameters
3. Once confident, switch to live trading with small position sizes
4. Gradually increase position sizes as confidence grows
5. Continuously monitor and optimize the system
