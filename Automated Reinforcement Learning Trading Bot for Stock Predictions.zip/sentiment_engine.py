"""
Market Sentiment Analysis Engine
Aggregates sentiment from news, social media, and market data
"""

import numpy as np
import requests
from typing import Dict, List, Tuple
from datetime import datetime, timedelta
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from textblob import TextBlob
import logging
from collections import deque

logger = logging.getLogger(__name__)


class SentimentEngine:
    """
    Analyzes market sentiment from multiple sources.
    Combines news sentiment, social media sentiment, and market metrics.
    """
    
    def __init__(self, 
                 newsapi_key: str = None,
                 twitter_bearer_token: str = None,
                 lookback_days: int = 7):
        """
        Initialize sentiment engine.
        
        Args:
            newsapi_key: NewsAPI key for news sentiment
            twitter_bearer_token: Twitter API bearer token
            lookback_days: Days to look back for sentiment
        """
        self.newsapi_key = newsapi_key
        self.twitter_bearer_token = twitter_bearer_token
        self.lookback_days = lookback_days
        
        self.vader = SentimentIntensityAnalyzer()
        
        # Sentiment history for averaging
        self.sentiment_history = {}
        self.max_history = 30
    
    def get_news_sentiment(self, symbol: str) -> float:
        """
        Get sentiment from financial news.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Sentiment score -1 to 1
        """
        if not self.newsapi_key:
            logger.warning("NewsAPI key not configured")
            return 0.0
        
        try:
            # Fetch news articles
            url = "https://newsapi.org/v2/everything"
            params = {
                "q": symbol,
                "sortBy": "publishedAt",
                "language": "en",
                "apiKey": self.newsapi_key,
                "pageSize": 50
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            articles = response.json().get("articles", [])
            
            if not articles:
                return 0.0
            
            # Analyze sentiment of headlines and descriptions
            sentiments = []
            for article in articles:
                text = f"{article.get('title', '')} {article.get('description', '')}"
                
                # Use VADER for financial sentiment
                scores = self.vader.polarity_scores(text)
                sentiments.append(scores['compound'])
            
            # Average sentiment
            avg_sentiment = np.mean(sentiments) if sentiments else 0.0
            
            logger.info(f"{symbol} news sentiment: {avg_sentiment:.4f}")
            return float(avg_sentiment)
        
        except Exception as e:
            logger.error(f"Error fetching news sentiment for {symbol}: {e}")
            return 0.0
    
    def get_social_sentiment(self, symbol: str) -> float:
        """
        Get sentiment from social media (Twitter/X).
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Sentiment score -1 to 1
        """
        if not self.twitter_bearer_token:
            logger.warning("Twitter API token not configured")
            return 0.0
        
        try:
            # Note: This is a simplified example
            # In production, use tweepy or official Twitter API
            headers = {
                "Authorization": f"Bearer {self.twitter_bearer_token}"
            }
            
            # Search for tweets about the symbol
            url = "https://api.twitter.com/2/tweets/search/recent"
            params = {
                "query": f"${symbol} -is:retweet",
                "max_results": 100,
                "tweet.fields": "created_at,public_metrics"
            }
            
            response = requests.get(url, headers=headers, params=params, timeout=10)
            
            if response.status_code != 200:
                logger.warning(f"Twitter API error: {response.status_code}")
                return 0.0
            
            tweets = response.json().get("data", [])
            
            if not tweets:
                return 0.0
            
            # Analyze sentiment of tweets
            sentiments = []
            for tweet in tweets:
                text = tweet.get("text", "")
                scores = self.vader.polarity_scores(text)
                sentiments.append(scores['compound'])
            
            avg_sentiment = np.mean(sentiments) if sentiments else 0.0
            
            logger.info(f"{symbol} social sentiment: {avg_sentiment:.4f}")
            return float(avg_sentiment)
        
        except Exception as e:
            logger.error(f"Error fetching social sentiment for {symbol}: {e}")
            return 0.0
    
    def get_market_sentiment(self, symbol: str, market_data: Dict) -> float:
        """
        Calculate sentiment from market metrics.
        
        Args:
            symbol: Stock symbol
            market_data: Dictionary with market data (volume, price changes, etc.)
            
        Returns:
            Sentiment score -1 to 1
        """
        try:
            sentiment = 0.0
            
            # Volume sentiment: high volume = positive
            if "volume" in market_data and "avg_volume" in market_data:
                volume_ratio = market_data["volume"] / market_data["avg_volume"]
                volume_sentiment = min(1.0, (volume_ratio - 1.0) / 2.0)  # Normalize
                sentiment += volume_sentiment * 0.3
            
            # Price momentum: positive change = positive sentiment
            if "price_change_percent" in market_data:
                price_change = market_data["price_change_percent"] / 100.0
                price_sentiment = np.tanh(price_change * 10)  # Sigmoid-like normalization
                sentiment += price_sentiment * 0.4
            
            # Volatility: high volatility = negative (uncertainty)
            if "volatility" in market_data:
                volatility_sentiment = -market_data["volatility"]
                sentiment += volatility_sentiment * 0.3
            
            logger.info(f"{symbol} market sentiment: {sentiment:.4f}")
            return float(np.clip(sentiment, -1.0, 1.0))
        
        except Exception as e:
            logger.error(f"Error calculating market sentiment: {e}")
            return 0.0
    
    def get_combined_sentiment(self, symbol: str, market_data: Dict = None) -> float:
        """
        Get combined sentiment from all sources.
        
        Args:
            symbol: Stock symbol
            market_data: Optional market data for market sentiment
            
        Returns:
            Combined sentiment score -1 to 1
        """
        # Get sentiment from each source
        news_sentiment = self.get_news_sentiment(symbol)
        social_sentiment = self.get_social_sentiment(symbol)
        market_sentiment = self.get_market_sentiment(symbol, market_data or {})
        
        # Weight: news 40%, social 30%, market 30%
        combined = (
            news_sentiment * 0.4 +
            social_sentiment * 0.3 +
            market_sentiment * 0.3
        )
        
        # Store in history
        if symbol not in self.sentiment_history:
            self.sentiment_history[symbol] = deque(maxlen=self.max_history)
        
        self.sentiment_history[symbol].append({
            'timestamp': datetime.now(),
            'sentiment': combined,
            'news': news_sentiment,
            'social': social_sentiment,
            'market': market_sentiment
        })
        
        logger.info(f"{symbol} combined sentiment: {combined:.4f}")
        return float(np.clip(combined, -1.0, 1.0))
    
    def get_sentiment_trend(self, symbol: str) -> Tuple[float, float]:
        """
        Get sentiment trend (current and average).
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Tuple of (current_sentiment, trend_direction)
        """
        if symbol not in self.sentiment_history or len(self.sentiment_history[symbol]) == 0:
            return 0.0, 0.0
        
        history = list(self.sentiment_history[symbol])
        current = history[-1]['sentiment']
        
        # Calculate trend: positive if sentiment improving
        if len(history) > 1:
            prev_avg = np.mean([h['sentiment'] for h in history[:-1]])
            trend = current - prev_avg
        else:
            trend = 0.0
        
        return float(current), float(trend)
    
    def get_sentiment_strength(self, symbol: str) -> float:
        """
        Get strength of sentiment (how confident the sentiment is).
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Strength 0 to 1 (0 = neutral, 1 = strong conviction)
        """
        if symbol not in self.sentiment_history or len(self.sentiment_history[symbol]) == 0:
            return 0.0
        
        history = list(self.sentiment_history[symbol])
        sentiments = [h['sentiment'] for h in history]
        
        # Strength = absolute value of average sentiment
        strength = abs(np.mean(sentiments))
        
        # Confidence = consistency (low std = high confidence)
        consistency = 1.0 - min(1.0, np.std(sentiments))
        
        # Combined strength
        combined_strength = (strength + consistency) / 2.0
        
        return float(np.clip(combined_strength, 0.0, 1.0))


class SentimentBuffer:
    """
    Maintains a rolling buffer of sentiment scores for time-series analysis.
    """
    
    def __init__(self, window_size: int = 30):
        """
        Initialize sentiment buffer.
        
        Args:
            window_size: Number of sentiment readings to keep
        """
        self.window_size = window_size
        self.buffers = {}
    
    def add_sentiment(self, symbol: str, sentiment: float) -> None:
        """
        Add sentiment reading to buffer.
        
        Args:
            symbol: Stock symbol
            sentiment: Sentiment score
        """
        if symbol not in self.buffers:
            self.buffers[symbol] = deque(maxlen=self.window_size)
        
        self.buffers[symbol].append(sentiment)
    
    def get_sentiment_array(self, symbol: str) -> np.ndarray:
        """
        Get sentiment as numpy array for neural network input.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Numpy array of sentiment scores
        """
        if symbol not in self.buffers:
            return np.zeros(self.window_size)
        
        buffer = list(self.buffers[symbol])
        
        # Pad with zeros if not full
        if len(buffer) < self.window_size:
            buffer = [0.0] * (self.window_size - len(buffer)) + buffer
        
        return np.array(buffer, dtype=np.float32)
    
    def get_current_sentiment(self, symbol: str) -> float:
        """
        Get most recent sentiment score.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Most recent sentiment or 0.0 if not available
        """
        if symbol not in self.buffers or len(self.buffers[symbol]) == 0:
            return 0.0
        
        return float(self.buffers[symbol][-1])
    
    def get_sentiment_statistics(self, symbol: str) -> Dict:
        """
        Get statistics about sentiment buffer.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Dictionary with sentiment statistics
        """
        if symbol not in self.buffers or len(self.buffers[symbol]) == 0:
            return {
                'mean': 0.0,
                'std': 0.0,
                'min': 0.0,
                'max': 0.0,
                'trend': 0.0
            }
        
        buffer = np.array(list(self.buffers[symbol]))
        
        # Calculate trend: recent vs older
        if len(buffer) > 1:
            recent = np.mean(buffer[-5:])
            older = np.mean(buffer[:-5])
            trend = recent - older
        else:
            trend = 0.0
        
        return {
            'mean': float(np.mean(buffer)),
            'std': float(np.std(buffer)),
            'min': float(np.min(buffer)),
            'max': float(np.max(buffer)),
            'trend': float(trend)
        }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Example usage
    engine = SentimentEngine()
    
    # Get sentiment for a symbol
    market_data = {
        'volume': 1000000,
        'avg_volume': 800000,
        'price_change_percent': 2.5,
        'volatility': 0.02
    }
    
    sentiment = engine.get_combined_sentiment('TSLA', market_data)
    print(f"TSLA Sentiment: {sentiment:.4f}")
    
    current, trend = engine.get_sentiment_trend('TSLA')
    print(f"Current: {current:.4f}, Trend: {trend:.4f}")
    
    strength = engine.get_sentiment_strength('TSLA')
    print(f"Strength: {strength:.4f}")
