# IBKR RL Trading Bot

An automated reinforcement learning-based stock trading system that connects to Interactive Brokers for live trading. The bot uses deep reinforcement learning (PPO algorithm) with LSTM/Transformer feature extraction to identify patterns in historical stock data and make intelligent buy/sell/hold decisions.

## Features

### Core Trading System
- **RL Agent**: Proximal Policy Optimization (PPO) agent trained on historical stock data
- **Feature Extraction**: LSTM and Transformer-based neural networks for temporal pattern recognition
- **Custom Trading Environment**: OpenAI Gym-compatible environment with realistic market simulation
- **Technical Indicators**: RSI, MACD, Bollinger Bands, ATR, ADX, Stochastic, CCI, and more

### Interactive Brokers Integration
- **Live Connection**: Direct integration with Interactive Brokers via ib_insync
- **Real-time Market Data**: Streaming price and volume data for all trading symbols
- **Order Execution**: Market and limit order placement with automatic execution
- **Position Tracking**: Real-time position monitoring and portfolio updates

### Risk Management
- **Position Sizing**: Configurable maximum position size as percentage of portfolio
- **Stop Loss**: Automatic stop-loss enforcement at configured percentage
- **Take Profit**: Automatic profit-taking at configured levels
- **Total Exposure Limits**: Maximum total portfolio exposure constraints
- **Trading Hours**: Configurable market hours for trading

### Monitoring & Analytics
- **Real-time Dashboard**: Live portfolio value, P&L, and position tracking
- **Performance Metrics**: Sharpe ratio, maximum drawdown, win rate, total return
- **Trade History**: Complete record of all executed trades with entry/exit prices
- **Trading Logs**: Detailed logs of all trading events and system messages
- **Portfolio Charts**: Historical portfolio value and P&L visualization

### Model Management
- **Model Versioning**: Track multiple trained models with hyperparameters
- **Backtesting**: Evaluate models on historical data before live trading
- **Model Checkpointing**: Save and load trained models
- **Hyperparameter Tuning**: Framework for optimizing agent performance

## Trading Universe

The bot trades the following 8 stocks:
- **AVGO** - Broadcom Inc.
- **TSLA** - Tesla Inc.
- **MU** - Micron Technology
- **COST** - Costco Wholesale
- **ABBV** - AbbVie Inc.
- **NFLX** - Netflix Inc.
- **INTC** - Intel Corporation
- **IBM** - IBM Corporation

## Architecture

### Backend (Python)
```
server/trading/
├── data_pipeline.py          # Historical data fetching and preprocessing
├── trading_env.py            # Custom OpenAI Gym trading environment
├── feature_extractor.py      # LSTM/Transformer feature extraction
├── rl_agent.py              # PPO agent training and inference
├── ibkr_connector.py        # Interactive Brokers integration
└── orchestrator.py          # Trading orchestrator and risk management
```

### Frontend (React + TypeScript)
```
client/src/
├── pages/
│   ├── Home.tsx             # Landing page
│   └── TradingDashboard.tsx  # Main trading dashboard
└── lib/
    └── trpc.ts              # tRPC client configuration
```

### Database (MySQL)
- **stocks**: List of tradable symbols
- **models**: RL model versions and metadata
- **trades**: Executed trades with entry/exit prices
- **positions**: Current open positions
- **portfolio_metrics**: Daily portfolio snapshots
- **predictions**: Model predictions for each stock
- **trading_config**: Trading parameters and settings
- **trading_logs**: System logs and events

## Setup Instructions

### Prerequisites
- Python 3.8+
- Node.js 18+
- MySQL database
- Interactive Brokers account with TWS/Gateway running

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd ibkr-rl-trading-bot
```

2. **Install Python dependencies**
```bash
pip install -r requirements.txt
```

3. **Install Node dependencies**
```bash
pnpm install
```

4. **Set up database**
```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

5. **Configure environment variables**
Create a `.env` file with:
```
DATABASE_URL=mysql://user:password@localhost:3306/trading_bot
IBKR_HOST=127.0.0.1
IBKR_PORT=7497
```

### Running the Application

1. **Start the development server**
```bash
pnpm dev
```

2. **Access the dashboard**
Open `http://localhost:3000` in your browser

## Model Training

### Training a New Model

```python
from server.trading import DataPipeline, TradingEnvironment, RLAgent

# Prepare data
pipeline = DataPipeline(lookback_days=365)
training_data = pipeline.prepare_training_data(window_size=60)

# Create environment
env = TradingEnvironment(training_data, initial_balance=100000)

# Train agent
agent = RLAgent(env, model_type="ppo")
agent.create_model(learning_rate=3e-4, n_steps=2048)
results = agent.train(total_timesteps=100000)

# Save model
agent.save_model("models/trading_bot_v1.zip")
```

### Backtesting

```python
# Load trained model
agent.load_model("models/trading_bot_v1.zip")

# Evaluate on test data
eval_results = agent.evaluate(n_episodes=10, deterministic=True)
print(f"Mean Reward: {eval_results['mean_reward']:.4f}")
print(f"Sharpe Ratio: {eval_results.get('sharpe_ratio', 'N/A')}")
```

## API Reference

### Trading Endpoints

#### Get Active Model
```typescript
trpc.trading.activeModel.useQuery()
```

#### Get Open Trades
```typescript
trpc.trading.openTrades.useQuery({ modelId: 1 })
```

#### Get Trade History
```typescript
trpc.trading.tradeHistory.useQuery({ modelId: 1, limit: 100 })
```

#### Get Positions
```typescript
trpc.trading.positions.useQuery({ modelId: 1 })
```

#### Get Portfolio Metrics
```typescript
trpc.trading.portfolioMetrics.useQuery({ modelId: 1, limit: 30 })
```

#### Update Trading Config
```typescript
trpc.trading.updateConfig.useMutation({
  maxPositionSize: "0.3",
  stopLossPercent: "0.05",
  tradingEnabled: 1
})
```

## Configuration

### Trading Parameters

Edit the trading configuration through the dashboard or directly in the database:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `maxPositionSize` | 0.3 | Maximum position size as % of portfolio |
| `maxTotalExposure` | 0.9 | Maximum total exposure as % of portfolio |
| `stopLossPercent` | 0.05 | Stop loss percentage (5%) |
| `takeProfitPercent` | 0.10 | Take profit percentage (10%) |
| `tradingStartHour` | 9 | Trading start hour (9:30 AM ET) |
| `tradingEndHour` | 16 | Trading end hour (4:00 PM ET) |
| `minTradeInterval` | 300 | Minimum seconds between trades |
| `rebalanceFrequency` | daily | Portfolio rebalancing frequency |

## Risk Management

The system implements multiple layers of risk management:

1. **Position Sizing**: Limits individual position size to prevent over-concentration
2. **Total Exposure**: Caps total portfolio exposure to prevent excessive leverage
3. **Stop Loss**: Automatically closes losing positions at configured threshold
4. **Take Profit**: Automatically closes winning positions at configured threshold
5. **Trading Hours**: Only trades during configured market hours
6. **Trade Interval**: Enforces minimum time between trades to prevent overtrading

## Monitoring

### Dashboard Features

- **Portfolio Overview**: Current portfolio value, cash balance, and P&L
- **Position Monitor**: Real-time position tracking with unrealized P&L
- **Trade History**: Complete record of all trades with entry/exit prices
- **Performance Charts**: Historical portfolio value and P&L visualization
- **Trading Logs**: System logs showing all trading events and errors
- **Configuration**: View and modify trading parameters

### Alerts & Notifications

- Trade execution notifications
- Stop loss/take profit triggers
- Connection status alerts
- Error and warning messages

## Performance Metrics

The system tracks the following performance metrics:

- **Total Return**: Overall percentage return on initial capital
- **Sharpe Ratio**: Risk-adjusted return metric
- **Maximum Drawdown**: Largest peak-to-trough decline
- **Win Rate**: Percentage of profitable trades
- **Average Trade Duration**: Average holding period
- **Profit Factor**: Gross profit divided by gross loss

## Troubleshooting

### Connection Issues
- Ensure TWS or IB Gateway is running on the configured host/port
- Check firewall settings to allow connections to IBKR
- Verify API access is enabled in IBKR account settings

### Data Issues
- Ensure yfinance can access historical data for all symbols
- Check internet connectivity for real-time data streaming
- Verify database connection and schema

### Model Issues
- Check that model file exists at configured path
- Ensure model was trained on compatible environment
- Verify hyperparameters match the training configuration

## Development

### Project Structure
```
ibkr-rl-trading-bot/
├── server/
│   ├── trading/           # Core trading modules
│   ├── db.ts             # Database queries
│   └── routers.ts        # tRPC API routes
├── client/
│   └── src/
│       ├── pages/        # React pages
│       └── lib/          # Utilities
├── drizzle/              # Database schema
└── README.md
```

### Testing

Run tests with:
```bash
pnpm test
```

### Code Style

The project uses:
- TypeScript for type safety
- ESLint for code linting
- Prettier for code formatting

## Contributing

Contributions are welcome! Please follow these guidelines:

1. Create a feature branch
2. Make your changes
3. Write tests for new functionality
4. Submit a pull request

## License

This project is licensed under the MIT License.

## Disclaimer

**IMPORTANT**: This trading bot is provided for educational and research purposes only. Trading involves substantial risk of loss. Past performance is not indicative of future results. Always test thoroughly on paper trading before deploying with real capital. The authors assume no responsibility for trading losses or system failures.

## Support

For issues, questions, or suggestions, please open an issue on GitHub or contact the development team.

## References

- [Stable-Baselines3 Documentation](https://stable-baselines3.readthedocs.io/)
- [ib_insync Documentation](https://ib-insync.readthedocs.io/)
- [Interactive Brokers API](https://www.interactivebrokers.com/campus/ibkr-api-page/)
- [OpenAI Gym Documentation](https://gymnasium.farama.org/)
- [PyTorch Documentation](https://pytorch.org/docs/)
