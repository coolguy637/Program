"""
Main Trading Bot Orchestrator
Coordinates all components: data collection, model training, sentiment analysis, and live trading.
"""

import asyncio
import logging
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import json
import os

from data_pipeline import DataPipeline, RealTimeDataBuffer
from sentiment_engine import SentimentEngine, SentimentBuffer
from neural_network import PricePredictor
from rl_agent import PPOAgent, TradingEnvironment
from ibkr_connector import IBKRConnector, OrderManager
from online_learner import OnlineLearner, OnlineLearningBuffer

logger = logging.getLogger(__name__)


class TradingBot:
    """
    Main trading bot that orchestrates all components.
    """
    
    def __init__(self,
                 symbols: List[str],
                 config_file: str = 'config.json',
                 models_dir: str = './models',
                 logs_dir: str = './logs'):
        """
        Initialize trading bot.
        
        Args:
            symbols: List of stock symbols to trade
            config_file: Path to configuration file
            models_dir: Directory to store models
            logs_dir: Directory to store logs
        """
        self.symbols = symbols
        self.config_file = config_file
        self.models_dir = models_dir
        self.logs_dir = logs_dir
        
        # Create directories
        os.makedirs(models_dir, exist_ok=True)
        os.makedirs(logs_dir, exist_ok=True)
        
        # Load configuration
        self.config = self._load_config()
        
        # Initialize components
        self.data_pipeline = DataPipeline(symbols, lookback_days=365)
        self.sentiment_engine = SentimentEngine(
            newsapi_key=self.config.get('newsapi_key'),
            twitter_bearer_token=self.config.get('twitter_bearer_token')
        )
        self.sentiment_buffer = SentimentBuffer(window_size=30)
        self.real_time_buffer = RealTimeDataBuffer(symbols, buffer_size=30)
        
        # Initialize models
        self.price_predictor = PricePredictor()
        self.price_predictor.build_model(sequence_length=30, num_features=5, sentiment_dim=30)
        
        self.rl_agent = PPOAgent(state_dim=32)
        
        # Initialize IBKR connector
        self.ibkr = IBKRConnector(
            host=self.config.get('ibkr_host', '127.0.0.1'),
            port=self.config.get('ibkr_port', 7497),
            client_id=self.config.get('ibkr_client_id', 1)
        )
        self.order_manager = OrderManager(self.ibkr)
        
        # Initialize online learner
        self.online_learner = OnlineLearner(
            self.price_predictor,
            self.rl_agent,
            buffer_size=1000,
            update_frequency=100
        )
        
        # Trading state
        self.is_running = False
        self.last_trade_time = {}
        self.position_tracking = {}
        self.trade_log = []
    
    def _load_config(self) -> Dict:
        """Load configuration from file."""
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                return json.load(f)
        
        # Default configuration
        return {
            'ibkr_host': '127.0.0.1',
            'ibkr_port': 7497,
            'ibkr_client_id': 1,
            'max_position_size': 0.3,
            'max_total_exposure': 0.9,
            'stop_loss_percent': 0.05,
            'take_profit_percent': 0.10,
            'min_trade_interval': 300,
            'trading_enabled': False,
            'trading_start_hour': 9,
            'trading_end_hour': 16,
            'newsapi_key': None,
            'twitter_bearer_token': None,
            'confidence_threshold': 0.6
        }
    
    def _save_config(self):
        """Save configuration to file."""
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=2)
    
    async def initialize(self) -> bool:
        """
        Initialize the trading bot.
        
        Returns:
            True if initialization successful
        """
        logger.info("Initializing trading bot...")
        
        try:
            # Connect to IBKR
            if not await self.ibkr.connect():
                logger.error("Failed to connect to IBKR")
                return False
            
            # Fetch historical data
            logger.info("Fetching historical data...")
            self.data_pipeline.fetch_historical_data()
            
            # Normalize data
            logger.info("Normalizing data...")
            self.data_pipeline.normalize_data(method='minmax')
            
            # Create sequences
            logger.info("Creating training sequences...")
            X, y = self.data_pipeline.create_sequences(sequence_length=30)
            
            # Train initial models
            logger.info("Training initial models...")
            self._train_initial_models(X, y)
            
            # Subscribe to market data
            logger.info("Subscribing to market data...")
            self.ibkr.subscribe_market_data(self.symbols)
            
            logger.info("Trading bot initialized successfully")
            return True
        
        except Exception as e:
            logger.error(f"Initialization error: {e}")
            return False
    
    def _train_initial_models(self, X: Dict, y: Dict):
        """
        Train initial models on historical data.
        
        Args:
            X: Input sequences
            y: Target values
        """
        try:
            # Combine all symbols' data
            X_combined = np.vstack([X[symbol] for symbol in self.symbols if symbol in X])
            y_combined = np.hstack([y[symbol] for symbol in self.symbols if symbol in y])
            
            # Split train/test
            split_idx = int(len(X_combined) * 0.8)
            X_train = X_combined[:split_idx]
            y_train = y_combined[:split_idx]
            X_test = X_combined[split_idx:]
            y_test = y_combined[split_idx:]
            
            # Train price predictor
            logger.info("Training price predictor...")
            self.price_predictor.train(
                X_train, y_train,
                X_test, y_test,
                epochs=10,
                batch_size=32
            )
            
            # Save model
            model_path = os.path.join(self.models_dir, 'price_predictor_initial.pt')
            self.price_predictor.save_model(model_path)
            
            logger.info("Initial models trained successfully")
        
        except Exception as e:
            logger.error(f"Error training initial models: {e}")
    
    async def run(self):
        """
        Main trading loop.
        """
        if not await self.initialize():
            logger.error("Failed to initialize trading bot")
            return
        
        self.is_running = True
        logger.info("Trading bot started")
        
        try:
            while self.is_running:
                try:
                    # Check market hours
                    if not self.ibkr.is_market_open():
                        logger.info("Market is closed, waiting...")
                        await asyncio.sleep(3600)  # Wait 1 hour
                        continue
                    
                    # Check if trading is enabled
                    if not self.config.get('trading_enabled', False):
                        logger.info("Trading is disabled")
                        await asyncio.sleep(300)  # Wait 5 minutes
                        continue
                    
                    # Main trading loop
                    await self._trading_cycle()
                    
                    # Wait before next cycle
                    await asyncio.sleep(60)  # 1 minute between cycles
                
                except Exception as e:
                    logger.error(f"Error in trading cycle: {e}")
                    await asyncio.sleep(60)
        
        except KeyboardInterrupt:
            logger.info("Trading bot interrupted by user")
        
        finally:
            await self.shutdown()
    
    async def _trading_cycle(self):
        """
        Execute one trading cycle.
        """
        try:
            # Get current market data
            market_data = {}
            for symbol in self.symbols:
                data = self.ibkr.get_market_data(symbol)
                if data:
                    market_data[symbol] = data
            
            if not market_data:
                logger.warning("No market data available")
                return
            
            # Update sentiment for each symbol
            for symbol in self.symbols:
                sentiment = self.sentiment_engine.get_combined_sentiment(
                    symbol,
                    market_data.get(symbol, {})
                )
                self.sentiment_buffer.add_sentiment(symbol, sentiment)
            
            # Make trading decisions
            for symbol in self.symbols:
                await self._make_trading_decision(symbol, market_data.get(symbol, {}))
            
            # Check for model updates
            if self.online_learner.samples_collected % 100 == 0:
                logger.info("Updating models with online learning...")
                self.online_learner.update_models()
        
        except Exception as e:
            logger.error(f"Error in trading cycle: {e}")
    
    async def _make_trading_decision(self, symbol: str, market_data: Dict):
        """
        Make trading decision for a symbol.
        
        Args:
            symbol: Stock symbol
            market_data: Current market data
        """
        try:
            # Get latest price sequence
            price_sequence = self.real_time_buffer.get_buffer_array(symbol)
            
            # Get sentiment sequence
            sentiment_sequence = self.sentiment_buffer.get_sentiment_array(symbol)
            
            # Prepare state for RL agent
            state = np.concatenate([
                sentiment_sequence,
                np.array([
                    self.ibkr.get_cash_balance() / self.config.get('initial_balance', 100000),
                    self.ibkr.get_portfolio_value() / self.config.get('initial_balance', 100000)
                ])
            ]).astype(np.float32)
            
            # Get RL action
            action, _ = self.rl_agent.select_action(state, deterministic=False)
            
            # Get price prediction
            price_pred = self.price_predictor.predict(
                price_sequence.reshape(1, 30, 5),
                sentiment_sequence.reshape(1, 30)
            )[0, 0]
            
            # Combine predictions: 70% RL, 30% sentiment
            sentiment_score = self.sentiment_buffer.get_current_sentiment(symbol)
            
            # Calculate confidence
            confidence = abs(sentiment_score) * 0.3
            
            # Execute trade if confidence exceeds threshold
            if confidence > self.config.get('confidence_threshold', 0.6):
                await self._execute_trade(symbol, action, market_data, confidence)
            
            # Record experience for online learning
            next_price = market_data.get('last', 0)
            reward = (next_price - market_data.get('open', next_price)) / market_data.get('open', 1)
            
            self.online_learner.add_experience(
                price_sequence,
                sentiment_sequence,
                next_price,
                action,
                reward
            )
        
        except Exception as e:
            logger.error(f"Error making trading decision for {symbol}: {e}")
    
    async def _execute_trade(self, symbol: str, action: int, market_data: Dict, confidence: float):
        """
        Execute a trade.
        
        Args:
            symbol: Stock symbol
            action: 0=hold, 1=buy, 2=sell
            market_data: Current market data
            confidence: Confidence level (0-1)
        """
        try:
            # Check minimum trade interval
            last_trade = self.last_trade_time.get(symbol, datetime.now() - timedelta(hours=1))
            if (datetime.now() - last_trade).total_seconds() < self.config.get('min_trade_interval', 300):
                return
            
            portfolio_value = self.ibkr.get_portfolio_value()
            max_position_value = portfolio_value * self.config.get('max_position_size', 0.3)
            
            current_price = market_data.get('last', 0)
            if current_price <= 0:
                return
            
            if action == 1:  # Buy
                # Calculate shares to buy
                shares = int(max_position_value / current_price)
                
                if shares > 0:
                    order_id = self.order_manager.buy(symbol, shares)
                    
                    if order_id:
                        logger.info(f"BUY {shares} shares of {symbol} at ${current_price} (Confidence: {confidence:.2%})")
                        self.last_trade_time[symbol] = datetime.now()
                        self.trade_log.append({
                            'timestamp': datetime.now().isoformat(),
                            'symbol': symbol,
                            'action': 'BUY',
                            'shares': shares,
                            'price': current_price,
                            'confidence': confidence,
                            'order_id': order_id
                        })
            
            elif action == 2:  # Sell
                # Close position
                order_id = self.order_manager.close_position(symbol)
                
                if order_id:
                    logger.info(f"SELL position in {symbol} (Confidence: {confidence:.2%})")
                    self.last_trade_time[symbol] = datetime.now()
                    self.trade_log.append({
                        'timestamp': datetime.now().isoformat(),
                        'symbol': symbol,
                        'action': 'SELL',
                        'confidence': confidence,
                        'order_id': order_id
                    })
        
        except Exception as e:
            logger.error(f"Error executing trade for {symbol}: {e}")
    
    async def shutdown(self):
        """Shutdown the trading bot."""
        logger.info("Shutting down trading bot...")
        
        self.is_running = False
        
        # Save trade log
        log_file = os.path.join(self.logs_dir, f'trades_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json')
        with open(log_file, 'w') as f:
            json.dump(self.trade_log, f, indent=2)
        
        # Save models
        self.price_predictor.save_model(os.path.join(self.models_dir, 'price_predictor_final.pt'))
        self.rl_agent.save_model(os.path.join(self.models_dir, 'rl_agent_final.pt'))
        
        # Disconnect from IBKR
        self.ibkr.disconnect()
        
        logger.info("Trading bot shutdown complete")


async def main():
    """Main entry point."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('trading_bot.log'),
            logging.StreamHandler()
        ]
    )
    
    # Define symbols to trade
    symbols = ['AVGO', 'TSLA', 'MU', 'COST', 'ABBV', 'NFLX', 'INTC', 'IBM']
    
    # Create and run bot
    bot = TradingBot(symbols)
    await bot.run()


if __name__ == '__main__':
    asyncio.run(main())
