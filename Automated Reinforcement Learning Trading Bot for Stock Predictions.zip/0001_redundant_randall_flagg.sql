CREATE TABLE `models` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`version` varchar(64) NOT NULL,
	`modelType` varchar(64) NOT NULL,
	`status` enum('training','trained','active','archived') NOT NULL DEFAULT 'trained',
	`isActive` int NOT NULL DEFAULT 0,
	`trainingStartedAt` timestamp,
	`trainingCompletedAt` timestamp,
	`backTestStartDate` varchar(10),
	`backTestEndDate` varchar(10),
	`backTestReturn` text,
	`hyperparameters` text,
	`modelPath` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `models_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `portfolioMetrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`modelId` int NOT NULL,
	`date` varchar(10) NOT NULL,
	`totalValue` text NOT NULL,
	`cashBalance` text NOT NULL,
	`realizedPnL` text NOT NULL,
	`unrealizedPnL` text NOT NULL,
	`totalReturn` text,
	`sharpeRatio` text,
	`maxDrawdown` text,
	`winRate` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `portfolioMetrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `positions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`modelId` int NOT NULL,
	`stockId` int NOT NULL,
	`quantity` int NOT NULL,
	`averageEntryPrice` text NOT NULL,
	`currentPrice` text NOT NULL,
	`unrealizedPnL` text,
	`unrealizedPnLPercent` text,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `positions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `predictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`modelId` int NOT NULL,
	`stockId` int NOT NULL,
	`predictionTime` timestamp NOT NULL,
	`action` enum('buy','sell','hold') NOT NULL,
	`confidence` text NOT NULL,
	`predictedPrice` text,
	`actualPrice` text,
	`accuracy` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `predictions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`symbol` varchar(10) NOT NULL,
	`name` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stocks_id` PRIMARY KEY(`id`),
	CONSTRAINT `stocks_symbol_unique` UNIQUE(`symbol`)
);
--> statement-breakpoint
CREATE TABLE `trades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`modelId` int NOT NULL,
	`stockId` int NOT NULL,
	`tradeType` enum('buy','sell') NOT NULL,
	`quantity` int NOT NULL,
	`entryPrice` text NOT NULL,
	`exitPrice` text,
	`entryTime` timestamp NOT NULL,
	`exitTime` timestamp,
	`status` enum('open','closed','cancelled') NOT NULL DEFAULT 'open',
	`profitLoss` text,
	`profitLossPercent` text,
	`commission` text,
	`ibOrderId` varchar(64),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `trades_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tradingConfig` (
	`id` int AUTO_INCREMENT NOT NULL,
	`activeModelId` int,
	`maxPositionSize` text NOT NULL,
	`maxTotalExposure` text NOT NULL,
	`stopLossPercent` text NOT NULL,
	`takeProfitPercent` text,
	`tradingEnabled` int NOT NULL DEFAULT 1,
	`tradingStartHour` int NOT NULL DEFAULT 9,
	`tradingEndHour` int NOT NULL DEFAULT 16,
	`rebalanceFrequency` varchar(64) NOT NULL DEFAULT 'daily',
	`minTradeInterval` int NOT NULL DEFAULT 300,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tradingConfig_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tradingLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`modelId` int,
	`level` enum('info','warning','error','debug') NOT NULL,
	`message` text NOT NULL,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `tradingLogs_id` PRIMARY KEY(`id`)
);
