"""
Data pipeline for fetching and preprocessing historical stock data.
Handles data normalization, technical indicator calculation, and feature engineering.
"""

import numpy as np
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import talib
from typing import Dict, List, Tuple, Optional
import logging

logger = logging.getLogger(__name__)

STOCK_SYMBOLS = ['AVGO', 'TSLA', 'MU', 'COST', 'ABBV', 'NFLX', 'INTC', 'IBM']


class DataPipeline:
    """Handles historical data fetching and preprocessing."""
    
    def __init__(self, lookback_days: int = 365):
        """
        Initialize the data pipeline.
        
        Args:
            lookback_days: Number of days of historical data to fetch
        """
        self.lookback_days = lookback_days
        self.data_cache: Dict[str, pd.DataFrame] = {}
    
    def fetch_historical_data(self, symbols: List[str] = None, 
                             end_date: Optional[datetime] = None) -> Dict[str, pd.DataFrame]:
        """
        Fetch historical OHLCV data for given symbols.
        
        Args:
            symbols: List of stock symbols. Defaults to STOCK_SYMBOLS
            end_date: End date for data fetch. Defaults to today
            
        Returns:
            Dictionary mapping symbol to DataFrame with OHLCV data
        """
        if symbols is None:
            symbols = STOCK_SYMBOLS
        
        if end_date is None:
            end_date = datetime.now()
        
        start_date = end_date - timedelta(days=self.lookback_days)
        
        data = {}
        for symbol in symbols:
            try:
                logger.info(f"Fetching data for {symbol} from {start_date.date()} to {end_date.date()}")
                df = yf.download(symbol, start=start_date, end=end_date, progress=False)
                
                if df.empty:
                    logger.warning(f"No data found for {symbol}")
                    continue
                
                # Ensure index is datetime
                if not isinstance(df.index, pd.DatetimeIndex):
                    df.index = pd.to_datetime(df.index)
                
                # Rename columns to lowercase
                df.columns = [col.lower() for col in df.columns]
                
                # Sort by date
                df = df.sort_index()
                
                data[symbol] = df
                logger.info(f"Fetched {len(df)} bars for {symbol}")
                
            except Exception as e:
                logger.error(f"Error fetching data for {symbol}: {e}")
                continue
        
        self.data_cache.update(data)
        return data
    
    def calculate_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate technical indicators for a given OHLCV dataframe.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with added technical indicator columns
        """
        df = df.copy()
        
        # Ensure required columns exist
        required_cols = ['open', 'high', 'low', 'close', 'volume']
        if not all(col in df.columns for col in required_cols):
            logger.error(f"Missing required columns. Found: {df.columns.tolist()}")
            return df
        
        # Convert to numpy arrays for talib
        close = df['close'].values
        high = df['high'].values
        low = df['low'].values
        volume = df['volume'].values
        
        # RSI (Relative Strength Index)
        df['rsi_14'] = talib.RSI(close, timeperiod=14)
        
        # MACD (Moving Average Convergence Divergence)
        df['macd'], df['macd_signal'], df['macd_hist'] = talib.MACD(close, fastperiod=12, slowperiod=26, signalperiod=9)
        
        # Bollinger Bands
        df['bb_upper'], df['bb_middle'], df['bb_lower'] = talib.BBANDS(close, timeperiod=20)
        
        # ATR (Average True Range)
        df['atr'] = talib.ATR(high, low, close, timeperiod=14)
        
        # SMA (Simple Moving Averages)
        df['sma_20'] = talib.SMA(close, timeperiod=20)
        df['sma_50'] = talib.SMA(close, timeperiod=50)
        df['sma_200'] = talib.SMA(close, timeperiod=200)
        
        # EMA (Exponential Moving Averages)
        df['ema_12'] = talib.EMA(close, timeperiod=12)
        df['ema_26'] = talib.EMA(close, timeperiod=26)
        
        # ADX (Average Directional Index)
        df['adx'] = talib.ADX(high, low, close, timeperiod=14)
        
        # OBV (On Balance Volume)
        df['obv'] = talib.OBV(close, volume)
        
        # Stochastic Oscillator
        df['stoch_k'], df['stoch_d'] = talib.STOCH(high, low, close, fastk_period=14, slowk_period=3, slowd_period=3)
        
        # CCI (Commodity Channel Index)
        df['cci'] = talib.CCI(high, low, close, timeperiod=20)
        
        # Rate of Change
        df['roc'] = talib.ROC(close, timeperiod=12)
        
        # Normalize volume
        df['volume_sma'] = talib.SMA(volume, timeperiod=20)
        df['volume_ratio'] = df['volume'] / (df['volume_sma'] + 1e-8)
        
        # Price rate of change
        df['price_change'] = df['close'].pct_change()
        df['price_momentum'] = df['close'] - df['close'].shift(5)
        
        return df
    
    def normalize_features(self, df: pd.DataFrame, 
                          feature_cols: Optional[List[str]] = None) -> Tuple[pd.DataFrame, Dict]:
        """
        Normalize features to [-1, 1] range using min-max scaling.
        
        Args:
            df: DataFrame with features
            feature_cols: Columns to normalize. If None, normalizes all numeric columns except OHLCV
            
        Returns:
            Tuple of (normalized DataFrame, normalization parameters for inverse transform)
        """
        df = df.copy()
        
        if feature_cols is None:
            # Exclude OHLCV and datetime columns
            exclude_cols = {'open', 'high', 'low', 'close', 'volume', 'adj close'}
            feature_cols = [col for col in df.columns if col.lower() not in exclude_cols and df[col].dtype in [np.float64, np.float32, np.int64, np.int32]]
        
        normalization_params = {}
        
        for col in feature_cols:
            if col not in df.columns or df[col].isna().all():
                continue
            
            # Remove NaN values for min/max calculation
            valid_data = df[col].dropna()
            
            if len(valid_data) == 0:
                continue
            
            min_val = valid_data.min()
            max_val = valid_data.max()
            
            # Avoid division by zero
            if max_val == min_val:
                df[col] = 0
            else:
                # Normalize to [-1, 1]
                df[col] = 2 * (df[col] - min_val) / (max_val - min_val) - 1
            
            normalization_params[col] = {'min': min_val, 'max': max_val}
        
        return df, normalization_params
    
    def prepare_training_data(self, symbols: List[str] = None,
                             window_size: int = 60,
                             end_date: Optional[datetime] = None) -> Dict[str, np.ndarray]:
        """
        Prepare training data with technical indicators and normalization.
        
        Args:
            symbols: List of stock symbols
            window_size: Number of days to use as input window
            end_date: End date for data
            
        Returns:
            Dictionary mapping symbol to array of shape (n_windows, window_size, n_features)
        """
        if symbols is None:
            symbols = STOCK_SYMBOLS
        
        # Fetch data
        data = self.fetch_historical_data(symbols, end_date)
        
        training_data = {}
        
        for symbol in symbols:
            if symbol not in data:
                logger.warning(f"No data available for {symbol}")
                continue
            
            df = data[symbol]
            
            # Calculate technical indicators
            df = self.calculate_technical_indicators(df)
            
            # Normalize features
            df, _ = self.normalize_features(df)
            
            # Remove rows with NaN values
            df = df.dropna()
            
            if len(df) < window_size:
                logger.warning(f"Not enough data for {symbol}: {len(df)} < {window_size}")
                continue
            
            # Select feature columns
            feature_cols = [col for col in df.columns if col not in ['open', 'high', 'low', 'close', 'volume', 'adj close']]
            
            # Create sliding windows
            X = []
            for i in range(len(df) - window_size + 1):
                window = df[feature_cols].iloc[i:i+window_size].values
                X.append(window)
            
            training_data[symbol] = np.array(X, dtype=np.float32)
            logger.info(f"Prepared {len(X)} windows for {symbol}")
        
        return training_data
    
    def get_latest_features(self, symbol: str, window_size: int = 60) -> Optional[np.ndarray]:
        """
        Get the latest features for a symbol for real-time prediction.
        
        Args:
            symbol: Stock symbol
            window_size: Number of days to include
            
        Returns:
            Array of shape (window_size, n_features) or None if insufficient data
        """
        if symbol not in self.data_cache:
            # Fetch recent data
            end_date = datetime.now()
            start_date = end_date - timedelta(days=window_size + 50)
            
            try:
                df = yf.download(symbol, start=start_date, end=end_date, progress=False)
                df.columns = [col.lower() for col in df.columns]
                self.data_cache[symbol] = df
            except Exception as e:
                logger.error(f"Error fetching data for {symbol}: {e}")
                return None
        
        df = self.data_cache[symbol].copy()
        
        # Calculate technical indicators
        df = self.calculate_technical_indicators(df)
        
        # Normalize features
        df, _ = self.normalize_features(df)
        
        # Remove NaN rows
        df = df.dropna()
        
        if len(df) < window_size:
            logger.warning(f"Insufficient data for {symbol}: {len(df)} < {window_size}")
            return None
        
        # Get latest window
        feature_cols = [col for col in df.columns if col not in ['open', 'high', 'low', 'close', 'volume', 'adj close']]
        latest_window = df[feature_cols].iloc[-window_size:].values
        
        return latest_window.astype(np.float32)


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    pipeline = DataPipeline(lookback_days=365)
    
    # Fetch and prepare training data
    training_data = pipeline.prepare_training_data(window_size=60)
    
    for symbol, data in training_data.items():
        print(f"{symbol}: {data.shape}")
