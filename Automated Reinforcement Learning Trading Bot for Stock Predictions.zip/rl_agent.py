"""
RL agent implementation using Stable-Baselines3 PPO.
Handles model training, evaluation, and inference.
"""

import numpy as np
from stable_baselines3 import PPO, A2C
from stable_baselines3.common.callbacks import EvalCallback, CheckpointCallback
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import VecNormalize
import os
import json
from datetime import datetime
from typing import Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class RLAgent:
    """
    RL agent for stock trading using Stable-Baselines3.
    """
    
    def __init__(self, env, model_type: str = "ppo", model_name: str = "trading_bot",
                 device: str = "cpu"):
        """
        Initialize the RL agent.
        
        Args:
            env: Trading environment
            model_type: "ppo" or "a2c"
            model_name: Name for the model
            device: "cpu" or "cuda"
        """
        self.env = env
        self.model_type = model_type
        self.model_name = model_name
        self.device = device
        self.model = None
        self.eval_env = None
        self.vec_env = None
        self.training_history = []
    
    def create_model(self, learning_rate: float = 3e-4,
                    n_steps: int = 2048,
                    batch_size: int = 64,
                    n_epochs: int = 10,
                    gamma: float = 0.99,
                    gae_lambda: float = 0.95,
                    clip_range: float = 0.2) -> None:
        """
        Create the RL model with specified hyperparameters.
        
        Args:
            learning_rate: Learning rate for the optimizer
            n_steps: Number of steps to collect before updating
            batch_size: Batch size for training
            n_epochs: Number of epochs for training
            gamma: Discount factor
            gae_lambda: GAE lambda parameter
            clip_range: PPO clip range
        """
        policy_kwargs = {
            "net_arch": [dict(pi=[256, 256], vf=[256, 256])],
            "activation_fn": None,  # Use default ReLU
        }
        
        if self.model_type == "ppo":
            self.model = PPO(
                "MlpPolicy",
                self.env,
                learning_rate=learning_rate,
                n_steps=n_steps,
                batch_size=batch_size,
                n_epochs=n_epochs,
                gamma=gamma,
                gae_lambda=gae_lambda,
                clip_range=clip_range,
                policy_kwargs=policy_kwargs,
                device=self.device,
                verbose=1,
                tensorboard_log="./logs/trading_bot"
            )
        elif self.model_type == "a2c":
            self.model = A2C(
                "MlpPolicy",
                self.env,
                learning_rate=learning_rate,
                gamma=gamma,
                policy_kwargs=policy_kwargs,
                device=self.device,
                verbose=1,
                tensorboard_log="./logs/trading_bot"
            )
        else:
            raise ValueError(f"Unknown model type: {self.model_type}")
        
        logger.info(f"Created {self.model_type.upper()} model with learning_rate={learning_rate}")
    
    def train(self, total_timesteps: int = 100000,
             eval_freq: int = 10000,
             n_eval_episodes: int = 10,
             save_dir: str = "./models") -> Dict:
        """
        Train the RL agent.
        
        Args:
            total_timesteps: Total number of timesteps to train
            eval_freq: Evaluation frequency
            n_eval_episodes: Number of episodes for evaluation
            save_dir: Directory to save model checkpoints
            
        Returns:
            Training history dictionary
        """
        if self.model is None:
            raise ValueError("Model not created. Call create_model() first.")
        
        # Create save directory
        os.makedirs(save_dir, exist_ok=True)
        
        # Create evaluation environment
        self.eval_env = self.env
        
        # Callbacks
        eval_callback = EvalCallback(
            self.eval_env,
            best_model_save_path=save_dir,
            log_path=save_dir,
            eval_freq=eval_freq,
            n_eval_episodes=n_eval_episodes,
            deterministic=False,
            render=False
        )
        
        checkpoint_callback = CheckpointCallback(
            save_freq=eval_freq,
            save_path=save_dir,
            name_prefix=self.model_name
        )
        
        # Train the model
        logger.info(f"Starting training for {total_timesteps} timesteps...")
        start_time = datetime.now()
        
        self.model.learn(
            total_timesteps=total_timesteps,
            callback=[eval_callback, checkpoint_callback],
            progress_bar=True
        )
        
        end_time = datetime.now()
        training_time = (end_time - start_time).total_seconds()
        
        logger.info(f"Training completed in {training_time:.2f} seconds")
        
        # Save final model
        final_model_path = os.path.join(save_dir, f"{self.model_name}_final")
        self.model.save(final_model_path)
        logger.info(f"Model saved to {final_model_path}")
        
        return {
            "total_timesteps": total_timesteps,
            "training_time": training_time,
            "model_path": final_model_path
        }
    
    def evaluate(self, n_episodes: int = 10, deterministic: bool = True) -> Dict:
        """
        Evaluate the trained model.
        
        Args:
            n_episodes: Number of episodes to evaluate
            deterministic: Whether to use deterministic policy
            
        Returns:
            Evaluation metrics dictionary
        """
        if self.model is None:
            raise ValueError("Model not trained. Call train() first.")
        
        episode_rewards = []
        episode_lengths = []
        
        for episode in range(n_episodes):
            obs, info = self.env.reset()
            episode_reward = 0.0
            episode_length = 0
            done = False
            
            while not done:
                action, _ = self.model.predict(obs, deterministic=deterministic)
                obs, reward, terminated, truncated, info = self.env.step(action)
                episode_reward += reward
                episode_length += 1
                done = terminated or truncated
            
            episode_rewards.append(episode_reward)
            episode_lengths.append(episode_length)
            
            logger.info(f"Episode {episode + 1}: Reward={episode_reward:.4f}, Length={episode_length}")
        
        return {
            "mean_reward": np.mean(episode_rewards),
            "std_reward": np.std(episode_rewards),
            "mean_length": np.mean(episode_lengths),
            "episode_rewards": episode_rewards,
            "episode_lengths": episode_lengths
        }
    
    def predict(self, obs: np.ndarray, deterministic: bool = True) -> Tuple[int, Optional[np.ndarray]]:
        """
        Get action prediction from the model.
        
        Args:
            obs: Current observation
            deterministic: Whether to use deterministic policy
            
        Returns:
            Tuple of (action, state)
        """
        if self.model is None:
            raise ValueError("Model not trained.")
        
        action, state = self.model.predict(obs, deterministic=deterministic)
        return action, state
    
    def save_model(self, path: str) -> None:
        """
        Save the trained model.
        
        Args:
            path: Path to save the model
        """
        if self.model is None:
            raise ValueError("No model to save.")
        
        self.model.save(path)
        logger.info(f"Model saved to {path}")
    
    def load_model(self, path: str) -> None:
        """
        Load a trained model.
        
        Args:
            path: Path to the model file
        """
        if self.model_type == "ppo":
            self.model = PPO.load(path, env=self.env, device=self.device)
        elif self.model_type == "a2c":
            self.model = A2C.load(path, env=self.env, device=self.device)
        else:
            raise ValueError(f"Unknown model type: {self.model_type}")
        
        logger.info(f"Model loaded from {path}")
    
    def get_model_info(self) -> Dict:
        """
        Get information about the trained model.
        
        Returns:
            Dictionary with model information
        """
        if self.model is None:
            return {}
        
        return {
            "model_type": self.model_type,
            "model_name": self.model_name,
            "num_timesteps": self.model.num_timesteps,
            "policy": str(self.model.policy),
            "device": self.device
        }


class ModelTrainer:
    """
    Trainer class for managing model training pipeline.
    """
    
    def __init__(self, env, model_name: str = "trading_bot"):
        """
        Initialize the trainer.
        
        Args:
            env: Trading environment
            model_name: Name for the model
        """
        self.env = env
        self.model_name = model_name
        self.agent = None
        self.best_reward = float('-inf')
        self.training_log = []
    
    def train_with_hyperparameter_tuning(self, 
                                        hyperparams: Dict,
                                        total_timesteps: int = 100000) -> Dict:
        """
        Train model with given hyperparameters.
        
        Args:
            hyperparams: Dictionary of hyperparameters
            total_timesteps: Total timesteps for training
            
        Returns:
            Training results
        """
        self.agent = RLAgent(self.env, model_type="ppo", model_name=self.model_name)
        self.agent.create_model(**hyperparams)
        
        results = self.agent.train(total_timesteps=total_timesteps)
        
        # Evaluate
        eval_results = self.agent.evaluate(n_episodes=10)
        results.update(eval_results)
        
        # Log results
        self.training_log.append({
            "timestamp": datetime.now().isoformat(),
            "hyperparams": hyperparams,
            "results": results
        })
        
        return results
    
    def save_training_log(self, path: str) -> None:
        """
        Save training log to file.
        
        Args:
            path: Path to save the log
        """
        with open(path, 'w') as f:
            json.dump(self.training_log, f, indent=2, default=str)
        logger.info(f"Training log saved to {path}")


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    from trading_env import TradingEnvironment
    
    # Create dummy environment
    dummy_data = {
        'AVGO': np.random.randn(100, 60, 30).astype(np.float32),
        'TSLA': np.random.randn(100, 60, 30).astype(np.float32),
    }
    
    env = TradingEnvironment(dummy_data)
    
    # Create and train agent
    agent = RLAgent(env, model_type="ppo")
    agent.create_model(learning_rate=3e-4, n_steps=256)
    
    # Train for a short time
    results = agent.train(total_timesteps=1000, eval_freq=500)
    print(f"Training results: {results}")
    
    # Evaluate
    eval_results = agent.evaluate(n_episodes=5)
    print(f"Evaluation results: {eval_results}")
