import { useEffect, useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Activity } from 'lucide-react';

export default function TradingDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [selectedModelId, setSelectedModelId] = useState<number | null>(null);

  // Queries
  const { data: activeModel } = trpc.trading.activeModel.useQuery();
  const { data: stocks } = trpc.trading.stocks.useQuery();
  const { data: config } = trpc.trading.config.useQuery();
  
  const { data: openTrades } = trpc.trading.openTrades.useQuery(
    { modelId: selectedModelId || activeModel?.id || 0 },
    { enabled: !!selectedModelId || !!activeModel }
  );
  
  const { data: tradeHistory } = trpc.trading.tradeHistory.useQuery(
    { modelId: selectedModelId || activeModel?.id || 0, limit: 50 },
    { enabled: !!selectedModelId || !!activeModel }
  );
  
  const { data: positions } = trpc.trading.positions.useQuery(
    { modelId: selectedModelId || activeModel?.id || 0 },
    { enabled: !!selectedModelId || !!activeModel }
  );
  
  const { data: portfolioMetrics } = trpc.trading.portfolioMetrics.useQuery(
    { modelId: selectedModelId || activeModel?.id || 0, limit: 30 },
    { enabled: !!selectedModelId || !!activeModel }
  );
  
  const { data: logs } = trpc.trading.logs.useQuery({ limit: 50 });

  useEffect(() => {
    if (activeModel && !selectedModelId) {
      setSelectedModelId(activeModel.id);
    }
  }, [activeModel, selectedModelId]);

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>Please log in to access the trading dashboard</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  // Calculate summary metrics
  const totalOpenTrades = openTrades?.length || 0;
  const totalPositionValue = positions?.reduce((sum, p) => sum + (parseInt(p.currentPrice) * p.quantity), 0) || 0;
  const unrealizedPnL = positions?.reduce((sum, p) => sum + parseFloat(p.unrealizedPnL || '0'), 0) || 0;
  const latestMetrics = portfolioMetrics?.[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Trading Bot Dashboard</h1>
          <p className="text-slate-400">Real-time monitoring and control of your RL trading agent</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Portfolio Value</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">${latestMetrics?.totalValue || '0'}</div>
              <p className="text-xs text-slate-500 mt-1">Total account value</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Open Positions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white flex items-center gap-2">
                {totalOpenTrades}
                <Activity className="w-5 h-5 text-blue-400" />
              </div>
              <p className="text-xs text-slate-500 mt-1">Active trades</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Unrealized P&L</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold flex items-center gap-2 ${unrealizedPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                ${unrealizedPnL.toFixed(2)}
                {unrealizedPnL >= 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
              </div>
              <p className="text-xs text-slate-500 mt-1">Open position gains/losses</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Cash Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white flex items-center gap-2">
                ${latestMetrics?.cashBalance || '0'}
                <DollarSign className="w-5 h-5 text-yellow-400" />
              </div>
              <p className="text-xs text-slate-500 mt-1">Available cash</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="bg-slate-800 border-slate-700">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="positions">Positions</TabsTrigger>
            <TabsTrigger value="trades">Trade History</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Portfolio Value Chart */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Portfolio Value Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                  {portfolioMetrics && portfolioMetrics.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={portfolioMetrics}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                        <XAxis dataKey="date" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                          labelStyle={{ color: '#e2e8f0' }}
                        />
                        <Line type="monotone" dataKey="totalValue" stroke="#3b82f6" dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-[300px] flex items-center justify-center text-slate-500">
                      No data available
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* P&L Chart */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Realized P&L</CardTitle>
                </CardHeader>
                <CardContent>
                  {portfolioMetrics && portfolioMetrics.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={portfolioMetrics}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                        <XAxis dataKey="date" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                          labelStyle={{ color: '#e2e8f0' }}
                        />
                        <Bar dataKey="realizedPnL" fill="#10b981" />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-[300px] flex items-center justify-center text-slate-500">
                      No data available
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Positions Tab */}
          <TabsContent value="positions">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Current Positions</CardTitle>
              </CardHeader>
              <CardContent>
                {positions && positions.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="border-b border-slate-700">
                        <tr className="text-slate-400">
                          <th className="text-left py-3 px-4">Symbol</th>
                          <th className="text-right py-3 px-4">Quantity</th>
                          <th className="text-right py-3 px-4">Entry Price</th>
                          <th className="text-right py-3 px-4">Current Price</th>
                          <th className="text-right py-3 px-4">Unrealized P&L</th>
                          <th className="text-right py-3 px-4">Return %</th>
                        </tr>
                      </thead>
                      <tbody>
                        {positions.map((pos) => {
                          const pnl = parseFloat(pos.unrealizedPnL || '0');
                          const pnlPercent = parseFloat(pos.unrealizedPnLPercent || '0');
                          return (
                            <tr key={pos.id} className="border-b border-slate-700 hover:bg-slate-700/50">
                              <td className="py-3 px-4 text-white font-medium">
                                {stocks?.find(s => s.id === pos.stockId)?.symbol || 'N/A'}
                              </td>
                              <td className="text-right py-3 px-4 text-slate-300">{pos.quantity}</td>
                              <td className="text-right py-3 px-4 text-slate-300">${pos.averageEntryPrice}</td>
                              <td className="text-right py-3 px-4 text-slate-300">${pos.currentPrice}</td>
                              <td className={`text-right py-3 px-4 font-medium ${pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                ${pnl.toFixed(2)}
                              </td>
                              <td className={`text-right py-3 px-4 font-medium ${pnlPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                {pnlPercent.toFixed(2)}%
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    No open positions
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Trade History Tab */}
          <TabsContent value="trades">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Trade History</CardTitle>
              </CardHeader>
              <CardContent>
                {tradeHistory && tradeHistory.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="border-b border-slate-700">
                        <tr className="text-slate-400">
                          <th className="text-left py-3 px-4">Date</th>
                          <th className="text-left py-3 px-4">Symbol</th>
                          <th className="text-left py-3 px-4">Type</th>
                          <th className="text-right py-3 px-4">Quantity</th>
                          <th className="text-right py-3 px-4">Price</th>
                          <th className="text-right py-3 px-4">P&L</th>
                          <th className="text-left py-3 px-4">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {tradeHistory.map((trade) => {
                          const pnl = parseFloat(trade.profitLoss || '0');
                          return (
                            <tr key={trade.id} className="border-b border-slate-700 hover:bg-slate-700/50">
                              <td className="py-3 px-4 text-slate-300">{new Date(trade.entryTime).toLocaleDateString()}</td>
                              <td className="py-3 px-4 text-white font-medium">
                                {stocks?.find(s => s.id === trade.stockId)?.symbol || 'N/A'}
                              </td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-1 rounded text-xs font-medium ${
                                  trade.tradeType === 'buy' ? 'bg-blue-900 text-blue-200' : 'bg-red-900 text-red-200'
                                }`}>
                                  {trade.tradeType.toUpperCase()}
                                </span>
                              </td>
                              <td className="text-right py-3 px-4 text-slate-300">{trade.quantity}</td>
                              <td className="text-right py-3 px-4 text-slate-300">${trade.entryPrice}</td>
                              <td className={`text-right py-3 px-4 font-medium ${pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                {trade.status === 'closed' ? `$${pnl.toFixed(2)}` : '-'}
                              </td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-1 rounded text-xs font-medium ${
                                  trade.status === 'open' ? 'bg-yellow-900 text-yellow-200' : 'bg-green-900 text-green-200'
                                }`}>
                                  {trade.status.toUpperCase()}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    No trades yet
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Trading Configuration</CardTitle>
                <CardDescription className="text-slate-400">Adjust risk management and trading parameters</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {config ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="text-sm font-medium text-slate-300">Max Position Size</label>
                      <p className="text-2xl font-bold text-white mt-1">{config.maxPositionSize}</p>
                      <p className="text-xs text-slate-500 mt-1">% of portfolio per position</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-slate-300">Max Total Exposure</label>
                      <p className="text-2xl font-bold text-white mt-1">{config.maxTotalExposure}</p>
                      <p className="text-xs text-slate-500 mt-1">% of portfolio exposed</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-slate-300">Stop Loss</label>
                      <p className="text-2xl font-bold text-white mt-1">{config.stopLossPercent}</p>
                      <p className="text-xs text-slate-500 mt-1">Stop loss percentage</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-slate-300">Take Profit</label>
                      <p className="text-2xl font-bold text-white mt-1">{config.takeProfitPercent || 'N/A'}</p>
                      <p className="text-xs text-slate-500 mt-1">Take profit percentage</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-slate-300">Trading Hours</label>
                      <p className="text-2xl font-bold text-white mt-1">{config.tradingStartHour}:00 - {config.tradingEndHour}:00</p>
                      <p className="text-xs text-slate-500 mt-1">Market hours (24-hour format)</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-slate-300">Min Trade Interval</label>
                      <p className="text-2xl font-bold text-white mt-1">{config.minTradeInterval}s</p>
                      <p className="text-xs text-slate-500 mt-1">Seconds between trades</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    Loading configuration...
                  </div>
                )}
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  Edit Configuration
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Trading Logs</CardTitle>
              </CardHeader>
              <CardContent>
                {logs && logs.length > 0 ? (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {logs.map((log) => (
                      <div key={log.id} className="flex gap-3 p-3 bg-slate-700/50 rounded text-sm">
                        <span className={`font-medium px-2 py-1 rounded text-xs ${
                          log.level === 'error' ? 'bg-red-900 text-red-200' :
                          log.level === 'warning' ? 'bg-yellow-900 text-yellow-200' :
                          log.level === 'info' ? 'bg-blue-900 text-blue-200' :
                          'bg-slate-900 text-slate-300'
                        }`}>
                          {log.level.toUpperCase()}
                        </span>
                        <div className="flex-1">
                          <p className="text-slate-200">{log.message}</p>
                          <p className="text-xs text-slate-500 mt-1">
                            {new Date(log.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    No logs available
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
