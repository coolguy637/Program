"""
Interactive Brokers integration using ib_insync.
Handles connection, market data streaming, and order execution.
"""

import asyncio
from ib_insync import IB, Stock, MarketOrder, LimitOrder, Order
from typing import Dict, List, Optional, Callable
import logging
from datetime import datetime
import time

logger = logging.getLogger(__name__)


class IBKRConnector:
    \"\"\"\
    Interactive Brokers connector using ib_insync.
    Manages connection, market data, and order execution.
    \"\"\"\
    
    def __init__(self, host: str = '127.0.0.1', port: int = 7497, 
                 client_id: int = 1, account: Optional[str] = None):
        \"\"\"\
        Initialize the IBKR connector.
        
        Args:
            host: TWS/Gateway host
            port: TWS/Gateway port (7497 for live, 7498 for paper)
            client_id: Client ID for the connection
            account: Account ID (optional, will use default if not specified)
        \"\"\"\
        self.host = host
        self.port = port
        self.client_id = client_id
        self.account = account
        
        self.ib = IB()
        self.connected = False
        self.market_data_callbacks: Dict[str, List[Callable]] = {}
        self.order_callbacks: List[Callable] = []
        self.positions: Dict[str, int] = {}
        self.portfolio_value = 0.0
        self.cash_balance = 0.0
    
    async def connect(self) -> bool:
        \"\"\"\
        Connect to Interactive Brokers.
        
        Returns:
            True if connection successful, False otherwise
        \"\"\"\
        try:
            logger.info(f"Connecting to IBKR at {self.host}:{self.port}...")
            await self.ib.connectAsync(self.host, self.port, clientId=self.client_id)
            
            # Wait for connection to establish
            await asyncio.sleep(1)
            
            if self.ib.isConnected():
                self.connected = True
                logger.info("Connected to IBKR successfully")
                
                # Get account information
                await self._update_account_info()
                
                # Set up event handlers
                self._setup_event_handlers()
                
                return True
            else:
                logger.error("Failed to connect to IBKR")
                return False
                
        except Exception as e:
            logger.error(f"Connection error: {e}")
            return False
    
    def disconnect(self) -> None:
        \"\"\"\
        Disconnect from Interactive Brokers.
        \"\"\"\
        if self.ib.isConnected():
            self.ib.disconnect()
            self.connected = False
            logger.info("Disconnected from IBKR")
    
    def _setup_event_handlers(self) -> None:
        \"\"\"\
        Set up event handlers for IBKR events.
        \"\"\"\
        self.ib.connectedEvent += self._on_connected
        self.ib.disconnectedEvent += self._on_disconnected
        self.ib.orderStatusEvent += self._on_order_status
        self.ib.execDetailsEvent += self._on_exec_details
        self.ib.updatePortfolioEvent += self._on_portfolio_update
        self.ib.accountValueEvent += self._on_account_value
    
    def _on_connected(self) -> None:
        \"\"\"\
        Handle connection event.
        \"\"\"\
        logger.info("IBKR connected event triggered")
        self.connected = True
    
    def _on_disconnected(self) -> None:
        \"\"\"\
        Handle disconnection event.
        \"\"\"\
        logger.warning("IBKR disconnected event triggered")
        self.connected = False
    
    def _on_order_status(self, trade) -> None:
        \"\"\"\
        Handle order status update event.
        \"\"\"\
        logger.info(f"Order status update: {trade.order.orderId} - {trade.orderStatus.status}")
        
        # Trigger callbacks
        for callback in self.order_callbacks:
            try:
                callback(trade)
            except Exception as e:
                logger.error(f"Error in order callback: {e}")
    
    def _on_exec_details(self, trade, fill) -> None:
        \"\"\"\
        Handle execution details event.
        \"\"\"\
        logger.info(f"Execution: {trade.contract.symbol} - {fill.execution.shares}@{fill.execution.price}")
    
    def _on_portfolio_update(self, item) -> None:
        \"\"\"\
        Handle portfolio update event.
        \"\"\"\
        logger.debug(f"Portfolio update: {item.contract.symbol} - {item.position} shares")
        if item.contract.symbol:
            self.positions[item.contract.symbol] = item.position
    
    def _on_account_value(self, value) -> None:
        \"\"\"\
        Handle account value update event.
        \"\"\"\
        if value.tag == 'NetLiquidation':\
            self.portfolio_value = float(value.value)
        elif value.tag == 'CashBalance':
            self.cash_balance = float(value.value)
    
    async def _update_account_info(self) -> None:
        \"\"\"\
        Update account information.
        \"\"\"\
        try:
            # Get account summary
            account_values = self.ib.accountValues()
            
            for value in account_values:
                if value.tag == 'NetLiquidation':
                    self.portfolio_value = float(value.value)
                elif value.tag == 'CashBalance':
                    self.cash_balance = float(value.value)
            
            # Get positions
            portfolio = self.ib.portfolio()
            for item in portfolio:
                self.positions[item.contract.symbol] = item.position
            
            logger.info(f"Account info updated - Portfolio: ${self.portfolio_value:.2f}, Cash: ${self.cash_balance:.2f}")
            
        except Exception as e:
            logger.error(f"Error updating account info: {e}")
    
    def subscribe_market_data(self, symbols: List[str]) -> None:
        \"\"\"\
        Subscribe to market data for symbols.
        
        Args:
            symbols: List of stock symbols
        \"\"\"\
        for symbol in symbols:
            try:
                contract = Stock(symbol, 'SMART', 'USD')
                ticker = self.ib.reqMktData(contract, '', False, False)
                
                # Initialize callback list
                if symbol not in self.market_data_callbacks:
                    self.market_data_callbacks[symbol] = []
                
                logger.info(f"Subscribed to market data for {symbol}")
                
            except Exception as e:
                logger.error(f"Error subscribing to {symbol}: {e}")
    
    def unsubscribe_market_data(self, symbols: List[str]) -> None:
        \"\"\"\
        Unsubscribe from market data for symbols.
        
        Args:
            symbols: List of stock symbols
        \"\"\"\
        for symbol in symbols:
            try:
                contract = Stock(symbol, 'SMART', 'USD')
                self.ib.cancelMktData(contract)
                logger.info(f"Unsubscribed from market data for {symbol}")
                
            except Exception as e:
                logger.error(f"Error unsubscribing from {symbol}: {e}")
    
    def register_market_data_callback(self, symbol: str, callback: Callable) -> None:
        \"\"\"\
        Register a callback for market data updates.
        
        Args:
            symbol: Stock symbol
            callback: Callback function(ticker) to call on updates
        \"\"\"\
        if symbol not in self.market_data_callbacks:
            self.market_data_callbacks[symbol] = []
        
        self.market_data_callbacks[symbol].append(callback)
    
    def register_order_callback(self, callback: Callable) -> None:
        \"\"\"\
        Register a callback for order status updates.
        
        Args:
            callback: Callback function(trade) to call on updates
        \"\"\"\
        self.order_callbacks.append(callback)
    
    def get_market_data(self, symbol: str) -> Optional[Dict]:
        \"\"\"\
        Get current market data for a symbol.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Dictionary with market data or None if not available
        \"\"\"\
        try:
            contract = Stock(symbol, 'SMART', 'USD')
            ticker = self.ib.ticker(contract)
            
            if ticker:
                return {
                    'symbol': symbol,
                    'bid': ticker.bid,
                    'ask': ticker.ask,
                    'last': ticker.last,
                    'volume': ticker.volume,
                    'time': datetime.now().isoformat()
                }
            else:
                logger.warning(f"No market data available for {symbol}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting market data for {symbol}: {e}")
            return None
    
    def place_market_order(self, symbol: str, quantity: int, 
                          action: str = 'BUY') -> Optional[int]:
        \"\"\"\
        Place a market order.
        
        Args:
            symbol: Stock symbol
            quantity: Number of shares
            action: 'BUY' or 'SELL'
            
        Returns:
            Order ID or None if failed
        \"\"\"\
        try:
            contract = Stock(symbol, 'SMART', 'USD')
            order = MarketOrder(action, quantity)
            
            trade = self.ib.placeOrder(contract, order)
            logger.info(f"Placed {action} order for {quantity} shares of {symbol} - Order ID: {trade.order.orderId}")
            
            return trade.order.orderId
            
        except Exception as e:
            logger.error(f"Error placing market order for {symbol}: {e}")
            return None
    
    def place_limit_order(self, symbol: str, quantity: int, 
                         limit_price: float, action: str = 'BUY') -> Optional[int]:
        \"\"\"\
        Place a limit order.
        
        Args:
            symbol: Stock symbol
            quantity: Number of shares
            limit_price: Limit price
            action: 'BUY' or 'SELL'
            
        Returns:
            Order ID or None if failed
        \"\"\"\
        try:
            contract = Stock(symbol, 'SMART', 'USD')
            order = LimitOrder(action, quantity, limit_price)
            
            trade = self.ib.placeOrder(contract, order)
            logger.info(f"Placed {action} limit order for {quantity} shares of {symbol} @ ${limit_price} - Order ID: {trade.order.orderId}")
            
            return trade.order.orderId
            
        except Exception as e:
            logger.error(f"Error placing limit order for {symbol}: {e}")
            return None
    
    def cancel_order(self, order_id: int) -> bool:
        \"\"\"\
        Cancel an order.
        
        Args:
            order_id: Order ID to cancel
            
        Returns:
            True if successful, False otherwise
        \"\"\"\
        try:
            # Find the trade with this order ID
            for trade in self.ib.trades():
                if trade.order.orderId == order_id:
                    self.ib.cancelOrder(trade.order)
                    logger.info(f"Cancelled order {order_id}")
                    return True
            
            logger.warning(f"Order {order_id} not found")
            return False
            
        except Exception as e:
            logger.error(f"Error cancelling order {order_id}: {e}")
            return False
    
    def get_positions(self) -> Dict[str, int]:
        \"\"\"\
        Get current positions.
        
        Returns:
            Dictionary mapping symbol to quantity
        \"\"\"\
        return self.positions.copy()
    
    def get_position(self, symbol: str) -> int:
        \"\"\"\
        Get position for a specific symbol.
        
        Args:
            symbol: Stock symbol
            
        Returns:
            Quantity held (0 if no position)
        \"\"\"\
        return self.positions.get(symbol, 0)
    
    def get_portfolio_value(self) -> float:
        \"\"\"\
        Get total portfolio value.
        
        Returns:
            Portfolio value in USD
        \"\"\"\
        return self.portfolio_value
    
    def get_cash_balance(self) -> float:
        \"\"\"\
        Get cash balance.
        
        Returns:
            Cash balance in USD
        \"\"\"\
        return self.cash_balance
    
    def is_market_open(self) -> bool:
        \"\"\"\
        Check if US stock market is open.
        
        Returns:
            True if market is open, False otherwise
        \"\"\"\
        now = datetime.now()
        
        # Check if it's a weekday (0-4 = Mon-Fri)
        if now.weekday() >= 5:
            return False
        
        # Check if it's within market hours (9:30 AM - 4:00 PM ET)
        hour = now.hour
        minute = now.minute
        
        # Simplified check (doesn't account for daylight saving)
        if hour < 9 or hour >= 16:
            return False
        
        if hour == 9 and minute < 30:
            return False
        
        return True


# Async wrapper for easy use
async def create_ibkr_connector(host: str = '127.0.0.1', port: int = 7497,
                               client_id: int = 1) -> IBKRConnector:
    \"\"\"\
    Create and connect to IBKR.
    
    Args:
        host: TWS/Gateway host
        port: TWS/Gateway port
        client_id: Client ID
        
    Returns:
        Connected IBKRConnector instance
    \"\"\"\
    connector = IBKRConnector(host, port, client_id)
    success = await connector.connect()
    
    if not success:
        raise ConnectionError("Failed to connect to IBKR")
    
    return connector


if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    
    async def main():
        try:
            # Connect to IBKR
            connector = await create_ibkr_connector()
            
            # Subscribe to market data
            connector.subscribe_market_data(['AAPL', 'MSFT', 'GOOGL'])
            
            # Get market data
            await asyncio.sleep(2)
            data = connector.get_market_data('AAPL')
            print(f"Market data: {data}")
            
            # Get positions
            positions = connector.get_positions()
            print(f"Positions: {positions}")
            
            # Disconnect
            connector.disconnect()
            
        except Exception as e:
            logger.error(f"Error: {e}")
    
    # Run async main
    asyncio.run(main())
