# IBKR RL Trading Bot

A pure Python reinforcement learning trading bot that connects to Interactive Brokers for automated trading. The bot learns price patterns from historical data without technical indicators, incorporates market sentiment analysis (30% weight), uses deep neural networks (LSTM + CNN hybrid), and continuously learns from live trading data.

## Features

- **Neural Network Architecture**: Hybrid LSTM + CNN model for learning complex price patterns
- **Reinforcement Learning**: PPO agent that learns optimal trading actions (buy, sell, hold)
- **Market Sentiment**: Integrates news, social media, and market sentiment (30% weight in decisions)
- **Live Trading**: Direct connection to Interactive Brokers for automated order execution
- **Online Learning**: Continuously updates models with new data collected during trading
- **Risk Management**: Position sizing, stop-loss, take-profit, and exposure limits
- **Daily Trading**: Designed for daily timeframe trading
- **8 Stocks**: Trades AVGO, TSLA, MU, COST, ABBV, NFLX, INTC, IBM

## Architecture

### Components

1. **Data Pipeline** (`data_pipeline.py`)
   - Fetches historical price data from yfinance
   - Normalizes data to 0-1 range
   - Creates sequences for neural network training
   - Maintains real-time data buffer

2. **Sentiment Engine** (`sentiment_engine.py`)
   - Aggregates sentiment from multiple sources
   - News sentiment via NewsAPI
   - Social media sentiment via Twitter API
   - Market sentiment from volume and volatility
   - Returns combined sentiment score (-1 to 1)

3. **Neural Network** (`neural_network.py`)
   - Hybrid architecture: CNN for local patterns, LSTM for temporal patterns
   - Input: Raw OHLCV data + sentiment sequences
   - Output: Predicted next day's price (normalized 0-1)
   - Trainable on historical data and live data

4. **RL Agent** (`rl_agent.py`)
   - PPO (Proximal Policy Optimization) agent
   - Actor-Critic network architecture
   - Actions: 0=hold, 1=buy, 2=sell
   - State: Price patterns + sentiment + portfolio metrics
   - Learns from rewards (profit/loss)

5. **IBKR Connector** (`ibkr_connector.py`)
   - Async connection to Interactive Brokers
   - Market data streaming
   - Order execution (market and limit orders)
   - Position tracking
   - Account management

6. **Online Learner** (`online_learner.py`)
   - Maintains rolling buffer of recent experiences
   - Updates models periodically with new data
   - Prioritized experience replay
   - Adaptive learning schedule

7. **Trading Bot** (`trading_bot.py`)
   - Main orchestrator coordinating all components
   - Trading cycle: collect data → analyze sentiment → make decisions → execute trades
   - Logging and trade history tracking
   - Configuration management

## Installation

### Prerequisites

- Python 3.8+
- Interactive Brokers account (paper or live)
- TWS (Trader Workstation) or IB Gateway running
- API keys for sentiment data (optional but recommended)

### Setup

1. **Clone or download the project**
```bash
cd trading-bot-pure
```

2. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Configure IBKR connection**

   Create `config.json`:
   ```json
   {
     "ibkr_host": "127.0.0.1",
     "ibkr_port": 7497,
     "ibkr_client_id": 1,
     "max_position_size": 0.3,
     "max_total_exposure": 0.9,
     "stop_loss_percent": 0.05,
     "take_profit_percent": 0.10,
     "min_trade_interval": 300,
     "trading_enabled": false,
     "trading_start_hour": 9,
     "trading_end_hour": 16,
     "newsapi_key": "YOUR_NEWSAPI_KEY",
     "twitter_bearer_token": "YOUR_TWITTER_TOKEN",
     "confidence_threshold": 0.6,
     "initial_balance": 100000
   }
   ```

5. **Start TWS or IB Gateway**
   - Download from https://www.interactivebrokers.com
   - Log in with your credentials
   - Enable API in settings

## Configuration

### Key Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `ibkr_host` | 127.0.0.1 | IBKR connection host |
| `ibkr_port` | 7497 | IBKR port (7497=paper, 7496=live) |
| `max_position_size` | 0.3 | Max position as % of portfolio |
| `max_total_exposure` | 0.9 | Max total exposure as % of portfolio |
| `stop_loss_percent` | 0.05 | Stop loss at 5% loss |
| `take_profit_percent` | 0.10 | Take profit at 10% gain |
| `min_trade_interval` | 300 | Minimum seconds between trades per symbol |
| `trading_enabled` | false | Enable/disable live trading |
| `confidence_threshold` | 0.6 | Minimum confidence to execute trade |
| `newsapi_key` | null | NewsAPI key for news sentiment |
| `twitter_bearer_token` | null | Twitter API token for social sentiment |

### Getting API Keys

**NewsAPI** (Free tier available):
1. Go to https://newsapi.org
2. Sign up for free account
3. Get API key from dashboard
4. Add to `config.json`

**Twitter API** (Requires approval):
1. Go to https://developer.twitter.com
2. Create app and get bearer token
3. Add to `config.json`

## Usage

### Training on Historical Data

```python
from data_pipeline import DataPipeline
from neural_network import PricePredictor

# Fetch historical data
symbols = ['AVGO', 'TSLA', 'MU', 'COST', 'ABBV', 'NFLX', 'INTC', 'IBM']
pipeline = DataPipeline(symbols, lookback_days=365)
pipeline.fetch_historical_data()
pipeline.normalize_data()

# Create sequences
X, y = pipeline.create_sequences(sequence_length=30)

# Train model
predictor = PricePredictor()
predictor.build_model()
predictor.train(X['TSLA'], y['TSLA'], epochs=20)
predictor.save_model('models/price_predictor.pt')
```

### Running the Trading Bot

```bash
python trading_bot.py
```

The bot will:
1. Connect to IBKR
2. Fetch historical data for all symbols
3. Train initial models
4. Subscribe to market data
5. Enter main trading loop
6. Make trading decisions based on price patterns and sentiment
7. Execute trades automatically
8. Continuously learn from new data

### Paper Trading (Recommended First)

1. Ensure `ibkr_port` is set to 7497 (paper trading)
2. Set `trading_enabled` to false initially
3. Run bot to collect data and verify decisions
4. Review trade logs and performance
5. Once confident, set `trading_enabled` to true

### Live Trading

⚠️ **WARNING**: Live trading uses real money. Test thoroughly on paper trading first.

1. Switch to live account in TWS
2. Set `ibkr_port` to 7496 (live trading)
3. Set `trading_enabled` to true in config
4. Start with small position sizes
5. Monitor closely for first week

## Model Architecture

### Price Predictor (Supervised Learning)

```
Input: (batch_size, 30, 5)  # 30 days of OHLCV
  ↓
CNN Branch:
  - Conv1D(5 → 32) + BatchNorm + ReLU
  - Conv1D(32 → 64) + BatchNorm + ReLU
  - Conv1D(64 → 128) + BatchNorm + ReLU
  - Flatten → (batch_size, 3840)
  ↓
LSTM Branch:
  - LSTM(5 → 64, 2 layers)
  - Output: (batch_size, 64)
  ↓
Sentiment Input: (batch_size, 30)
  ↓
Concatenate: (batch_size, 3840 + 64 + 30 = 3934)
  ↓
Dense Layers:
  - Linear(3934 → 256) + ReLU + Dropout
  - Linear(256 → 128) + ReLU + Dropout
  - Linear(128 → 1) + Sigmoid
  ↓
Output: (batch_size, 1)  # Normalized price prediction (0-1)
```

### RL Agent (PPO)

```
State: (batch_size, 32)  # 30 sentiment + 2 portfolio features
  ↓
Shared Feature Extraction:
  - Linear(32 → 128) + ReLU + Dropout
  - Linear(128 → 128) + ReLU + Dropout
  ↓
Actor Head (Policy):
  - Linear(128 → 64) + ReLU
  - Linear(64 → 3) + Softmax  # 3 actions: hold, buy, sell
  ↓
Critic Head (Value):
  - Linear(128 → 64) + ReLU
  - Linear(64 → 1)  # Value estimate
```

## Decision Making

The bot makes trading decisions by combining multiple signals:

1. **Price Prediction** (70% weight)
   - Neural network predicts next day's price
   - If predicted price > current: bullish signal
   - If predicted price < current: bearish signal

2. **Market Sentiment** (30% weight)
   - News sentiment: 40% of sentiment score
   - Social sentiment: 30% of sentiment score
   - Market sentiment: 30% of sentiment score
   - Combined into -1 to 1 score

3. **RL Agent Decision**
   - PPO agent learns optimal actions from rewards
   - Actions: buy, sell, hold
   - Rewards based on profit/loss

4. **Confidence Threshold**
   - Trade only if confidence > threshold (default 0.6)
   - Confidence = |sentiment_score| * 0.3
   - Prevents low-confidence trades

## Monitoring

### Log Files

- `trading_bot.log`: Main application log
- `logs/trades_*.json`: Trade history with timestamps and details
- `models/`: Saved model checkpoints

### Trade Log Example

```json
{
  "timestamp": "2024-01-15T10:30:00",
  "symbol": "TSLA",
  "action": "BUY",
  "shares": 10,
  "price": 250.50,
  "confidence": 0.75,
  "order_id": "12345"
}
```

### Performance Metrics

Track these metrics over time:
- Total return (%)
- Sharpe ratio
- Maximum drawdown
- Win rate (% profitable trades)
- Average profit per trade
- Model accuracy

## Online Learning

The bot continuously learns from live trading data:

1. **Experience Collection**
   - Every trade adds experience to buffer
   - Experiences include: state, action, reward, next state

2. **Periodic Updates**
   - Every 100 samples, models are updated
   - Uses prioritized experience replay
   - Adaptive learning schedule

3. **Model Improvement**
   - Price predictor learns new price patterns
   - RL agent learns better trading actions
   - Both models improve with more data

## Risk Management

### Position Sizing

- Max position: 30% of portfolio per symbol
- Max total exposure: 90% of portfolio
- Remaining 10% kept as cash buffer

### Stop Loss & Take Profit

- Stop loss: Close position if loss exceeds 5%
- Take profit: Close position if profit exceeds 10%
- Prevents large losses and locks in gains

### Trade Frequency

- Minimum 5 minutes between trades per symbol
- Prevents overtrading and excessive fees
- Allows time for market impact

## Troubleshooting

### Connection Issues

**Problem**: "Connection refused" to IBKR

**Solutions**:
1. Verify TWS/IB Gateway is running
2. Check port is correct (7497 for paper, 7496 for live)
3. Ensure firewall allows localhost connections
4. Check API is enabled in account settings

### No Market Data

**Problem**: Market data not streaming

**Solutions**:
1. Verify market is open (9:30 AM - 4:00 PM ET, weekdays)
2. Check symbols are valid
3. Verify subscription to market data is active
4. Check data subscription level in IB account

### Models Not Improving

**Problem**: Trading performance not improving over time

**Solutions**:
1. Increase training data (lookback_days)
2. Adjust learning rate in config
3. Increase update frequency for online learning
4. Verify sentiment data sources are working
5. Check confidence threshold isn't too high

### Out of Memory

**Problem**: "CUDA out of memory" or similar

**Solutions**:
1. Reduce batch size in training
2. Reduce buffer size for online learning
3. Use CPU instead of GPU (slower but uses less memory)
4. Reduce number of symbols being tracked

## Performance Tips

1. **Use IB Gateway instead of TWS** - Lower resource usage
2. **Run on dedicated machine** - Prevents interruptions
3. **Monitor logs regularly** - Catch issues early
4. **Start with paper trading** - Test before live
5. **Use limit orders** - Better execution prices
6. **Rebalance portfolio** - Maintain risk limits
7. **Update models regularly** - Keep up with market changes

## Advanced Customization

### Adding New Symbols

Edit `trading_bot.py`:
```python
symbols = ['AVGO', 'TSLA', 'MU', 'COST', 'ABBV', 'NFLX', 'INTC', 'IBM', 'NEW_SYMBOL']
```

### Changing Model Architecture

Edit `neural_network.py`:
```python
# Modify CNN channels
cnn_channels = [64, 128, 256]

# Modify LSTM hidden size
lstm_hidden_size = 128

# Modify dense layers
dense_units = [512, 256, 128]
```

### Adjusting RL Agent

Edit `rl_agent.py`:
```python
# Modify PPO parameters
clip_ratio = 0.3  # Larger = more conservative
gae_lambda = 0.95  # Closer to 1 = more variance
gamma = 0.99  # Discount factor
```

## Disclaimer

This trading bot is provided for educational purposes. Trading involves risk of loss. Past performance does not guarantee future results. Always:

1. Test thoroughly on paper trading first
2. Start with small position sizes on live trading
3. Monitor the bot closely
4. Understand the risks
5. Never invest more than you can afford to lose
6. Consult with a financial advisor if needed

## License

MIT License - See LICENSE file for details

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review log files for error messages
3. Verify configuration is correct
4. Test with paper trading first

## Future Enhancements

- [ ] Multi-timeframe analysis (intraday + daily)
- [ ] Advanced risk management (Kelly criterion)
- [ ] Portfolio optimization (mean-variance)
- [ ] Ensemble models (multiple RL agents)
- [ ] Backtesting framework with walk-forward analysis
- [ ] Web dashboard for monitoring
- [ ] Telegram/Email notifications
- [ ] Support for options trading
- [ ] Machine learning feature engineering
- [ ] Sentiment from earnings calls

## References

- Interactive Brokers API: https://ib-insync.readthedocs.io/
- PyTorch Documentation: https://pytorch.org/docs/
- Stable Baselines3: https://stable-baselines3.readthedocs.io/
- NewsAPI: https://newsapi.org/
- Twitter API: https://developer.twitter.com/

---

**Last Updated**: January 2024
**Version**: 1.0.0
