import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Stocks table - list of stocks to trade
 */
export const stocks = mysqlTable("stocks", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 10 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Stock = typeof stocks.$inferSelect;
export type InsertStock = typeof stocks.$inferInsert;

/**
 * Models table - RL model versions and metadata
 */
export const models = mysqlTable("models", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  version: varchar("version", { length: 64 }).notNull(),
  modelType: varchar("modelType", { length: 64 }).notNull(), // "ppo", "a2c", etc.
  status: mysqlEnum("status", ["training", "trained", "active", "archived"]).default("trained").notNull(),
  isActive: int("isActive").default(0).notNull(), // Boolean as int
  trainingStartedAt: timestamp("trainingStartedAt"),
  trainingCompletedAt: timestamp("trainingCompletedAt"),
  backTestStartDate: varchar("backTestStartDate", { length: 10 }), // YYYY-MM-DD
  backTestEndDate: varchar("backTestEndDate", { length: 10 }),
  backTestReturn: text("backTestReturn"), // JSON: {total: 0.15, sharpe: 1.2, maxDrawdown: -0.08}
  hyperparameters: text("hyperparameters"), // JSON: {learning_rate, network_size, etc.}
  modelPath: text("modelPath"), // S3 path to model file
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Model = typeof models.$inferSelect;
export type InsertModel = typeof models.$inferInsert;

/**
 * Trades table - executed trades
 */
export const trades = mysqlTable("trades", {
  id: int("id").autoincrement().primaryKey(),
  modelId: int("modelId").notNull(),
  stockId: int("stockId").notNull(),
  tradeType: mysqlEnum("tradeType", ["buy", "sell"]).notNull(),
  quantity: int("quantity").notNull(),
  entryPrice: text("entryPrice").notNull(), // Decimal as string
  exitPrice: text("exitPrice"), // NULL for open positions
  entryTime: timestamp("entryTime").notNull(),
  exitTime: timestamp("exitTime"),
  status: mysqlEnum("status", ["open", "closed", "cancelled"]).default("open").notNull(),
  profitLoss: text("profitLoss"), // Decimal as string, NULL for open
  profitLossPercent: text("profitLossPercent"), // Decimal as string
  commission: text("commission"), // Decimal as string
  ibOrderId: varchar("ibOrderId", { length: 64 }), // Interactive Brokers order ID
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = typeof trades.$inferInsert;

/**
 * Positions table - current open positions
 */
export const positions = mysqlTable("positions", {
  id: int("id").autoincrement().primaryKey(),
  modelId: int("modelId").notNull(),
  stockId: int("stockId").notNull(),
  quantity: int("quantity").notNull(),
  averageEntryPrice: text("averageEntryPrice").notNull(), // Decimal as string
  currentPrice: text("currentPrice").notNull(),
  unrealizedPnL: text("unrealizedPnL"), // Decimal as string
  unrealizedPnLPercent: text("unrealizedPnLPercent"), // Decimal as string
  lastUpdated: timestamp("lastUpdated").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Position = typeof positions.$inferSelect;
export type InsertPosition = typeof positions.$inferInsert;

/**
 * Portfolio metrics - daily portfolio snapshots
 */
export const portfolioMetrics = mysqlTable("portfolioMetrics", {
  id: int("id").autoincrement().primaryKey(),
  modelId: int("modelId").notNull(),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  totalValue: text("totalValue").notNull(), // Decimal as string
  cashBalance: text("cashBalance").notNull(),
  realizedPnL: text("realizedPnL").notNull(),
  unrealizedPnL: text("unrealizedPnL").notNull(),
  totalReturn: text("totalReturn"), // Decimal as string
  sharpeRatio: text("sharpeRatio"), // Decimal as string
  maxDrawdown: text("maxDrawdown"), // Decimal as string
  winRate: text("winRate"), // Decimal as string (0-1)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PortfolioMetrics = typeof portfolioMetrics.$inferSelect;
export type InsertPortfolioMetrics = typeof portfolioMetrics.$inferInsert;

/**
 * Predictions table - model predictions for each stock
 */
export const predictions = mysqlTable("predictions", {
  id: int("id").autoincrement().primaryKey(),
  modelId: int("modelId").notNull(),
  stockId: int("stockId").notNull(),
  predictionTime: timestamp("predictionTime").notNull(),
  action: mysqlEnum("action", ["buy", "sell", "hold"]).notNull(),
  confidence: text("confidence").notNull(), // Decimal as string (0-1)
  predictedPrice: text("predictedPrice"), // Decimal as string
  actualPrice: text("actualPrice"), // Filled later
  accuracy: text("accuracy"), // Filled later when actual price known
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = typeof predictions.$inferInsert;

/**
 * Trading configuration - settings for the trading bot
 */
export const tradingConfig = mysqlTable("tradingConfig", {
  id: int("id").autoincrement().primaryKey(),
  activeModelId: int("activeModelId"),
  maxPositionSize: text("maxPositionSize").notNull(), // Decimal: max % of portfolio per position
  maxTotalExposure: text("maxTotalExposure").notNull(), // Decimal: max % of portfolio exposed
  stopLossPercent: text("stopLossPercent").notNull(), // Decimal: stop loss %
  takeProfitPercent: text("takeProfitPercent"), // Decimal: take profit %
  tradingEnabled: int("tradingEnabled").default(1).notNull(), // Boolean as int
  tradingStartHour: int("tradingStartHour").default(9).notNull(), // 9 AM
  tradingEndHour: int("tradingEndHour").default(16).notNull(), // 4 PM
  rebalanceFrequency: varchar("rebalanceFrequency", { length: 64 }).default("daily").notNull(), // "daily", "weekly", "monthly"
  minTradeInterval: int("minTradeInterval").default(300).notNull(), // seconds between trades
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TradingConfig = typeof tradingConfig.$inferSelect;
export type InsertTradingConfig = typeof tradingConfig.$inferInsert;

/**
 * Trading logs - detailed logs of trading events
 */
export const tradingLogs = mysqlTable("tradingLogs", {
  id: int("id").autoincrement().primaryKey(),
  modelId: int("modelId"),
  level: mysqlEnum("level", ["info", "warning", "error", "debug"]).notNull(),
  message: text("message").notNull(),
  metadata: text("metadata"), // JSON: additional context
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TradingLog = typeof tradingLogs.$inferSelect;
export type InsertTradingLog = typeof tradingLogs.$inferInsert;