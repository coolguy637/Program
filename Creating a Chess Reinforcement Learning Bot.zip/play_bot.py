import torch
import chess
from chess_env import ChessEnv
from chess_model import ChessNet, load_model
from mcts import MCTS

def play():
    model = load_model("chess_model.pth")
    model.eval()
    mcts = MCTS(model)
    env = ChessEnv()
    
    print("Welcome to Chess RL Bot!")
    print(env.board)
    
    while not env.board.is_game_over():
        if env.board.turn == chess.WHITE:
            # Human move
            move_str = input("Enter your move (e.g., e2e4): ")
            try:
                move = chess.Move.from_uci(move_str)
                if move in env.board.legal_moves:
                    env.board.push(move)
                else:
                    print("Illegal move!")
                    continue
            except ValueError:
                print("Invalid format! Use UCI (e.g., e2e4).")
                continue
        else:
            # Bot move
            print("Bot is thinking...")
            move = mcts.search(env.board, num_simulations=100)
            print(f"Bot plays: {move}")
            env.board.push(move)
            
        print("\n", env.board, "\n")
        
    print("Game Over!")
    print(f"Result: {env.board.result()}")

if __name__ == "__main__":
    # Ensure a model exists
    import os
    if not os.path.exists("chess_model.pth"):
        model = ChessNet()
        torch.save(model.state_dict(), "chess_model.pth")
    play()
