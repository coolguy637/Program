import torch
import torch.optim as optim
import torch.nn as nn
from chess_env import ChessEnv, move_to_index
from chess_model import ChessNet, save_model
from mcts import MCTS
import random

def self_play(model, num_games=5):
    dataset = []
    mcts = MCTS(model)
    env = ChessEnv()
    
    for i in range(num_games):
        print(f"Starting game {i+1}...")
        state = env.reset()
        game_history = []
        
        while not env.board.is_game_over():
            move = mcts.search(env.board, num_simulations=50)
            
            # Store state and policy (simplified policy as one-hot of chosen move)
            # In real AlphaZero, we store the visit counts as the target policy
            policy_target = np.zeros(4096)
            policy_target[move_to_index(move)] = 1.0
            
            game_history.append((state, policy_target))
            
            state, reward, done, _ = env.step(move)
            
        # Assign final reward to all states in the game
        result = env.board.result()
        if result == "1-0":
            final_reward = 1
        elif result == "0-1":
            final_reward = -1
        else:
            final_reward = 0
            
        for state, policy in game_history:
            dataset.append((state, policy, final_reward))
            
    return dataset

def train(model, dataset, epochs=5):
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    mse_loss = nn.MSELoss()
    ce_loss = nn.CrossEntropyLoss()
    
    model.train()
    for epoch in range(epochs):
        total_loss = 0
        random.shuffle(dataset)
        
        for state, policy_target, value_target in dataset:
            optimizer.zero_grad()
            
            state_t = torch.FloatTensor(state).unsqueeze(0)
            policy_t = torch.FloatTensor(policy_target).unsqueeze(0)
            value_t = torch.FloatTensor([value_target]).unsqueeze(0)
            
            p_out, v_out = model(state_t)
            
            # Loss = Value Loss + Policy Loss
            v_loss = mse_loss(v_out, value_t)
            p_loss = F.cross_entropy(p_out, torch.argmax(policy_t, dim=1))
            
            loss = v_loss + p_loss
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            
        print(f"Epoch {epoch+1}, Loss: {total_loss/len(dataset)}")

if __name__ == "__main__":
    import torch.nn.functional as F
    import numpy as np
    
    model = ChessNet()
    print("Collecting self-play data...")
    data = self_play(model, num_games=2) # Small number for demo
    print(f"Training on {len(data)} positions...")
    train(model, data, epochs=3)
    save_model(model, "chess_model.pth")
    print("Model saved.")
