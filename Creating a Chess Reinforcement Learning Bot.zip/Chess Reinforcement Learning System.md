# Chess Reinforcement Learning System

The Chess Reinforcement Learning System is a sophisticated framework designed to develop a chess-playing agent that learns from both self-play and external game data. Inspired by the AlphaZero architecture, this system integrates deep neural networks with advanced search algorithms to achieve strategic decision-making capabilities.

## System Architecture

The core of the system is built upon three primary components that work in tandem to evaluate positions and select optimal moves.

| Component | Description |
| :--- | :--- |
| **Neural Network** | A dual-headed Convolutional Neural Network (CNN) that processes an 8x8x12 tensor representation of the board. It outputs a policy vector for move probabilities and a scalar value for position evaluation. |
| **Search Algorithm** | A Monte Carlo Tree Search (MCTS) implementation that utilizes the neural network's policy and value outputs to guide its exploration of the game tree. |
| **Environment** | A wrapper around the `python-chess` library that manages board states, validates legal moves, and handles game terminal conditions. |

## Operational Workflows

The system supports two primary methods for improving the agent's performance: autonomous self-play and supervised fine-tuning from historical data.

### Autonomous Self-Play
In the self-play mode, the agent plays games against itself using its current neural network model. The MCTS search allows it to discover better moves than its raw policy would suggest. The states, visit counts, and final outcomes are recorded to form a training dataset, which is then used to optimize the neural network through backpropagation.

### Data Ingestion and Fine-Tuning
The system includes a dedicated pipeline for ingesting Portable Game Notation (PGN) files. This allows the agent to analyze data from high-level human or engine games, learning to emulate professional-grade decision-making and improving its initial evaluation capabilities before starting the reinforcement learning process.

## Implementation Details

The project is structured into modular Python components for ease of maintenance and extension.

*   **chess_env.py**: Defines the board representation and the interface for move execution.
*   **chess_model.py**: Contains the PyTorch implementation of the CNN architecture.
*   **mcts.py**: Implements the tree search logic, including selection, expansion, and backpropagation.
*   **train.py**: Orchestrates the self-play loop and the neural network optimization process.
*   **data_ingestion.py**: Provides tools for parsing PGN files and fine-tuning the model on external datasets.
*   **play_bot.py**: Offers a command-line interface for human players to interact with and challenge the bot.

To begin training, users should execute the `train.py` script, while the `play_bot.py` script can be used to test the agent's performance in real-time.
