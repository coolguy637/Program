import math
import numpy as np
import torch
import chess
from chess_env import move_to_index

class MCTSNode:
    def __init__(self, board, parent=None, prior=0):
        self.board = board
        self.parent = parent
        self.children = {} # move -> MCTSNode
        self.visit_count = 0
        self.value_sum = 0
        self.prior = prior

    @property
    def value(self):
        if self.visit_count == 0:
            return 0
        return self.value_sum / self.visit_count

    def select_child(self, c_puct):
        best_score = -float('inf')
        best_move = None
        best_child = None

        for move, child in self.children.items():
            # Upper Confidence Bound applied to Trees (UCT) variant for AlphaZero
            score = child.value + c_puct * child.prior * math.sqrt(self.visit_count) / (1 + child.visit_count)
            if score > best_score:
                best_score = score
                best_move = move
                best_child = child
        return best_move, best_child

    def expand(self, model):
        # Convert board to tensor
        from chess_env import ChessEnv
        env = ChessEnv()
        env.board = self.board.copy()
        state = torch.FloatTensor(env.get_state()).unsqueeze(0)
        
        with torch.no_grad():
            policy_logits, value = model(state)
        
        policy = torch.softmax(policy_logits, dim=1).numpy()[0]
        
        # Expand children for all legal moves
        for move in self.board.legal_moves:
            idx = move_to_index(move)
            if idx < len(policy):
                prob = policy[idx]
                new_board = self.board.copy()
                new_board.push(move)
                self.children[move] = MCTSNode(new_board, parent=self, prior=prob)
        
        return value.item()

    def backpropagate(self, value):
        self.visit_count += 1
        self.value_sum += value
        if self.parent:
            # Flip value for the opponent's perspective
            self.parent.backpropagate(-value)

class MCTS:
    def __init__(self, model, c_puct=1.4):
        self.model = model
        self.c_puct = c_puct

    def search(self, board, num_simulations=100):
        root = MCTSNode(board)
        
        # Initial expansion
        root.expand(self.model)
        
        for _ in range(num_simulations):
            node = root
            # Selection
            while node.children:
                move, node = node.select_child(self.c_puct)
            
            # Expansion & Evaluation
            if not node.board.is_game_over():
                value = node.expand(self.model)
            else:
                # Terminal state evaluation
                res = node.board.result()
                if res == "1-0":
                    value = 1 if node.board.turn == chess.WHITE else -1
                elif res == "0-1":
                    value = -1 if node.board.turn == chess.WHITE else 1
                else:
                    value = 0
            
            # Backpropagation
            node.backpropagate(value)
            
        # Return move with highest visit count
        best_move = max(root.children.items(), key=lambda item: item[1].visit_count)[0]
        return best_move
