import chess.pgn
import torch
import numpy as np
from chess_env import ChessEnv, move_to_index
from chess_model import ChessNet, save_model
import torch.nn.functional as F
import torch.optim as optim
import torch.nn as nn

def ingest_pgn(file_path, max_games=10):
    dataset = []
    pgn = open(file_path)
    
    game_count = 0
    while game_count < max_games:
        game = chess.pgn.read_game(pgn)
        if game is None:
            break
            
        board = game.board()
        result = game.headers.get("Result")
        
        if result == "1-0":
            final_reward = 1
        elif result == "0-1":
            final_reward = -1
        else:
            final_reward = 0
            
        env = ChessEnv()
        for move in game.mainline_moves():
            state = env.get_state()
            
            # Target policy: the actual move played in the game
            policy_target = np.zeros(4096)
            try:
                policy_target[move_to_index(move)] = 1.0
                dataset.append((state, policy_target, final_reward))
            except IndexError:
                # Skip moves that don't fit our simplified index
                pass
                
            env.board.push(move)
            
        game_count += 1
        
    return dataset

def fine_tune(model, dataset, epochs=5):
    optimizer = optim.Adam(model.parameters(), lr=0.0005)
    mse_loss = nn.MSELoss()
    
    model.train()
    for epoch in range(epochs):
        total_loss = 0
        for state, policy_target, value_target in dataset:
            optimizer.zero_grad()
            
            state_t = torch.FloatTensor(state).unsqueeze(0)
            policy_t = torch.FloatTensor(policy_target).unsqueeze(0)
            value_t = torch.FloatTensor([value_target]).unsqueeze(0)
            
            p_out, v_out = model(state_t)
            
            v_loss = mse_loss(v_out, value_t)
            p_loss = F.cross_entropy(p_out, torch.argmax(policy_t, dim=1))
            
            loss = v_loss + p_loss
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            
        print(f"Fine-tuning Epoch {epoch+1}, Loss: {total_loss/len(dataset)}")

if __name__ == "__main__":
    # Create a dummy PGN for demonstration
    pgn_content = """[Event "Example"]
[Result "1-0"]
1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 d6 8. c3 O-O 9. h3 Nb8 10. d4 Nbd7 1-0
"""
    with open("example.pgn", "w") as f:
        f.write(pgn_content)
        
    model = ChessNet()
    print("Ingesting PGN data...")
    data = ingest_pgn("example.pgn")
    print(f"Extracted {len(data)} positions. Fine-tuning...")
    fine_tune(model, data, epochs=3)
    save_model(model, "chess_model_tuned.pth")
    print("Fine-tuned model saved.")
