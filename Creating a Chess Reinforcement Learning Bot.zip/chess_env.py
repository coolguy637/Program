import chess
import numpy as np

class ChessEnv:
    def __init__(self):
        self.board = chess.Board()

    def reset(self):
        self.board = chess.Board()
        return self.get_state()

    def get_state(self):
        """
        Converts the board to an 8x8x12 tensor representation.
        Layers 0-5: White pieces (P, N, B, R, Q, K)
        Layers 6-11: Black pieces (P, N, B, R, Q, K)
        """
        state = np.zeros((12, 8, 8), dtype=np.float32)
        piece_map = {
            chess.PAWN: 0,
            chess.KNIGHT: 1,
            chess.BISHOP: 2,
            chess.ROOK: 3,
            chess.QUEEN: 4,
            chess.KING: 5
        }
        
        for square, piece in self.board.piece_map().items():
            row = 7 - (square // 8)
            col = square % 8
            layer = piece_map[piece.piece_type]
            if piece.color == chess.BLACK:
                layer += 6
            state[layer, row, col] = 1.0
            
        return state

    def get_legal_moves(self):
        return list(self.board.legal_moves)

    def step(self, move):
        """
        Executes a move and returns (next_state, reward, done, info)
        """
        self.board.push(move)
        done = self.board.is_game_over()
        reward = 0
        if done:
            result = self.board.result()
            if result == "1-0":
                reward = 1
            elif result == "0-1":
                reward = -1
            else:
                reward = 0
        
        return self.get_state(), reward, done, {}

    def render(self):
        print(self.board)

def move_to_index(move):
    """
    Simplistic move to index mapping. 
    In a real AlphaZero, this is much more complex (8x8x73).
    For this demo, we'll use a simpler encoding: (from_sq * 64) + to_sq.
    """
    return move.from_square * 64 + move.to_square

def index_to_move(index, board):
    """
    Converts index back to a chess.Move object.
    """
    from_sq = index // 64
    to_sq = index % 64
    move = chess.Move(from_sq, to_sq)
    
    # Handle promotion (default to Queen for simplicity)
    if chess.square_rank(to_sq) in [0, 7] and board.piece_at(from_sq).piece_type == chess.PAWN:
        move.promotion = chess.QUEEN
        
    return move
